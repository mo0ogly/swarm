const tr_web_prephase_conversion_js = source => globalThis.SwarmI18n?.t(source) ?? source;
export class PreparationConversion {
 constructor(api,current,committed){
  this.api=api;this.current=current;this.committed=committed;this.pending=null;this.busy=false;this.routeGeneration=0;this.preflight=null;
  this.dialog=document.getElementById('conversion-dialog');this.confirm=document.getElementById('conversion-confirm');this.error=document.getElementById('conversion-error');
  document.getElementById('conversion-open').addEventListener('click',e=>{if(e.isTrusted)this.open()});
  this.confirm.addEventListener('click',e=>{if(e.isTrusted)this.submit()});
 for(const id of ['organization-provider','organization-worker','organization-level'])document.getElementById(id)?.addEventListener('change',()=>{this.invalidatePreflight();this.resolve()});
 document.getElementById('organization-workspace')?.addEventListener('input',()=>this.invalidatePreflight());
 for(const id of ['organization-tasks','organization-calls'])document.getElementById(id)?.addEventListener('input',()=>this.updateSummary());
 document.getElementById('organization-validation')?.addEventListener('change',()=>{document.getElementById('organization-checks').hidden=document.getElementById('organization-validation').value!=='automatic';this.updateSummary()});
 document.getElementById('organization-preflight-details')?.addEventListener('click',e=>{if(e.isTrusted)document.getElementById('preflight-details-dialog').showModal()});
 document.getElementById('organization-preflight')?.addEventListener('click',e=>{if(e.isTrusted)this.runPreflight()});
 }
 hasPending(){return !!this.pending}
 paint(p){
  const box=document.getElementById('conversion-state'),button=document.getElementById('conversion-open'),link=document.getElementById('conversion-pilotage'),status=document.getElementById('conversion-status');
  box.hidden=!p.plan_ready&&!p.conversion;
  if(p.conversion){
   const c=p.conversion;link.hidden=false;link.href='/?work='+encodeURIComponent(c.work_id);
   status.textContent=c.task_ids.length+tr_web_prephase_conversion_js(' missions créées. ')+(c.released_at?tr_web_prephase_conversion_js('Démarrage autorisé ; le moteur contrôle encore les profils, dépendances, budget, pause et autonomie.'):tr_web_prephase_conversion_js('Démarrage verrouillé : autorisez-le quand vous êtes prêt.'));
   const revised=p.plan_ready&&p.documents.plan.sha256!==c.plan_hash;button.hidden=!!c.released_at&&!revised;button.textContent=revised?tr_web_prephase_conversion_js('Comparer et appliquer la révision'):tr_web_prephase_conversion_js('Relire et autoriser le démarrage');
  }else{link.hidden=true;button.hidden=false;button.textContent=tr_web_prephase_conversion_js('Relire l’équipe proposée');status.textContent=tr_web_prephase_conversion_js('Plan vérifié. Relisez l’équipe et ses IA, vérifiez les conditions de lancement puis donnez une autorisation unique.')}
 }
 async open(){
  try{
   const p=await this.current();if(!p)return;
   if(this.pending){this.dialog.showModal();return}
   const review=await this.api('preparations/conversion?id='+encodeURIComponent(p.id));
   if(review.preparation.revision!==p.revision)throw new Error(tr_web_prephase_conversion_js('Préparation modifiée : actualisez les versions avant de relire les missions.'));
   this.review=review;this.error.textContent='';const c=p.conversion;
   const revising=review.action==='revise-missions';document.getElementById('conversion-organization').hidden=!!c;document.getElementById('conversion-changes').hidden=!revising;const changes=document.getElementById('conversion-change-list');changes.replaceChildren();for(const change of review.changes||[]){const li=document.createElement('li');li.textContent=change.title+' : '+change.kind;changes.append(li)}document.getElementById('conversion-warning').textContent=review.warning||'';
   document.getElementById('conversion-title').textContent=revising?tr_web_prephase_conversion_js('Réviser ce Swarm'):c?tr_web_prephase_conversion_js('Autoriser les missions créées'):tr_web_prephase_conversion_js('Créer les missions du plan');
   document.getElementById('conversion-target').textContent=(p.work_id?tr_web_prephase_conversion_js('Travail existant : '):tr_web_prephase_conversion_js('Nouveau travail : '))+review.work_title;
   document.getElementById('conversion-explanation').textContent=revising?tr_web_prephase_conversion_js('La version relue remplacera les définitions des missions. Les résultats concernés seront à revérifier. Le démarrage sera verrouillé et la mission mise en pause.'):c?tr_web_prephase_conversion_js('Vous autorisez le plan créé, présenté ci-dessous, même si le brouillon a évolué depuis. En mode automatique, les missions éligibles pourront démarrer. Profils, dépendances, budget et pause restent applicables.'):tr_web_prephase_conversion_js('Cette revue propose l’équipe, ses IA, la validation et les missions. Le bouton final constitue l’unique autorisation : il crée cet ensemble et autorise seulement ensuite les départs éligibles. Aucun processus ne démarre avant ce geste.');
   const list=document.getElementById('conversion-missions');list.replaceChildren();
   for(const m of review.spec.tasks){const item=document.createElement('li'),title=document.createElement('strong'),text=document.createElement('p');title.textContent=m.id+' — '+m.title;text.textContent=tr_web_prephase_conversion_js('Rôle : ')+({worker:tr_web_prephase_conversion_js('Exécutant'),planner:tr_web_prephase_conversion_js('Planificateur'),subplanner:tr_web_prephase_conversion_js('Planificateur de branche')}[m.role]||m.role)+tr_web_prephase_conversion_js(' · Livrable : ')+m.deliverable+tr_web_prephase_conversion_js(' · Dépendances : ')+(m.depends.join(', ')||tr_web_prephase_conversion_js('aucune'))+tr_web_prephase_conversion_js(' · Critères : ')+m.criteria.join(' ; ');item.append(title,text);list.append(item)}
   this.confirm.textContent=revising?tr_web_prephase_conversion_js('Appliquer la révision et mettre en pause'):c?tr_web_prephase_conversion_js('Autoriser le démarrage des missions'):tr_web_prephase_conversion_js('Autoriser cette équipe et ses missions');this.confirm.disabled=!c&&!revising;this.dialog.showModal();if(!c)await this.setupOrganization();
  }catch(e){document.getElementById('error').textContent=e.message;document.getElementById('error').hidden=false}
 }
 async submit(){
  if(this.busy||!this.review)return;
 if(!this.review.preparation.conversion&&!this.pending){try{this.organization=this.readOrganization()}catch(e){this.error.textContent=e.message;return}}
  const p=this.review.preparation,c=p.conversion;
  if(!c&&!this.preflight){this.error.textContent=tr_web_prephase_conversion_js('Vérifiez les conditions de lancement avant d’autoriser cette équipe.');return}
  this.pending ||= {version:1,action:this.review.action==='revise-missions'?'revise-missions':c?'release-plan':'authorize-plan',preparation_id:p.id,event_id:crypto.randomUUID(),expected_revision:p.revision,expected_work_revision:this.review.work_revision,sha256:this.review.action==='revise-missions'?p.documents.plan.sha256:c?c.plan_hash:p.documents.plan.sha256,...(!c?{organization:this.organization}:{})};
  this.busy=true;this.confirm.disabled=true;
  try{
   let result=await this.api('preparations/command',this.pending);this.pending=null;
   if(result.receipt_historical)result=await this.api('preparations/show?id='+encodeURIComponent(p.id));
   this.committed(result);this.dialog.close();document.getElementById('conversion-pilotage').focus();
  }catch(e){if(e.status&&e.status<500)this.pending=null;this.error.textContent=e.message;this.confirm.textContent=this.pending?tr_web_prephase_conversion_js('Vérifier l’enregistrement'):tr_web_prephase_conversion_js('Réessayer après relecture');if(!this.pending){this.confirm.disabled=true;this.review=null}}
  finally{this.busy=false;if(this.review)this.confirm.disabled=false}
 }
 async setupOrganization(){
  const data=await this.api('preparations/providers'),select=document.getElementById('organization-provider');select.replaceChildren(new Option(tr_web_prephase_conversion_js('Choisir une IA…'),''));for(const p of data.providers){const o=new Option(p.provider,p.provider);o.disabled=!p.available;select.add(o)}const workers=document.getElementById('organization-worker');workers.replaceChildren(new Option(tr_web_prephase_conversion_js('Même fournisseur si ses outils le permettent'),''));for(const p of data.providers.filter(p=>p.available&&!p.text_only))workers.add(new Option(p.provider,p.provider));const chosen=document.getElementById('chat-provider')?.value;if(chosen)select.value=chosen;
  document.getElementById('organization-workspace').value='.';
  const host=document.getElementById('organization-checks');host.replaceChildren();const hint=document.createElement('p');hint.className='notice info';hint.textContent=tr_web_prephase_conversion_js('Chaque contrôle est exécuté avec les arguments indiqués, au plus 30 secondes. Maximum huit contrôles par mission : trois étapes et jusqu’à cinq critères. Les commandes doivent réellement prouver le résultat.');host.append(hint);
  for(const task of this.review.spec.tasks){const box=document.createElement('section'),title=document.createElement('h4');title.textContent=task.title;box.append(title);
   const checks=[['plan-entry',tr_web_prephase_conversion_js('Conditions de départ : ')+task.entry,1],['plan-validation',tr_web_prephase_conversion_js('Vérification : ')+task.validation,1],['plan-delivery',tr_web_prephase_conversion_js('Livraison : ')+task.delivery,1],...task.criteria.map((text,i)=>['plan-criterion-'+(i+1),tr_web_prephase_conversion_js('Critère : ')+text,i+1])];
   for(const [id,text,criterion] of checks){const group=document.createElement('fieldset'),legend=document.createElement('legend'),program=document.createElement('select'),args=document.createElement('textarea'),label=document.createElement('label'),programLabel=document.createElement('label');legend.textContent=text;program.id='organization-program-'+task.id+'-'+id;programLabel.htmlFor=program.id;programLabel.textContent=tr_web_prephase_conversion_js('Programme du contrôle');for(const name of ['git','go','node','npm','python3','pytest'])program.add(new Option(name,name));args.id='organization-control-'+task.id+'-'+id;args.dataset.task=task.id;args.dataset.control=id;args.dataset.criterion=String(criterion);args.dataset.program=program.id;args.dataset.justification=text;args.rows=2;args.placeholder=tr_web_prephase_conversion_js('Un argument par ligne, par exemple :\n-m\npytest\ntests/test_exemple.py');label.htmlFor=args.id;label.textContent=tr_web_prephase_conversion_js('Arguments — un par ligne');group.append(legend,programLabel,program,label,args);box.append(group)}host.append(box)}

  this.invalidatePreflight();await this.resolve();
 }
 async resolve(){const gen=++this.routeGeneration;this.route=null;this.workerRoute=null;this.reviewRoute=null;this.routeResolved=false;this.confirm.disabled=true;const info=document.getElementById('organization-model'),provider=document.getElementById('organization-provider').value,worker=document.getElementById('organization-worker').value||provider,level=document.getElementById('organization-level').value;if(!provider){info.textContent=tr_web_prephase_conversion_js('Choisissez une IA pour voir les modèles utilisés.');this.updateSummary();return}info.textContent=tr_web_prephase_conversion_js('Vérification des modèles utilisés…');try{const [owner,workerData]=await Promise.all([{provider,purpose:'planning'},{provider:worker,purpose:'work'}].map(x=>this.api('providers/resolve?'+new URLSearchParams({provider:x.provider,level,purpose:x.purpose}))));if(gen!==this.routeGeneration)return;this.route=owner.route;this.workerRoute=workerData.route;this.reviewRoute=owner.route;this.routeResolved=true;info.textContent=tr_web_prephase_conversion_js('Modèles résolus pour le responsable, les exécutants et la revue. Vérifiez maintenant les conditions de lancement.');this.updateSummary();}catch(e){if(gen===this.routeGeneration){info.textContent=e.message;this.updateSummary()}}}
 invalidatePreflight(){this.preflight=null;document.getElementById('organization-preflight-details').hidden=true;const status=document.getElementById('organization-preflight-status');if(status){status.className='notice attention';status.textContent=tr_web_prephase_conversion_js('Vérifiez les conditions de lancement avant d’autoriser cette équipe.')}this.confirm.disabled=true;this.updateSummary()}
 routeLabel(provider,route){return provider+(route?.model?tr_web_prephase_conversion_js(' · modèle ')+route.model:provider===tr_web_prephase_conversion_js('À choisir')?'':tr_web_prephase_conversion_js(' · modèle géré par l’exécutable'))+(route?.effort?tr_web_prephase_conversion_js(' · effort ')+route.effort:'')}
 updateSummary(){const rawProvider=document.getElementById('organization-provider')?.value,rawWorkspace=document.getElementById('organization-workspace')?.value?.trim(),provider=rawProvider||tr_web_prephase_conversion_js('À choisir'),worker=document.getElementById('organization-worker')?.value||rawProvider||tr_web_prephase_conversion_js('À choisir'),validation=document.getElementById('organization-validation')?.value;document.getElementById('summary-owner').textContent=this.routeLabel(provider,this.route);document.getElementById('summary-workers').textContent=this.routeLabel(worker,this.workerRoute)+tr_web_prephase_conversion_js(' · missions : ')+(this.review?.spec.tasks.length||0);document.getElementById('summary-review').textContent=this.routeLabel(provider,this.reviewRoute)+' · '+(validation==='human'?tr_web_prephase_conversion_js('acceptation humaine'):validation==='automatic'?tr_web_prephase_conversion_js('acceptation par contrôles moteur explicités'):tr_web_prephase_conversion_js('acceptation à choisir'));
  const tasksCap=document.getElementById('organization-tasks')?.value||'20',callsCap=document.getElementById('organization-calls')?.value||'40';
  document.getElementById('summary-limits').textContent=tr_web_prephase_conversion_js('Tâches (plan) : ')+tasksCap+' max'+tr_web_prephase_conversion_js(' · Appels par rôle (responsable/vérificateur) : ')+callsCap+' max';
  const missing=[];
  if(!rawProvider)missing.push(tr_web_prephase_conversion_js('IA à choisir'));else if(!this.routeResolved)missing.push(tr_web_prephase_conversion_js('Modèles non résolus'));
  if(!rawWorkspace)missing.push(tr_web_prephase_conversion_js('Dossier de travail à indiquer'));
  if(!validation)missing.push(tr_web_prephase_conversion_js('Validation à choisir'));
  if(!this.preflight)missing.push(tr_web_prephase_conversion_js('Prévol non exécuté'));
  if(rawProvider&&this.routeResolved&&validation){try{this.readOrganization()}catch(e){missing.push(e.message)}}
  document.getElementById('summary-prerequisites').textContent=missing.length?missing.join(' · '):tr_web_prephase_conversion_js('Aucun prérequis manquant — prêt à autoriser.');
 }
 async runPreflight(){
  const button=document.getElementById('organization-preflight'),status=document.getElementById('organization-preflight-status'),details=document.getElementById('organization-preflight-details');
  this.error.textContent='';let organization;try{organization=this.readOrganization()}catch(e){this.error.textContent=e.message;return}
  button.disabled=true;details.hidden=true;status.className='notice info';status.textContent=tr_web_prephase_conversion_js('Vérification des conditions de lancement…');
  try{
   const result=await this.api('preparations/preflight',{provider:organization.worker_provider||organization.provider,workspace:organization.workspace,level:organization.level});
   const acceptable=result.verdict==='ready'||result.verdict==='compatible';
   status.className='notice '+(acceptable?'success':'alert');
   status.textContent=acceptable?tr_web_prephase_conversion_js('Conditions vérifiées. Vous pouvez autoriser cette équipe.'):tr_web_prephase_conversion_js('Le lancement reste bloqué. Ouvrez les détails pour voir ce qui doit être corrigé.');
   document.getElementById('preflight-details-content').textContent=[result.verdict+' · '+result.verification,...(result.checks||[]).map(c=>globalThis.SwarmI18n?.engine(c.detail)??c.detail)].join('\n');
   details.hidden=false;this.preflight=acceptable?result:null;this.organization=organization;this.confirm.disabled=!acceptable;
  }catch(e){this.preflight=null;status.className='notice alert';status.textContent=e.message;this.confirm.disabled=true}
  finally{button.disabled=false;this.updateSummary()}
 }

 readOrganization(){
  const value=id=>document.getElementById(id).value;const validation=value('organization-validation');if(!validation)throw Error(tr_web_prephase_conversion_js('Choisissez qui accepte les résultats.'));if(!this.routeResolved)throw Error(tr_web_prephase_conversion_js('Choisissez une IA disponible.'));const controls={};
  if(validation==='automatic')for(const input of document.querySelectorAll('#organization-checks textarea')){if(!input.value.trim())throw Error(tr_web_prephase_conversion_js('Précisez les arguments de chaque contrôle.'));const command=[document.getElementById(input.dataset.program).value,...input.value.split('\n').filter(v=>v.trim())];(controls[input.dataset.task]||=[]).push({id:input.dataset.control,command,criteria:[Number(input.dataset.criterion)],justification:input.dataset.justification.slice(0,500),dir:'.',timeout_seconds:30})}

  if(value('organization-provider').startsWith('api-')&&!value('organization-worker'))throw Error(tr_web_prephase_conversion_js('Choisissez un agent avec outils pour les exécutants.'));
  return {worker_provider:value('organization-worker'),provider:value('organization-provider'),level:value('organization-level'),model_policy_hash:this.route?.policy_hash||'',workspace:value('organization-workspace'),validation,controls,max_tasks:Number(value('organization-tasks')),max_calls:Number(value('organization-calls'))};
 }

}
