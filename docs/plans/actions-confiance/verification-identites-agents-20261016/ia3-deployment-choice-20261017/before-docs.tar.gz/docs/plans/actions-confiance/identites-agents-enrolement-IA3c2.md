# IA3c.2 — source d’enrôlement et frontière de contrôle

17 octobre 2026 — protocole d’authenticité IA3c.2a, journal IA3c.2b, schéma
d’autorité IA3c.2c, demande complète IA3c.2d et lecture versionnée IA3c.2e
vérifiés en fixtures ; service protégé, bootstrap et consommateur moteur
**non réalisés**. Choix opérateur en attente.

## Besoin et état observé

IA3b reçoit encore un objet privé d’autorité fourni par son appelant. Sa référence
d’enrôlement est une empreinte syntaxiquement valide, pas une source courante.
IA3c.1 conserve le reçu de cette décision dans le journal. Aucun de ces mécanismes
ne prouve que l’autorité existe encore ou n’a pas été révoquée.

Le paquet `internal/enrollmentproof` fournit désormais l’authenticité d’une réponse
opaque liée à un challenge. Il n’est importé par aucun consommateur moteur.
Le contrat [IA2](identites-agents-contrat-IA2.md) et ses exigences de révocation,
descendants, arrêt observé et protection hôte restent inchangés.

## Décision de protocole et alternatives

Réutiliser l’émetteur de preuves Trust actuel ferait dépendre la nouvelle racine
de la configuration et de l’isolation dont la protection reste à établir.
Une racine distincte est retenue : clé publique épinglée hors réponse/import,
signature Ed25519, contexte projet et demande, nonce aléatoire, séparation de
domaine et une consommation locale. La clé privée reste à un service protégé ;
les tests ne génèrent que des clés éphémères de fixture. Le module ne crée,
ne configure et ne persiste aucune clé réelle.

Le protocole `swarm-enrollment-statement-v1` a deux cadres :

| Cadre | Champs exacts | Contrôle |
| --- | --- | --- |
| Requête publique `Request` | `protocol`, `authority_key_id`, `project_context_digest`, `request_digest`, `nonce` | SHA-256 en hex minuscule, nonce 32 octets base64url canonique, clé attendue par le signataire |
| Réponse signée | `protocol`, `challenge_digest`, `payload`, `signature` | Quatre chaînes exactes, doublons/casse/champs inconnus/types erronés/trailing refusés ; signature Ed25519 et base64url canonique |

Le challenge digest est SHA-256 du JSON à champs fixes de `Request`. Les octets
signés sont le préfixe `swarm-enrollment-statement-v1`, NUL, `response`, NUL,
puis le JSON de réponse à ordre fixe avec `signature` vide. Le payload est une
chaîne base64url d’octets opaques. Une clé publique reçue dans une réponse ne
peut pas devenir une racine. Aucune durée ou limite d’exécution n’est définie ici.
Les longueurs 32/64 octets viennent des formats SHA-256/Ed25519.

L’état mutable du challenge est partagé derrière un pointeur privé : copier
la valeur Go du handle ne duplique ni son verrou ni sa consommation. Une réponse
incorrecte ne consomme rien. Un challenge ne se reconstruit pas par JSON et n’est
pas durable. Un nouveau processus doit en obtenir un nouveau ; le protocole
ne fournit aucune réservation ou déduplication d’effet métier.

## Conditions du futur raccord — état par frontière

| ID | Condition observable exigée | État réel / propriétaire |
| --- | --- | --- |
| EP-01 | Bootstrap explicitement autorisé, principal humain exact et clé publique épinglée hors canal agent ; aucune inférence premier appelant/Admin/cockpit | Ouvert ; opérateur + Codex |
| EP-02 | Le digest de demande couvre principal vérifié, référence de session, projet, plan/génération, événement, instantané complet, racines et checkpoint précédent | Partiel : cadre complet et projection privée IA3c.2d vérifiés ; résolution courante protégée et raccord final ouverts |
| EP-03 | Le payload a un schéma métier strict : identité d’enrôlement et génération, état courant, principal, portée, droits/délégation, dates et tête d’autorité | Partiel : schéma strict et producteur/consommateur locaux IA3c.2c ; aucune capacité moteur ni admission publique |
| EP-04 | La source courante est relue et sérialisée avec la décision finale ; un message signé « actif » reçu après révocation ne suffit pas | Partiel : relecture et sérialisation locales dans IA3c.2b ; fraîcheur finale moteur ouverte |
| EP-05 | Révocation et usage ont un point de linéarisation prouvé sous concurrence ; descendants couverts, arrêt effectif suivi séparément | Ouvert ; même contrat IA2-C06, aucune instantanéité distante déduite |
| EP-06 | Journal durable, témoin indépendant couvrant aussi le plan, rollback/import détectés ; les générations révoquées ne revivent pas par réactivation | Partiel : journal signé, CAS, réouverture et révocation irréversible IA3c.2b ; témoin durable indépendant et plan ouverts |
| EP-07 | Service, clés, sessions et autorité inaccessibles depuis fournisseur/outils/proc/montages/descripteurs ; même UID + 0600 insuffisant | Ouvert ; déploiement/confinement, F07 non clos |
| EP-08 | Signature/erreur/absence/indisponibilité refusées sans autorité vide de succès ; absence d’autorité n’ouvre aucun secours | Signature locale contrôlée ; décision métier et indisponibilité réelles non raccordées |
| EP-09 | Droits, éventuels délais/leases/budgets et limites de transport ont une source documentée et un réglage Admin partagé si politique nouvelle | Aucune nouvelle politique ici ; aucun TTL inventé pour combler EP-04 |
| EP-10 | Publication/création exactes, réservation/départ/reprise incertaine et preuve publique avant requalification des risques | Ouvert ; IA3 puis IA4/IA5 |

Une signature ne fournit pas de confidentialité. Le service devra produire un
payload sans jeton brut ni clé privée, avec un transport protégé et une politique
d’accès cohérente. Un payload vide authentique ne constitue pas un enrôlement.

## Frontière de déploiement à choisir

L’opérateur est sollicité dans cette conversation : compte système distinct sur
cette machine, ou autorité sur une machine séparée. Aucun choix par défaut n’est
activé. Les deux doivent protéger aussi leur administration et ne doivent pas
être reconstruits depuis une base importée ou une réponse reçue.

| Option proposée, non activée | Valeur attendue et preuves nécessaires | Risques résiduels et conséquences |
| --- | --- | --- |
| Service local, compte distinct et confinement vérifié | Pas de nouvelle machine ; séparer clés, journal et témoin des agents ; vérifier permissions, processus, montages, descripteurs et accès au canal | Même noyau et administration hôte : une compromission root peut atteindre les deux. Le compte distinct seul ne confine pas les agents. Installer, maintenir et vérifier le service et le confinement restent nécessaires. |
| Autorité sur une machine séparée | Viser la résistance à une compromission de l’hôte Swarm ; protéger clés et témoin ailleurs, avec administration réellement distincte et contrôles propres de chaque demande | Infrastructure et exploitation supplémentaires : authentification mutuelle, certificats/rotation/révocation, sauvegarde/reprise, disponibilité réseau. Des accès administrateurs, montages ou sauvegardes partagés peuvent annuler la séparation. Un contrôleur compromis peut encore demander une opération interdite si l’autorité lui fait confiance sans contrôle métier. |
| Continuer les briques locales sans activation | Préparer et tester sans nouvelle infrastructure ni changement de service réel | Les risques des lanceurs publics et F01–F07 restent ouverts ; aucune garantie d’isolation réelle, d’admission ou de révocation appliquée ne découle des fixtures. Cette option reporte la protection opérationnelle. |

Dans les deux architectures de service, identifier le pair ne suffit pas :
l’autorité doit contrôler elle-même principal, portée, délégation, état courant
et droit de la demande exacte. SO_PEERCRED rapporte les credentials du processus
pair au moment de la connexion ; ce n’est pas une attestation de son rôle dans
le workflow ([Linux unix(7)](https://man7.org/linux/man-pages/man7/unix.7.html)).
Un agent et le contrôleur partageant un UID peuvent donc rester indiscernables
pour une politique limitée à cet UID. Les options de confinement doivent être
vérifiées sur le système réel, avec leurs interactions et limites, plutôt que
déduites du nom d’un compte ([documentation systemd](https://github.com/systemd/systemd/blob/main/man/systemd.exec.xml)).

Une panne ou partition du service ne doit pas ouvrir de secours permissif pour
une opération exigeant son autorité courante. La linéarisation de l’usage et de
la révocation reste à prouver ; aucune révocation instantanée distante ni aucun
TTL ou lease n’est fixé par ce choix d’hébergement.

Recommandation à confirmer, pas décision opérateur : commencer par un service
local réellement confiné si l’administrateur et le noyau de l’hôte sont dans la
base de confiance ; retenir une machine et une administration séparées si la
menace inclut la compromission de l’hôte Swarm. Garder le contrat indépendant
du transport permettrait ensuite de comparer ces frontières dans la recherche ;
cette portabilité n’est pas encore démontrée entre services réels. Propriétaire
du choix : opérateur ; condition de reprise de l’activation : frontière, principal
initial et autorités de déploiement explicitement décidés.

Le principal humain initial (issuer, sujet externe et liaison locale) doit être
désigné explicitement avant enrôlement réel. Le nom du compte local ou d’un rôle
ne le remplace pas. L’absence de ce choix ne bloque pas les tests du format,
mais bloque toute activation que ces tests ne pourraient pas autoriser.

## Vérification et portée scientifique

Le [rapport IA3c.2a](verification-identites-agents-20261016/ia3-enrollment-proof-20261017/RAPPORT-IA3c2a.md)
conserve les deux contre-exemples du candidat (null accepté et copie du challenge),
les sources, les contrôles normal/race et le schéma FR/EN. L’exécution locale
ne qualifie pas un service réel, un humain OIDC externe, la fraîcheur, la
révocation appliquée ou la sécurité des lanceurs. L’authentification de messages
par signature/challenge est une brique classique ; aucune originalité ou
supériorité comparative n’est démontrée. F01–F07, IDA et RETEX global restent ouverts.


## IA3c.2b — état local durable, pas encore service protégé

Le [contrat opérationnel](../../architecture/AGENT-IDENTITY-CONTRACT.md)
décrit désormais `internal/enrollmentstate` : chaîne signée sous clé/projet
épinglés, WAL, `BEGIN IMMEDIATE`, événement et tête atomiques, identifiants
non réutilisables après révocation, retry exact uniquement à la tête courante.
Le [rapport IA3c.2b](verification-identites-agents-20261016/ia3-enrollment-state-20261017/RAPPORT-IA3c2b.md)
lie les sources et tests. Ce journal dédié n’emploie aucune base de mission.

`WithActive` sérialise une lecture avec les révocations du journal ; `SignActive`
produit un `ActiveReply` sous cette réservation. Le corps reste opaque dans le journal ; IA3c.2c ajoute ensuite sa validation
locale, sans capacité moteur implicite. Une signature déjà retournée peut devenir historique
avant usage : EP-04/05 ne sont pas clos. Le caller fournit le témoin ; le paquet
ne protège ni ne persiste ce témoin hors du journal. Le test de rollback restaure
un journal cohérent et conserve aussi la limite où restaurer le témoin retire
la détection. Aucune indépendance OS ne découle de l’API Go.

L’erreur concurrente du premier candidat est conservée. La correction emploie
la réservation immédiate du pilote et WAL sans timer, plafond ou retry caché.
Une annulation ou une erreur de mise à jour de tête est refusée sans événement
partiel. Les tests de réouverture et de faute SQL ne prouvent pas une reprise
après panne matérielle, une disponibilité sous verrou hostile ou la cohérence
d’un témoin externe mis à jour séparément.

Prochain contrat commun préparatoire : schéma strict de l’autorité d’enrôlement
(principal OIDC complet, portée, permissions, délégation, dates et génération),
validé à son producteur et son consommateur. La désignation du principal, la
racine réelle, la frontière d’hébergement et toute activation attendent les
décisions explicites de l’opérateur. Le raccord ne doit pas accepter un simple
booléen actif ni un payload signé sans ces contrôles.


## IA3c.2c — document strict, génération dérivée de l’histoire

`internal/enrollmentauthority` vérifie désormais le document humain complet,
les droits/délégables et les dates explicites, avec primitives communes extraites
sans modifier les règles/JSON du moteur. `SignEnrollment` valide avant signature ;
`DecodeActive` exige un Statement authentifié et tous les attendus indépendants.
La génération doit égaler `Record.EnrolledSequence`, dérivée de l’événement de
création vérifié et stable quand la tête avance. Ce champ est ajouté au cadre
ActiveReply ; le schéma SQLite et les événements signés existants sont inchangés.
L’ancien cadre sans séquence ne satisfait pas le nouveau consommateur strict.

Le [contrat opérationnel](../../architecture/AGENT-IDENTITY-CONTRACT.md) décrit
les onze champs et les erreurs ; le [rapport IA3c.2c](verification-identites-agents-20261016/ia3-enrollment-authority-20261017/RAPPORT-IA3c2c.md)
conserve les preuves. Le corps générique reste opaque dans le journal, mais le
nouvel adaptateur de données n’accepte plus un booléen actif ou un JSON partiel.
EP-03 est partiellement réalisé localement ; le schéma de demande complète EP-02
et la conversion autorisée vers une capacité privée moteur restent ouverts.

Une ancienne tête fournie comme attendue peut encore authentifier son ancienne
réponse ; aucun test ne prétend prouver une fraîcheur finale ou un enrôlement
réel. Le choix de frontière, le principal initial, le témoin externe durable et
le point de linéarisation d’usage restent des préconditions explicites.


## IA3c.2d — demande complète et référence exacte de session

`internal/enrollmentrequest` définit le cadre complet de publication, son digest
avec domaine/version, ses copies immuables, son lien au challenge et la projection
d’attendus d’autorité. Le cadre couvre les octets complets du snapshot, les racines
exactes, l’humain, l’empreinte/dates de session, la portée, l’événement, les deux
checkpoints et le document d’enrôlement attendu. `CheckActive` compare aussi ce
dernier digest, pas seulement l’ID et la génération.

La projection privée moteur vérifie des frames déjà résolues, avec les validateurs
existants ; le résolveur conserve le `TokenDigest` réellement produit par Trust.
Il n’existe aucun second argument token que la projection pourrait associer à
un autre caller. La projection pure ne prouve pas l’actualité de la session,
du plan ou des checkpoints, ne lit pas leur source et ne crée pas de permis.
Le [rapport IA3c.2d](verification-identites-agents-20261016/ia3-enrollment-request-20261017/RAPPORT-IA3c2d.md)
conserve résultats et limites. EP-02 reste partiel tant que le raccord ne produit
pas ce cadre depuis l’état courant protégé et ne revalide pas son usage final.


## IA3c.2e — lecture versionnée et décodage commun

Le cadre ActiveReply exige désormais `schema_version: 1`. SignActive l’émet et
DecodeActiveReply le vérifie avant les contrôles d’autorité. Les anciens cadres
sans version et les versions inconnues, même authentiques, sont refusés sans
fallback. Le test original reproduit l’acceptation de l’ancien cadre sans version ;
sa correction et ses limites sont dans le [rapport IA3c.2e](verification-identites-agents-20261016/ia3-enrollment-reply-20261017/RAPPORT-IA3c2e.md).
Les signatures historiques, événements et schéma SQLite restent inchangés.
I2c-06 est réalisé pour le format et le refus locaux ; sélection et interopérabilité
entre vrais pairs restent à vérifier avant client externe. Aucun service activé,
aucune preuve d’actualité ou d’autorité ne découle du numéro de version.
