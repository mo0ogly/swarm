# Contrat interne d'identité et d'autorité des agents

17 octobre 2026 — [English](../en/AGENT-IDENTITY-CONTRACT.md).
Périmètre : noyau IA2.2, canal IA2.3a, source durable IA2.3b, liaison au plan
IA3a, émission humaine IA3b, reçu IA3c.1 et protocole isolé IA3c.2a. Ces composants
internes restent non raccordés aux lanceurs.
Les défauts de l'[audit IA1](../plans/actions-confiance/verification-identites-agents-20261016/RAPPORT-IA1.md)
restent ouverts. Il n'existe aucun nouvel endpoint, commande, paramètre Admin,
bootstrap ou confinement fournisseur livré par ce contrat.

## Responsabilités et parcours actuel

Le [contrat sémantique IA2](../plans/actions-confiance/identites-agents-contrat-IA2.md)
définit la cible complète. Le noyau concret vérifie des données et construit un
reçu de décision. Une décision positive n'est ni une réservation, ni une
approbation humaine, ni un processus attesté, ni un effet métier observé.

```mermaid
flowchart TD
  R["Demande interne JSON"] --> P["Schéma strict : aucune autorité déclarée"]
  P --> L["Verrou partagé Trust"]
  L --> I["Résoudre le jeton dans l'état courant"]
  A["Cadre fourni par le contrôle<br/>source durable IA2.3b ci-dessous"] --> V
  I --> V["Vérifier plan, instance, octrois et délégation"]
  V --> D["Décision liée à la demande exacte ou refus"]
  D -. "IA2.3 / IA3 : non raccordé" .-> E["Engagement atomique, lancement et effets"]
```

Le producteur Trust fournit l'émetteur et le sujet, la catégorie `local`, `human`
ou `service`, la révision et l'expiration. Le noyau ne promeut pas un accès local
en personne ni les rôles métier `requester`, `approver`, `admin` ou `effect` en
droit de création. Il ne déduit aucune instance du seul jeton.

## Données et sources d'autorité

Types privés dans `internal/engine/agent_identity_contract.go` :

| Objet | Contenu / sens |
| --- | --- |
| `agentIdentityPrincipal` | Identifiant local, catégorie, émetteur et sujet externe distincts. Aucun jeton brut ni condensat de jeton dans l'attribution. |
| `agentIdentityActor` | Principal et éventuelle instance. Ce rattachement doit être établi par le contrôle. |
| `agentIdentityScope` | Mission, génération persistée et empreinte du contrat enregistré. IA3a le lit dans SQLite ; cela ne prouve pas une adoption humaine attestée. |
| `agentIdentityGrant` | Émetteur, détenteur, parent, portée, révision Trust, permissions exactes, permissions déléguables, dates et révocation. |
| `agentIdentityInstance` | Instance, agent logique, principal, portée, octroi et référence de liaison d'exécution. Comparer cette référence n'atteste pas le processus. |
| `agentIdentitySnapshot` | Schéma 1, révision, octrois et instances sérialisables. Une sauvegarde ou un import reste une donnée. |
| `agentIdentityRequest` | Schéma 1, événement, portée, octroi, opération, ressource et empreinte de contenu. Aucun champ auteur/approbateur/autorité autorisant. |
| `agentIdentityDecision` | Contexte de projet, événement, acteur, empreintes de demande et d'instantané, révisions et expiration maximale. Aucun effet ni consommation implicites. |

`agentIdentityAuthority` est un cadre privé, non sérialisable depuis JSON :
racine canonique du projet, empreinte et révision courantes de l'instantané, révision Trust, plan courant et
octrois racine explicitement reconnus. Le producteur durable interne est décrit
en IA2.3b ; les émetteurs protégés de permis/checkpoint restent à raccorder.
Recalculer ce cadre depuis l'instantané à vérifier créerait une autorité circulaire.
Les tests historiques IA2.2 construisent une fixture ; IA2.3b lit les données
persistées sous un checkpoint de contrôle, sans déployer d'ancre externe.

Les empreintes sont des SHA-256 en hexadécimal minuscule. Les identifiants
réutilisent la syntaxe commune `safeName`. Les ressources sont comparées
exactement, sans jokers ni règle implicite de préfixe de chemin. Les opérations
reconnues sont `agent.create`, `memory.read`, `memory.summarize`,
`memory.transmit`, `tool.invoke`, `effect.execute` ; leurs consommateurs ne sont
pas raccordés par cette livraison. Il n'existe ni délai ni plafond opérateur
nouveau caché dans ce noyau.

Émetteur et sujet sont des chaînes opaques : les crochets d'un émetteur IPv6
ou d'un sujet ne sont pas traités comme des jokers. La validation du texte
refuse vide, UTF-8 invalide, contrôles et espaces périphériques ; l'interdiction
`*?[]` concerne seulement les ressources de permission.

Le digest du contenu doit venir de la proposition réelle, de ses paramètres et
de son contexte résolu. Le noyau lie la décision au digest reçu ; il ne prouve
pas la bonne production de ce digest ni sa correspondance avec un futur effet.
Le producteur et la frontière d'engagement appartiennent à IA2.3/IA3.

## Vérifications et reprise

`decodeAgentIdentityRequest` refuse champs inconnus, variantes de casse des
champs, doublons de clés y compris imbriqués/échappés, document multiple,
entrée vide/null/invalide, autorité déclarée et octrois à joker. Le décodeur
d'instantané refuse aussi les champs inconnus, les doublons et les objets absents.

`evaluateAgentIdentity` exige un appelant vérifié au même instant d'évaluation,
un cadre courant, un instantané correspondant et la même portée. Il vérifie
détenteur, référence d'instance, permission, dates, révocations et chaîne jusqu'à
une racine reconnue. Chaque lien conserve la portée ; ses droits sont inclus
dans les droits déléguables du parent et sa validité temporelle y est incluse.
La chaîne est parcourue avec détection des cycles, sans récursion par octroi.

Le consommateur lie l'appelant à `Store.root`, déjà canonisé à l'ouverture.
Le cadre privé doit désigner cette même racine ; le reçu porte l'empreinte de
ce contexte. Deux projets aux mêmes noms et jetons de fixture ne peuvent ainsi
échanger cadre et reçu. Ce contrôle local n'est ni un identifiant de projet
durable entre hôtes, ni une preuve de propriété du compte système. Une migration
de racine ou une fédération devra établir explicitement son nouveau contexte
et son ancre protégée dans IA2.3.

Une modification de la configuration Trust invalide les anciens octrois dans
ce contrat conservateur : renouvellement explicite requis. La réauthentification
ne remet pas ces octrois à jour. L'expiration d'une décision ne dépasse ni celle
du demandeur ni celle des octrois utilisés.

`Store.evaluateAgentIdentityRequest` résout l'identité et évalue sous le même
verrou Trust. Un rejeu repasse par cette résolution, puis par les mêmes contrôles
et la comparaison complète du reçu. Il ne retourne pas un ancien résultat avant
authentification. Le temps réel est échantillonné après acquisition du verrou ;
une horloge de fixture peut être injectée par les tests internes. Aucune horloge
JSON n'est acceptée. Ce consommateur interne ne fournit pas encore de voie
pour un appelant agent : celle-ci attend le courtier protégé.

`validateAgentIdentityTransition` exige la révision suivante et la conservation
des anciens enregistrements. Une révocation ne peut être effacée ou déplacée ;
les autres champs d'un ancien octroi ou d'une instance ne sont pas réécrits.
Un remplacement utilise un nouvel identifiant et ne supprime pas l'histoire.
Le contrôle de transition n'autorise ni ne publie la modification : le futur
écrivain devra vérifier l'état courant et publier son ancre sous le protocole
atomique approprié. Aucun stockage de production n'utilise encore ce validateur.

## Limites et suite obligatoire

La vérification des tests est conservée dans le
[rapport IA2.2](../plans/actions-confiance/verification-identites-agents-20261016/ia2-contract-kernel-20261017/RAPPORT-IA2.2.md).
Les essais emploient des racines isolées, des acteurs d'instance simulés et des
émetteurs OIDC/service locaux. Ils ne prouvent ni fournisseur réel ni revue
indépendante. Les régressions du contexte d'appelant réutilisé et du cadre échangé
entre projets sont conservées avant et après leurs corrections.

Restent à réaliser : bootstrap et émetteurs protégés du cadre/checkpoint,
engagement de l'admission dans les verrous, intégration du canal d'instance, liaison au contenu préparé, approbation humaine exacte, consommation unique, course
départ/révocation, réconciliation après panne et raccord de **tous** les
consommateurs CLI/API/fournisseur/mémoire. Les deux fichiers de stockage actuels
ne deviennent pas atomiques par l'ajout d'un évaluateur. La matrice IDA-01–18 et
le RETEX restent la condition de qualification globale.

## Expérience de canal IA2.3, distincte du noyau

Le [prototype du 17 octobre](../plans/actions-confiance/verification-identites-agents-20261016/ia2-runtime-binding-20261017/RAPPORT-IA2.3-CANAL.md)
vérifie 13 contrôles locaux sur deux cages Linux. PID/montage sont épinglés avant
exécution ; l'émetteur est attribué par les credentials de chaque message. Une
connexion B copiée à A conserve le pair B, mais le message est attribué à A et
refusé sous l'identité B déclarée. Trois joins vers B avec des descripteurs de
namespace copiés sont refusés. Le namespace utilisateur change au bootstrap et
n'est pas supposé stable. Ce prototype Python n'est ni un courtier Go intégré ni
une source d'autorité ; registre et révocation sont en mémoire. Les lanceurs
ne sont pas qualifiés par cette expérience.

## Canal Go d'instance — IA2.3a

Le récepteur et le registre de liaisons sont maintenant implémentés dans
`agent_identity_channel_linux.go` et `agent_identity_runtime_linux.go`.
`Store.evaluateAgentIdentityMessage` les relie au noyau IA2.2 en interne.
Ils ne sont enregistrés dans aucun serveur ni lanceur. Le [rapport IA2.3a](../plans/actions-confiance/verification-identites-agents-20261016/ia2-go-channel-20261017/RAPPORT-IA2.3a.md)
porte les contrôles et limites de cette tranche.

```mermaid
flowchart TD
  C["Contrôle avant ouverture de la porte<br/>tests Bubblewrap ; lanceurs non raccordés"] --> N["Épingler les namespaces PID/montage attendus"]
  N --> T["Table privée de liaisons en mémoire"]
  M["Paquet Unix avec credentials et pidfd du message"] --> J["Décoder la demande stricte"]
  J --> L["Verrou Trust partagé : état courant"]
  L --> R["Verrou du registre de liaisons"]
  T --> R
  R --> P["Namespaces du processus par ioctl sur le pidfd"]
  P --> B["Comparer UID et objets épinglés ; refuser révocation"]
  B --> H["Lire l'horloge après les attentes"]
  H --> V["Vérifier IA2.2 ; décision ou refus"]
  A["Cadre privé d'autorité<br/>source durable IA2.3b ci-dessous"] -.-> V
```

Le contrôle appelle `pin` à partir d'un bootstrap de lanceur tenu par une porte,
puis conserve les descripteurs PID/montage. Le namespace PID de l'hôte, les
références incompatibles et la réutilisation d'une instance, liaison ou namespace
PID déjà réservé sont refusés. Le premier message ne peut pas remplir cette table.
Son caractère privé au processus ne protège pas le compte contrôleur hôte non
confiné ; le lanceur et le bootstrap protégés restent des obligations d'intégration.

`configureAgentIdentityChannel` exige un socket Unix `SOCK_SEQPACKET` et active
`SO_PASSCRED` et `SO_PASSPIDFD`. La réception exige credentials et un unique
`SCM_PIDFD`. Les namespaces sont obtenus depuis ce descripteur, sans rouvrir le
numéro de PID du message. Un émetteur disparu n'est pas réidentifié par son numéro.
Le pair de connexion n'est pas utilisé pour attribuer le message. Il s'agit du
processus/groupe de threads indiqué par ce mécanisme, pas d'une attestation de
chaque thread ou du binaire exécuté. Les primitives manquantes entraînent un refus,
sans repli numérique ; seule la plateforme du rapport a été exécutée.

Le consommateur fournit son tampon et sa deadline de transport. Aucun plafond ni
délai opérateur nouveau n'est introduit. Un paquet tronqué, des credentials
manquants ou des droits de fichier injectés sont refusés ; les descripteurs reçus
sont fermés en cas de rejet. Le consommateur ferme le message accepté. Les
namespaces restent épinglés jusqu'à fermeture du registre, même après révocation,
pour conserver l'exclusion des anciennes références. Une table vide après reprise
n'adopte pas l'autorité du premier émetteur.

La réception a lieu hors du verrou Trust. L'évaluation prend Trust partagé puis
le registre, vérifie révision/liaison/UID/namespaces, échantillonne le temps réel
après ces attentes et appelle le noyau sous les deux verrous. La révocation de
liaison et la fermeture sont sérialisées avec cette évaluation. Cela ne constitue
aucun engagement Trust/SQLite, aucune consommation unique ni aucun arrêt observé.
Les instantanés et cadres d'autorité employés par les essais restent des fixtures.

Le verrou runtime protège les liaisons, pas les maps d'un instantané fourni par
un autre composant. IA2.3b fournit sa propre copie courante. Les consommateurs
primitifs IA2.2/IA2.3a recevant encore un cadre et un instantané supposent que leur
appelant respecte cette propriété et leur fraîcheur ; ils ne consultent pas le
registre durable. Une opération publique devra utiliser le parcours durable.

## Source durable et publication récupérable — IA2.3b

Le registre privé est maintenant produit depuis SQLite et une tête Trust
indépendante. La version **36** a ajouté les tables suivantes ; le stockage
courant est **37**, avec le stamp de plan IA3a décrit ci-dessous :
`agent_identity_snapshots` conserve les versions, `agent_identity_publications`
les reçus chaînés. La migration sauvegarde le stockage et ne crée aucun droit
pour les anciens travaux. La consultation refuse une migration implicite.
Le [rapport IA2.3b](../plans/actions-confiance/verification-identites-agents-20261016/ia2-durable-authority-20261017/RAPPORT-IA2.3b.md)
lie les sources, commandes et résultats ; les sections précédentes restent les
étapes IA2.2/IA2.3a, avec leurs fixtures d'origine.

```mermaid
sequenceDiagram
  participant C as Contrôle autorisé
  participant T as Trust / fichier durable
  participant S as SQLite
  C->>T: Prendre Trust exclusif sans attente cachée
  C->>S: Réserver transaction et vérifier version / travail
  C->>C: Vérifier permission exacte, appelant frais et ancienne tête
  C->>T: Persister intention et instantané cible
  Note over T,S: Toute lecture identité refuse<br/>une intention en attente
  C->>S: Insérer instantané et reçu, puis COMMIT
  C->>T: Finaliser la tête et retirer le marqueur en attente
  T-->>C: Checkpoint cible après publication réussie
  Note over C,S: Après interruption, reprise exacte du permis initial, sans lancer de processus
```

La tête stocke contexte du projet, portée, révision et digest de l'instantané,
révision Trust, racines reconnues, principal publiant, événement et lien vers la
tête précédente. Elle provient d'un `agentIdentityRegistryPermit` privé liant
le contenu exact, la portée et les racines autorisées. La voie normale résout
le jeton courant sous Trust, après attente de SQLite et de nouveau avant
l'intention. Un rôle métier ou un corps JSON ne construit pas ce permis.
IA3b ajoute le producteur humain interne décrit ci-dessous ; son enrôlement réel
et son raccord public restent à réaliser.

La publication prend Trust exclusif en mode non bloquant, puis réserve SQLite
avant lecture. Elle vérifie le travail, la version et le checkpoint précédent,
les liens, l'histoire non réécrite et le contenu approuvé. Elle persiste une
intention dans `agent_identity_authorities` de Trust avant COMMIT, puis publie
la nouvelle tête. Une panne après intention ou après COMMIT laisse une reprise
exacte à effectuer. `recoverAgentIdentityRegistry` exige le permis et l'instantané
initiaux ; il ne prépare pas une nouvelle opération. Une révision Trust changée
est conservée : finaliser un historique ancien ne réactive pas ses droits.

`atomicWrite` ouvre désormais le répertoire avant mutation, synchronise le
fichier, renomme, puis synchronise le répertoire. Une erreur après renommage
signifie un résultat incertain à réconcilier. Les tests ne simulent pas une
coupure électrique ou un stockage qui ment sur `fsync`.

La lecture d'inspection exige un `agentIdentityRegistryCheckpoint` privé et
courant, fourni par le contrôle, puis vérifie tête Trust, chaîne, instantané et
plan dans une transaction de lecture, avant de libérer sa copie. Le consommateur
de message `evaluateAgentIdentityRegistryMessage` obtient aussi ses données
dans le registre, sans snapshot/cadre déclaré dans le message ; depuis IA3a,
il réserve l'écrivain SQLite jusqu'à la décision runtime, comme décrit ci-dessous.
Le temps réel est lu après les attentes. Aucun de ces chemins ne consomme un
droit ni ne lance un effet métier.

Le checkpoint n'est pas recalculé depuis une base importée ou le même ensemble
de fichiers restaurés. Les tests le conservent hors de l'état restauré ; ils
ne déploient aucun témoin externe. Si tous les fichiers et un ancien témoin sont
restaurés ensemble, la fraîcheur n'est pas prouvée. L'émission et la conservation
indépendantes du témoin restent une condition d'intégration ouverte. La portée
est liée au permis du contrôle et au contrat enregistré lu en IA3a. Une
adoption humaine attestée et l’appartenance exacte de la création restent à raccorder. La confidentialité du paquet Go ne protège pas à elle seule le compte
hôte, les fichiers du contrôle ou une image SQLite hostile arbitraire. F01–F07
restent ouverts, de même que l'admission publique, le confinement fournisseur,
l'accord humain exact, la réservation/départ et les droits mémoire.


## Liaison au contrat courant du plan — IA3a

`agent_identity_plan_linux.go` lit le corps et la révision du travail, avec
`agent_identity_plan_heads`, dans la même transaction SQLite que l'autorité.
Il exige un plan enregistré dans `Work.Plans` ou une planification hiérarchique
valide ; le plan classique adopté, la conversion d'une préparation et les
décisions hiérarchiques alimentent cette source commune. Leur enregistrement
ne constitue pas une preuve d'approbation humaine ni un droit de création.

La projection **v1** conserve les définitions, instructions, propriétaires, rôles,
dépendances, hiérarchie, budgets, profils et champs inconnus. Elle retire les
champs identifiés de résultat, statut, tentative, revue, bail, compteur et
candidat intégré. Les sélections mémoire restent des entrées ; leur présence
n'autorise aucun usage. Les résultats/cadrages et leur transmission demandent
toujours leurs propres droits. Les listes gardent leur ordre ; les clés
d'objets sont canonisées à tous les niveaux, sans arrondir les entiers en
`float64`. Changer un champ conservé exige un nouveau permis exact.

```mermaid
flowchart TD
  W["Insertion ou modification de Work"] --> T["Transaction SQLite<br/>projection v1 et génération du contrat"]
  T --> S["Work et stamp du plan<br/>engagés ensemble"]
  S --> R["Lecteur identité<br/>écrivain SQLite réservé"]
  H["Tête Trust et checkpoint courant<br/>émetteur encore de fixture"] --> R
  R --> C{"Même génération<br/>et même empreinte ?"}
  C -->|Oui| V["Liaison runtime et contrôle des droits"]
  C -->|Non| N["Refus : aucune autorité retournée"]
  V --> F["COMMIT sans effet métier"]
```

La migration **37** sauvegarde le stockage, crée les stamps initiaux de
génération 1 et installe les triggers d'insertion/modification de `works`.
Chaque modification du contrat augmente sa génération dans cette transaction ;
un simple résultat runtime identifié la conserve. Modifier puis rétablir
l'ancien contenu ne réactive donc pas son ancienne portée, même après
réouverture. Un rollback de transaction annule aussi son stamp. Le compteur
doit rester un entier SQLite positif ; son dépassement technique refuse toute
la modification. Ce compteur n'est pas une limite de ressources opérateur.

Les triggers utilisent `swarm_identity_plan_digest_v1`, fonction pure enregistrée
une seule fois dans le pilote avant ouverture des connexions. Ils vérifient
le stamp précédent avant réécriture. Le lecteur recalcule l'empreinte du corps
et compare le stamp, sa version de projection et la portée de la tête Trust.
L'absence d'un plan retourne `agent_identity_plan_unavailable`, une portée
différente `agent_identity_plan_mismatch`, et un stamp absent/incohérent
`agent_identity_plan_stamp_changed`. Un refus normal ne prépare pas d'intention,
ne publie pas de droit et ne crée pas d'agent. Une erreur de trigger annule
l'écriture du travail, sans résultat vide présenté comme succès.

`readAgentIdentityNextPlanScope` propose en lecture seule la portée constatée
pour un futur permis. Il exige le checkpoint de la tête existante, refuse une
publication en attente et ne déduit aucune autorité d'un import. La publication
normale compare le permis à cette même source après réservation SQLite,
avant intention. La reprise exacte peut terminer un historique préparé avant
un changement de plan ; la lecture normale de cet historique reste refusée.
Pour une décision d'instance, l'ordre est Trust partagé → réservation
d'écrivain SQLite → lecture courante → verrou runtime → temps frais et
évaluation pure → COMMIT. La réservation interdit un changement de Work
pendant l'attente runtime. Le callback fermé ne réentre pas dans Store et les
méthodes runtime appelées n'accèdent pas à SQLite ; les futurs consommateurs
doivent respecter cette précondition. Une erreur, y compris de COMMIT, ne
retourne aucune décision positive. Cette sérialisation a un coût de concurrence
non mesuré et ne réalise toujours ni consommation ni lancement. Le composant
reste privé et ne rend pas l'admission des lanceurs effective.

Le stamp et ses triggers sont des mécanismes d'intégrité applicative, pas une
frontière contre un administrateur hôte ou un processus fournisseur non confiné.
Une restauration physique de tout SQLite peut aussi restaurer l'ancien stamp.
Un checkpoint ne couvrant que la tête d'identité inchangée ne prouve pas la
fraîcheur d'un changement de plan non publié dans cette tête : le futur témoin
indépendant doit couvrir aussi le watermark du plan. Son émetteur/protection
restent ouverts, propriétaires Codex et opérateur. L'appartenance de la création
au plan, son contenu résolu, l'accord humain, sa consommation et tous les
lanceurs publics restent à intégrer ; F01–F07 et IDA ne sont pas requalifiés.

## Émettre un permis depuis une autorité humaine explicite — IA3b

`mintAgentIdentityRegistryPermit` reçoit l'instantané complet, le jeton, le
checkpoint précédent, l'événement et les racines proposées. Le contrôleur lui
fournit séparément un `agentIdentityIssuerAuthority` privé : principal exact
(identifiant local, catégorie `human`, issuer et sujet externe), projet, portée
du plan, révision Trust, référence d'enrôlement, permissions exactes, sous-ensemble
délégable et intervalle de validité. Il s'agit d'une autorité explicite de
publication du registre, distincte des permissions qu'elle plafonne pour ses
nouvelles racines ; ni `agent.create` seul ni un rôle Admin ne l'impliquent.

Cet objet est une entrée de contrôle, pas une configuration lue depuis le JSON
demandé. La référence d'enrôlement est contrôlée syntaxiquement ; sa seule
empreinte ne prouve pas un enrôlement. Le service protégé qui atteste, persiste,
révoque et rafraîchit cette autorité reste à raccorder. Les tests fournissent
une autorité explicite de fixture et effectuent réellement le protocole OIDC
contre un fournisseur local à jetons signés ; aucun compte humain externe
ou service d'enrôlement déployé n'est qualifié par ces contrôles.

```mermaid
flowchart TD
  E["Enrôlement protégé courant<br/>prérequis : encore une fixture"] --> A["Autorité privée explicite<br/>principal, portée, droits et dates"]
  H["Session OIDC résolue par Trust"] --> V["Trust partagé puis écrivain SQLite<br/>plan courant et temps frais"]
  A --> V
  S["Candidat complet et checkpoint précédent"] --> V
  V --> P["Permis privé exact<br/>empreinte, racines, session et échéance"]
  P --> C["Publiant : revalider session et autorité<br/>après attente et avant intention"]
  C --> D["Intention Trust puis COMMIT SQLite<br/>puis tête Trust"]
  D -.-> X["Lanceurs publics et accord de création exact<br/>raccord restant à réaliser"]
```

L'émission vérifie d'abord l'identité et l'autorité sous Trust, avant SQL et
recherche du travail. Elle réserve ensuite l'écrivain SQLite, réauthentifie après
cette attente, puis lit le plan et le registre courant. Une session locale, un service workload, une instance,
un homonyme d'un autre issuer/sujet ou une identité non enrôlée est refusé.
Un import ne devient pas une autorité. Les nouvelles racines, y compris celles
non activées, et la réactivation d'une ancienne racine non reconnue respectent
l'émetteur, les permissions, les dates et le plafond délégable explicites.
L'historique est conservé ; l'émission ne publie ni ne consomme un droit.
La validité de ces liens n'atteste pas qu'une délégation a réellement été
demandée par son acteur ; la réception et l'origine des créations restent
à vérifier au consommateur d'admission.

Le permis possède ses listes, lie l'instantané complet, les racines, le
principal, le projet, le plan, la révision Trust et l'événement. Sa preuve privée
lie aussi la session d'émission et une échéance bornée par l'enrôlement et cette
session. L'identité et l'autorité sont vérifiées de nouveau après les lectures.
Une erreur de COMMIT retourne un permis nul. Aucun jeton brut n'est conservé
dans le permis ou le journal. Il n'y a ni durée cachée ni nouveau réglage ;
les dates sont des conditions de cette autorité fournie par le contrôle.

Le publiant recontrôle ces conditions après la réservation SQL et avant
l'intention durable. Une autre session du même humain ne peut reprendre ce
permis ; une échéance passée pendant l'attente est refusée sans intention ni
ligne de registre. `agent_identity_human_issuer_required` distingue un appelant
non humain ; `agent_identity_issuer_authority_required`, une autorité absente
ou incompatible ; `agent_identity_issuer_authority_stale`, des dates ou une
session périmées ; `agent_identity_issuer_ceiling_exceeded`, des racines excédant
l'octroi. Une demande corrigée nécessite une nouvelle émission explicite. La
reprise après intention ne fait que terminer cet historique exact ; elle peut
le finaliser après expiration de la session, sans produire de nouvel accord.

Le chemin bas niveau antérieur reste une capacité privée de contrôleur, utilisée
par les fixtures sans cette preuve humaine. Ce noyau ne rend donc pas tous les
permis du paquet humains et ne sécurise aucun endpoint public existant. Le futur
adaptateur public devra imposer le nouveau producteur et sa source d'enrôlement
protégée ; aucun booléen reçu d'un agent ne choisit un chemin. Le stockage et la
reprise des capacités privées hors processus restent à réaliser. Une copie
ancienne de l'autorité ne prouve pas sa non-révocation externe. Une session
OIDC catégorisée humaine ne prouve ni présence humaine physique, ni authentification
renforcée, ni accord d'un approbateur distinct sur le contenu résolu d'une création.
Ces critères, le témoin du plan, F01–F07 et les droits mémoire restent ouverts.

Recette locale : `go test ./internal/engine -run '^TestAgentIdentityIssuer'
-count=1 -v -timeout=0`, puis les contrôles ciblés du registre et du plan. Les commandes,
sources figées, deux échecs initiaux et résultats sont conservés dans le
[rapport IA3b](../plans/actions-confiance/verification-identites-agents-20261016/ia3-issuer-20261017/RAPPORT-IA3b.md).


## Conserver le reçu humain dans l’historique — IA3c.1

La tête de publication humaine passe au format 2 et contient un
`issuance_receipt` version 1. La tête lie déjà l’instantané exact, les racines,
l’événement et la tête précédente ; son empreinte couvre désormais aussi le reçu.
Le reçu conserve le principal humain exact, le projet, le plan, la révision Trust,
la référence d’enrôlement fournie, les permissions et dates de cette autorité,
l’empreinte de session, sa date d’expiration, l’instant d’émission et la fin de
validité du permis. Cette fin est le minimum des deux expirations. Aucun jeton
brut n’y figure. Les listes retournées sont possédées par leur lecteur.

```mermaid
flowchart TD
  A["Autorité fournie par le contrôle<br/>enrôlement réel encore à raccorder"] --> M["Émission authentifiée<br/>session et temps frais"]
  M --> R["Reçu historique<br/>autorité, session sous empreinte, dates"]
  R --> H["Tête version 2<br/>candidat exact et reçu liés par empreinte"]
  H --> T["Intention Trust durable"]
  T --> Q["COMMIT du journal SQLite"]
  Q --> F["Finalisation de la tête Trust"]
  T -.-> X["Reprise exacte après interruption<br/>même reçu, aucune autorisation nouvelle"]
  Q -.-> X
  X --> F
  F --> V["Lecture : checkpoint indépendant<br/>cohérence du reçu et chaîne historique"]
```

Le format 2 exige le reçu ; le format 1 reste réservé aux capacités privées
antérieures sans reçu. Les combinaisons incohérentes sont refusées. Les anciens
lecteurs ne comprenant que le format 1 refusent les nouvelles têtes ; le schéma
SQLite reste 37. Le protocole existant stocke exactement le même reçu dans
l’intention, le journal et la tête finale, y compris après réouverture et reprise
aux deux frontières de durabilité. La lecture historique valide les dates au
moment d’émission ; elle ne transforme pas un reçu expiré en autorité courante.

Ce reçu est une trace liée au contrôle, pas une signature indépendante ni une
preuve d’enrôlement réel, de non-révocation externe ou de présence physique.
Sa lecture exige toujours le checkpoint protégé indépendant. Restaurer ensemble
le stockage et son témoin, ou contrôler le même UID sans confinement, reste hors
de la garantie. Le reçu ne permet pas de reconstruire un permis privé ni de
reprendre sans la capacité de contrôle originale. Bootstrap, témoin couvrant le
plan, admission publique, approbation distincte et droits mémoire restent ouverts.

Vérification : les résultats et limites de cet incrément sont conservés dans le
[rapport IA3c.1](../plans/actions-confiance/verification-identites-agents-20261016/ia3-issuance-receipt-20261017/RAPPORT-IA3c1.md).


## Authentifier une réponse du futur service d’enrôlement — IA3c.2a

Le paquet isolé `internal/enrollmentproof` implémente un format de réponse signée,
sans raccord au moteur ou à un transport réseau. `NewVerifier` reçoit la clé
publique épinglée par le contrôle et le digest de projet ; aucune clé de confiance
n’est extraite d’une réponse. `NewChallenge` génère un nonce aléatoire de 256 bits
et lie clé/projet/digest de la demande complète. `SignResponse` signe le cadre
avec Ed25519 et une séparation de domaine/version ; il ne décide pas des droits.
Les clés privées des tests sont éphémères et locales ; aucun bootstrap réel
n’est activé.

```mermaid
flowchart TD
  B["Bootstrap indépendant<br/>cible : choix opérateur en attente"] -.-> K["Clé publique épinglée<br/>NewVerifier"]
  K --> Q["Challenge local neuf<br/>clé, projet, demande complète, nonce"]
  S["Service protégé courant<br/>cible : non raccordée"] -.-> R["SignResponse<br/>format testé avec clé de fixture"]
  Q --> R
  R --> V["Verify<br/>signature, contexte et enveloppe stricte"]
  K --> V
  V --> P["Statement : octets authentifiés<br/>une consommation locale"]
  P -.-> C["Schéma métier, fraîcheur et révocation<br/>contrôles consommateurs à réaliser"]
  C -.-> E["Admission et publication moteur<br/>raccord absent"]
```

`Verify` exige les quatre clés exactes `protocol`, `challenge_digest`, `payload`,
`signature`, toutes de type chaîne ; doublons, variantes de casse, champs inconnus,
valeurs null/non textuelles et données supplémentaires sont refusés. Le payload
et la signature utilisent base64url canonique sans padding. Le payload reste
opaque : une chaîne vide authentifiée ne signifie ni enrôlement ni autorisation.
`Statement.Payload()` rend une copie ; le client doit encore valider le schéma,
les droits et la source courante. Une signature n’apporte pas de confidentialité.

Une réponse valide consomme une seule fois son challenge local, sous mutex.
Le handle partage son état interne même après copie de valeur Go.
Une réponse refusée ne le consomme pas ; une nouvelle requête emploie un nouveau
nonce. Les replays simultanés, le changement de projet/demande, la réécriture
d’un digest sur une signature capturée, une clé non épinglée et une signature
d’un autre domaine sont refusés. Le challenge n’est pas reconstructible depuis
JSON ; son état n’est pas durable et ne réserve aucune publication ou exécution.

**Limite explicite :** un service peut signer « actif » puis révoquer avant la
réception ou l’application. Cette réponse peut encore être authentique ; le
paquet ne prouve aucune fraîcheur à la décision finale. Ni signature, ni nonce,
ni reçu historique ne remplacent une lecture courante et un point de
linéarisation de révocation. Aucun TTL, timeout, plafond métier ou réglage
opérateur n’est ajouté ici. Les tailles Ed25519/SHA-256 et le nonce définissent
le format cryptographique ; elles ne sont pas des budgets d’exécution.

Le [contrat cible d’enrôlement](../plans/actions-confiance/identites-agents-enrolement-IA3c2.md)
distingue ce module vérifié, les garanties encore absentes et les décisions de
déploiement. Recette isolée : `go test ./internal/enrollmentproof -count=1
-timeout=0`, puis `-race` et `go vet` sur ce paquet. Les preuves et limites sont
conservées dans le [rapport IA3c.2a](../plans/actions-confiance/verification-identites-agents-20261016/ia3-enrollment-proof-20261017/RAPPORT-IA3c2a.md).


## Journal durable de l’enrôlement — IA3c.2b

`internal/enrollmentstate` ajoute un journal SQLite dédié, isolé du moteur.
`Open` reçoit un chemin contrôlé, une clé publique épinglée et le digest de
projet. Le stockage exige WAL et des transactions `BEGIN IMMEDIATE`, avec
`synchronous=FULL` sur chaque connexion. Aucune clé privée n’est persistée ;
aucun service ou compte système réel n’est créé. Le journal n’est pas une source
d’autorité métier : le corps de chaque enregistrement reste un tableau d’octets
opaque, dont le schéma et les permissions doivent être validés au futur raccord.

```mermaid
flowchart TD
  B["Bootstrap et protection OS<br/>cible : décision opérateur attendue"] -.-> K["Clé publique et projet épinglés"]
  K --> J["Journal SQLite dédié<br/>chaîne signée et tête vérifiées"]
  H["Head retenu indépendamment<br/>protection durable : cible"] --> A["Apply : comparer puis ajouter<br/>ou reconnaître le retry exact courant"]
  J --> A
  A --> D["COMMIT événement et tête<br/>enroll unique ou revoke irréversible"]
  D --> L["WithActive : BEGIN IMMEDIATE<br/>relire toute la chaîne et comparer Head"]
  H --> L
  L --> S["SignActive sous réservation locale<br/>réponse liée au challenge"]
  S --> V["enrollmentproof.Verify<br/>authenticité des octets"]
  V -.-> E["Schéma métier et fraîcheur à l’usage<br/>raccord moteur : non réalisé"]
```

Le protocole `swarm-enrollment-change-v1` impose un JSON canonique à dix champs :
`protocol`, `authority_key_id`, `project_digest`, `sequence`, `previous`,
`operation`, `id`, `body`, `signature`. La signature Ed25519 couvre le préfixe
du protocole, NUL, `change`, NUL, puis ce JSON avec `signature` vide. `body` et
`signature` sont en base64url canonique sans padding. La tête contient la séquence
et SHA-256 du cadre signé complet. Le format refuse les clés inconnues, doublons,
variantes de casse, null, types erronés et encodages non canoniques. Les identifiants
sont opaques, jamais des chemins ou du SQL ; les requêtes sont paramétrées.
Les identifiants vides, UTF-8 invalides ou avec caractères de contrôle sont refusés.

`SignChange` ne signe qu’une proposition. `Apply` vérifie la clé, le projet,
l’intégralité de la chaîne et la tête attendue avant d’ajouter un événement.
`enroll` ne peut créer un identifiant qu’une fois ; `revoke` exige un identifiant
actif et un corps vide. Un identifiant révoqué reste dans l’historique et ne peut
être réactivé ; une autre création exige un nouvel identifiant. Un retry exact
après réponse perdue ne réussit que si cet événement est encore la tête courante.
Une révocation ultérieure empêche de rejouer l’ancien enrôlement avec succès.
L’événement et sa tête sont écrits dans la même transaction ; une erreur de
stockage n’est jamais convertie en succès vide.

Chaque lecture `WithActive` prend la réservation écrivain avant de relire la
chaîne, puis garde cette réservation pendant le callback. Une révocation concurrente
ne peut pas committer pendant ce callback ; après son propre COMMIT, une lecture
active est refusée. Le callback ne doit ni réentrer dans le journal, ni attendre
un autre écrivain, ni produire d’effet externe irréversible : une erreur de fin
de transaction reste possible après son appel. `SignActive` ne retourne les
octets signés qu’après succès de la transaction ; son `ActiveReply` contient
`schema_version: 1`, `head` (`sequence`, `digest`) et `record` (`id`, `body`, encodé en base64 JSON,
et `enrolled_sequence`, séquence de création dérivée de la chaîne).
Cette réponse peut devenir ancienne dès la réservation libérée.

Le contrôleur doit fournir un `Head` conservé indépendamment du journal/import.
La tête zéro signifie uniquement une genèse explicitement autorisée. Restaurer
un ancien journal cohérent est détecté contre le témoin plus récent ; restaurer
le témoin lui-même retire cette garantie. Le journal ne persiste pas ce témoin
indépendant et ne résout pas le transfert atomique entre journal et témoin externe.
Une réponse perdue est récupérable avec le changement exact signé ; cela ne prouve
pas une reprise distribuée, un arrêt effectif ou la livraison d’une révocation.

Les refus distinguent contexte, tête, changement invalide, identifiant absent,
déjà enrôlé et révoqué ; les erreurs SQLite et d’annulation conservent leur cause.
La contention remonte immédiatement, sans `busy_timeout` ni retry automatique.
WAL exige un système de fichiers local compatible ; ses fichiers auxiliaires
font partie du stockage à protéger, pas seulement le fichier principal.
La séquence SQLite/Go est un entier signé sur 64 bits : son dépassement est refusé
comme limite de représentation, pas comme politique d’exécution. Aucune durée,
budget ou limite métier n’est introduit. Une lecture reconstruit toute la chaîne :
son coût croît avec l’historique ; aucune performance à grande échelle n’est prouvée.

Recette isolée : `go test ./internal/enrollmentstate -count=1 -timeout=0`, puis
`-race`, `go vet` et `go build` sur ce paquet. Le
[rapport IA3c.2b](../plans/actions-confiance/verification-identites-agents-20261016/ia3-enrollment-state-20261017/RAPPORT-IA3c2b.md)
conserve les refus, l’échec concurrent initial, la correction et les preuves finales.
Les tests de réouverture et d’erreur transactionnelle ne simulent pas une panne
matérielle. Service protégé, témoin externe durable, schéma d’autorité humaine,
révocation/départ distribués et admission publique restent ouverts ; F01–F07
et les droits mémoire ne sont pas requalifiés.


## Valider le document d’autorité des deux côtés — IA3c.2c

`internal/enrollmentauthority` définit le document d’autorité humaine et son
producteur/consommateur local. Le journal générique conserve des corps opaques ;
ce paquet refuse de les traiter comme autorité sans schéma complet et contexte
attendu indépendant. Il retourne des données validées, jamais un permis privé
moteur. Aucun endpoint ou lanceur n’importe ce paquet.

```mermaid
flowchart TD
  C["Contrôle autorisé<br/>principal et droits explicites : prérequis"] -.-> D["Document version 1<br/>humain, projet, plan, droits et dates"]
  P["identitycontract partagé<br/>principal, portée, permission, nom"] --> D
  D --> S["SignEnrollment<br/>schéma valide et génération = prochain événement"]
  S --> J["Journal signé : Apply<br/>CAS, création unique, révocation"]
  J --> R["SignActive : tête courante<br/>séquence de création dérivée de la chaîne"]
  R --> V["enrollmentproof.Verify<br/>challenge et signature"]
  E["Expected indépendant<br/>tête, identité, génération, demande, portée"] --> A["DecodeActive<br/>cadre et document stricts, dates à l’observation"]
  V --> A
  P --> A
  A --> O["Document validé<br/>aucune capacité moteur créée"]
  O -.-> M["Raccord moteur et fraîcheur à l’usage<br/>cible : non réalisés"]
```

Le document version 1 exige les onze champs `schema_version`, `enrollment_id`,
`generation`, `project_context_digest`, `principal`, `scope`,
`trust_configuration_revision`, `permissions`, `delegable`, `not_before`,
`expires_at`. `principal` contient `principal_id`, `principal_kind`, `issuer`, `subject` ;
`scope` contient `work_id`, `plan_version`, `plan_digest`. Chaque permission a
`operation` et `resource`. Les clés sont exactes et l’encodage JSON canonique
est celui d’`Encode`, y compris l’ordre déclaré, les dates UTC RFC3339Nano et
`delegable: []` pour une liste vide. `Decode` refuse omission, null, doublon,
champ inconnu, variante de casse, type erroné ou encodage différent, même imbriqués.
Le producteur peut fournir des dates avec un autre fuseau : `Encode` conserve
leurs instants et les écrit en UTC, sans inventer de durée.

`identitycontract` partage les structures et validations avec les types privés
moteur ; `safeName` délègue aussi à cette source. Le JSON et les règles existantes
restent inchangés : noms locaux ASCII de 1 à 100 octets, version de plan et
révision Trust positives, digest SHA-256 en hex minuscule, ressources exactes
sans glob, six opérations existantes (`agent.create`, `memory.read`,
`memory.summarize`, `memory.transmit`, `tool.invoke`, `effect.execute`). Cette
syntaxe existante des noms ne s’applique pas aux issuer/sujets OIDC : ils restent
opaques, comparés exactement sans normalisation d’URL, casse ou espaces.
Le document d’enrôlement exige un principal `human` valide ; ni `local`, ni
`service`, ni rôle métier ou nom identique ne satisfait cette condition.

Les droits doivent être non vides, valides et sans doublon. Les délégables sont
valides, sans doublon et inclus dans les droits. Les deux dates sont explicites,
avec `not_before < expires_at`. La fenêtre est fermée au début et ouverte à
l’expiration. `Encode`/`Decode` vérifient sa structure, sans affirmer que l’autorité
est valable maintenant ; `DecodeActive` exige l’instant d’observation du contrôle.
Ce paramètre n’est pas une preuve d’horloge fraîche ; le raccord final devra
le fournir au bon point sous sérialisation.

`SignEnrollment` lie la génération à `base.Sequence + 1`, au projet exact et
à l’identifiant du document avant signature. L’ajout doit encore réussir sous CAS.
Le journal dérive ensuite `Record.EnrolledSequence` de l’événement `enroll`
vérifié, sans prendre ce nombre dans son corps. La génération reste stable
lorsque d’autres enregistrements ou révocations font avancer la tête. Le format
SQLite et les événements signés antérieurs ne changent pas ; leurs lectures
reconstruisent ce champ. Les anciens cadres de réponse sans ce champ ne sont
pas acceptés par le nouveau consommateur strict ; aucun client moteur existant
n’était raccordé à ce format isolé.

`DecodeActive` reçoit un `Statement` authentifié et `Expected` fourni par le
contrôle : tête courante attendue, ID d’enrôlement, génération, projet, principal
complet, portée complète, révision Trust et digest de demande. Il exige leur
égalité exacte dans la requête authentifiée, le cadre, le document et la séquence
de création du journal. Un document pourtant signé via le chemin opaque avec
une génération déclarée différente de l’événement est refusé. Le contrat du
contenu complet de `request_digest` reste à raccorder au moteur (EP-02).

Les erreurs distinguent document invalide, contexte incompatible et fenêtre
inactive ; aucun document partiel n’est retourné. Un document JSON seul peut
être structurellement valide sans être authentifié ; sa reconstruction n’accorde
aucun droit. Un ancien `Statement` vérifié avec son ancien `Expected` peut encore
passer : ce contrôle ne relit pas le service et ne prouve pas une non-révocation
à l’usage. Aucun budget, TTL, timeout ou réglage opérateur nouveau n’est ajouté.

Recette : `go test ./internal/identitycontract ./internal/enrollmentauthority
./internal/enrollmentstate -count=1 -timeout=0`, puis le même lot `-race`,
`go vet` et compilation ciblée ; vérifier séparément les consommateurs privés
moteur après extraction. Le [rapport IA3c.2c](../plans/actions-confiance/verification-identites-agents-20261016/ia3-enrollment-authority-20261017/RAPPORT-IA3c2c.md)
conserve ces contrôles et leurs limites. Enrôlement réel, source de temps,
témoin durable indépendant, point de linéarisation final, admission publique,
descendants et F01–F07 restent ouverts.


## Lier la demande complète au challenge — IA3c.2d

`internal/enrollmentrequest` définit une seule finalité :
`agent_identity_registry_publication`. Le paquet couvre le candidat complet,
pas seulement son ID ou une empreinte fournie. `Prepare` valide les données,
les encode et en conserve une copie immuable ; il n’authentifie pas leur source.
`Decode` peut reconstruire cette donnée depuis un cadre canonique, sans créer
une capacité privée moteur ni prouver l’identité déclarée.

```mermaid
flowchart TD
  T["Trust : caller vérifié<br/>empreinte de session conservée"] --> P["Projection privée moteur<br/>principal, session, portée et candidat complet"]
  C["Contrôle : autorité et checkpoint<br/>actualité protégée : prérequis"] -.-> P
  P --> D["Publication canonique version 1<br/>instantané entier et racines exactes"]
  D --> H["Prepared immuable<br/>SHA-256 avec domaine et version"]
  H --> N["NewChallenge<br/>projet exact et digest de demande"]
  D -.-> S["Service : recevoir le cadre complet<br/>Bind puis vérifier la source : cible"]
  N -.-> S
  S -.-> R["Réponse authentifiée<br/>source et transport protégés : cible"]
  R --> V["enrollmentproof.Verify"]
  H --> A["CheckActive<br/>attendus, dates et empreinte du document"]
  V --> A
  A --> O["Donnée d’autorité validée<br/>aucun permis d’exécuter"]
  O -.-> E["Réauthentification et état courant<br/>linéarisation à l’usage : à réaliser"]
```

`Publication` version 1 a seize champs, tous présents : `schema_version`,
`purpose`, `project_context_digest`, `principal`, `session_digest`,
`session_verified_at`, `session_expires_at`, `scope`,
`trust_configuration_revision`, `enrollment`, `event_id`, `snapshot_revision`,
`snapshot_digest`, `snapshot`, `root_grants`, `previous_registry_head_digest`.
`enrollment` contient `id`, `generation`, `head` (`sequence`, `digest`) et
`document_digest`. Principal et portée réutilisent `identitycontract`.
Le checkpoint précédent est une chaîne vide explicite pour la seule genèse
fournie par le contrôle ; l’omission et null sont refusés. L’enrôlement ciblé
exige une génération positive, une tête la couvrant et le digest du document.

Le JSON canonique suit l’ordre des champs Go et écrit les dates en UTC, sans
inventer de durée. `snapshot` transporte en base64 JSON les octets entiers de
l’instantané ; `snapshot_digest` doit être leur SHA-256 exact. Ce paquet vérifie
un contenu JSON de type objet, sans réimplémenter son schéma de grants, ses transitions
ou l’autorité de publication. La projection moteur applique ses validations
existantes puis utilise le JSON canonique complet du snapshot. L’ordre des
racines reste exact, comme dans la tête du registre ; ni tri ni déduplication
silencieuse. Doublons de racines, noms invalides, cadres non canoniques et
clés inconnues/dupliquées, même imbriquées dans le cadre, sont refusés. Les
règles du contenu embarqué restent celles du moteur.

Le digest de demande est SHA-256 de `swarm-enrollment-publication-request-v1`,
NUL, `request`, NUL, puis du cadre canonique entier. Ce digest diffère de celui
du seul snapshot. Il couvre aussi la référence et les dates de session,
l’enrôlement attendu, son document exact et les deux checkpoints distincts :
tête d’enrôlement et tête précédente de publication. Modifier l’une de ces
dimensions change la demande ; une réponse liée à l’ancienne demande ne couvre
pas la nouvelle. La finalité est fixe : un autre type d’action exige un contrat
explicite, pas une chaîne libre réutilisant ce format.

`Prepared.Bytes()` et `Publication()` rendent des copies possédées. Les copies
de valeur Go du handle ne peuvent modifier ni ses octets ni son digest ; les
champs internes ne se reconstruisent pas par JSON. Cela protège la cohérence
locale, pas une frontière OS. `Expected()` projette depuis ces mêmes octets
les attendus du consommateur d’autorité, au lieu de maintenir deux descriptions.
`NewChallenge` refuse un vérificateur d’un autre projet. Le service futur doit
recevoir le cadre complet et appeler `Bind` pour comparer projet et digest ;
`Bind` n’authentifie pas le pair ni l’enveloppe cryptographique. Ces vérifications
restent celles de `SignResponse`/`Verify` et du contrôle protégé.

`CheckActive` vérifie la fenêtre de session observée, les attendus complets puis
le digest du document d’autorité retourné. Un autre document authentique pour
le même ID/génération, avec des droits ou plafonds différents, est refusé.
L’observation de session est incluse ; l’expiration est exclue. Une date fournie
ne prouve ni horloge fraîche ni session encore active. Le digest ne contient
aucun jeton brut et ne doit jamais servir lui-même de credential d’accès.

Dans le moteur, `resolveAgentIdentityCaller` conserve désormais dans son résultat
privé le `TokenDigest` produit par Trust. La projection
`prepareAgentIdentityEnrollmentRequest` ne reçoit donc pas un autre jeton à
associer au caller. Elle vérifie caller/autorité/portée/checkpoint, la référence
d’enrôlement et le snapshot avec les validateurs existants. Cette fonction pure
ne lit ni Trust ni SQLite : son appelant futur doit résoudre et sérialiser leur
état courant. Elle ne remplace pas le producteur de permis, la validation des
nouveaux plafonds sur l’historique, l’approbation humaine ou le départ d’un agent.
Les callers runtime sans session humaine ne deviennent pas des émetteurs.

Aucun endpoint, transport ou service réel ne consomme ce format. Les octets et
les empreintes ne démontrent pas une adoption humaine du plan, une non-révocation
courante ou un effet unique. Le coût croît avec la taille du candidat ; aucune
limite de transport, durée, TTL, budget ou politique nouvelle n’est ajoutée.
La source courante, la fraîcheur finale, le témoin durable indépendant et le
versionnement du cadre de lecture avant client externe restent ouverts.

Recette : `go test ./internal/enrollmentrequest -count=1 -timeout=0`, même lot
avec `-race`, puis `go vet` et `go build` du paquet. Vérifier séparément la
projection et les consommateurs privés moteur. Le [rapport IA3c.2d](../plans/actions-confiance/verification-identites-agents-20261016/ia3-enrollment-request-20261017/RAPPORT-IA3c2d.md)
conserve commandes, collecte réelle, sources et limites. Aucun PASS global
F01–F07, IDA ou droits mémoire n’en découle.


## Version explicite du cadre de lecture — IA3c.2e

Le cadre `ActiveReply` est désormais versionné : `schema_version` vaut exactement
`1` (`enrollmentstate.ActiveReplySchema`). Le format a trois champs de premier
niveau : `schema_version`, `head`, `record`. `SignActive` écrit cette version sous
la réservation du journal ; la signature couvre tous les octets, version comprise.
Ce numéro décrit le cadre de lecture : il ne change pas le schéma SQLite, les
événements signés, le challenge, le document d’autorité ou la demande complète.

```mermaid
flowchart TD
  J["Journal sous réservation locale<br/>tête et enregistrement courants"] --> S["SignActive<br/>ActiveReply schema_version = 1"]
  S --> V["Signature et challenge<br/>enrollmentproof.Verify"]
  V --> D["DecodeActiveReply commun<br/>version et JSON canonique stricts"]
  D --> R["Format reconnu<br/>Head et Record cohérents, octets possédés"]
  D --> F["Version absente ou inconnue<br/>refus sans donnée ni repli"]
  R --> A["DecodeActive puis CheckActive<br/>attendus, document et dates"]
  A --> O["Donnée validée<br/>aucun permis d’exécuter"]
  O -.-> E["Source protégée et état frais à l’usage<br/>raccord restant à réaliser"]
```

`enrollmentstate.DecodeActiveReply` est l’unique décodeur de ce cadre. Une version
absente, nulle, zéro, négative ou inconnue est refusée ; une version d’un type
erroné aussi. Les clés inconnues, doublons, variantes de casse, omissions,
encodages non canoniques et données supplémentaires sont refusés. La tête doit
être positive avec un digest valide ; la séquence de création doit être positive
et couverte par cette tête. L’identifiant conserve les règles opaques du journal.
`body` est une chaîne base64 JSON, éventuellement vide, pas null. Un corps opaque
vide reste valide pour le journal ; il ne devient pas un document d’autorité.

Le consommateur `enrollmentauthority.DecodeActive` délègue le décodage à ce point
commun puis applique ses propres contrôles d’autorité. Il conserve la cause par
chaînage : une version non supportée reste détectable avec `ErrReplyVersion`,
tout en étant un `ErrDocument` pour le consommateur. Une forme incorrecte produit
`ErrReply`. Aucun résultat partiel n’est retourné ; un paquet authentique d’une
version inconnue reste refusé. Le décodage seul ne vérifie pas sa signature :
il doit porter sur le payload d’un Statement authentifié.

**Compatibilité : rupture explicite du prototype de lecture.** L’ancien cadre
sans version est refusé, sans réessai automatique dans un format antérieur. Les
producteurs et consommateurs doivent sélectionner la version 1 explicitement ;
le seul ensemble supporté est `{1}`. Aucun client externe n’était raccordé.
La négociation et l’interopérabilité entre véritables pairs restent à vérifier
avant leur premier raccord (I2c-06 partiel au déploiement). Les réponses historiques
et leurs preuves ne sont pas réécrites ; aucune migration du journal n’est requise.
Une version correcte ne prouve ni fraîcheur, ni non-révocation, ni droit d’action.

Recette : `go test ./internal/enrollmentstate ./internal/enrollmentauthority
./internal/enrollmentrequest -count=1 -timeout=0`, même lot avec `-race`, puis
`go vet` et compilation ciblée. Le [rapport IA3c.2e](../plans/actions-confiance/verification-identites-agents-20261016/ia3-enrollment-reply-20261017/RAPPORT-IA3c2e.md)
conserve le contre-exemple sans version, les refus, sources et limites. Aucun
TTL, timeout, budget ou politique opérateur nouveau n’est ajouté.

## Choix de frontière du service — décision ouverte

Trois suites sont proposées, sans activation : service local sous compte distinct
avec confinement vérifié, autorité sur une machine et une administration séparées,
ou poursuite des seules briques locales. Le [plan d’enrôlement](../plans/actions-confiance/identites-agents-enrolement-IA3c2.md)
compare bénéfices, risques et conséquences. La première conserve le noyau et
l’administration hôte dans la base de confiance ; la seconde vise une séparation
face à la compromission de l’hôte Swarm, sous réserve de ne pas partager les
accès administratifs et de vérifier la politique propre du service. La troisième
laisse la protection opérationnelle ouverte. Ces résultats ne sont pas déployés.

La protection de la clé et l’identification du pair ne suffisent pas : l’autorité
doit contrôler les droits de la demande exacte et son état courant. SO_PEERCRED
rapporte des credentials de processus, pas un rôle de workflow
([Linux unix(7)](https://man7.org/linux/man-pages/man7/unix.7.html)). Un canal
accessible à un agent sous le même UID peut donc défaire la séparation recherchée.
Une indisponibilité ne peut ouvrir de secours permissif pour une opération
exigeant l’autorité courante. Hébergement, principal initial et déploiement restent
à décider par l’opérateur ; aucune option présélectionnée ne vaut accord.
