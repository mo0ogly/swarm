//go:build linux

package engine

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unicode"
)

func terminalText(s string) string {
	return strings.Map(func(r rune) rune {
		if unicode.IsControl(r) || unicode.Is(unicode.Cf, r) {
			if r == '\n' || r == '\t' {
				return ' '
			}
			return -1
		}
		return r
	}, s)
}
func hostIdentity() string {
	name, _ := os.Hostname()
	boot, _ := os.ReadFile("/proc/sys/kernel/random/boot_id")
	namespace, _ := os.Readlink("/proc/self/ns/pid")
	return name + ":" + strings.TrimSpace(string(boot)) + ":" + namespace
}
func processStamp(pid int) string {
	b, e := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid))
	if e != nil {
		return ""
	}
	// comm may contain spaces and parentheses; fields after its LAST closing paren.
	at := strings.LastIndex(string(b), ")")
	if at < 0 {
		return ""
	}
	f := strings.Fields(string(b[at+1:]))
	if len(f) < 20 || f[0] == "Z" {
		return ""
	}
	return f[19]
}
func (s *Store) spawnAgent(a Agent) error {
	if err := s.storageGuard(); err != nil {
		return err
	}
	exe, e := os.Executable()
	if e != nil {
		return e
	}
	cmd := exec.Command(exe, "--root", s.root, "_supervise", a.ID)
	cmd.Dir = s.root
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	// The supervisor is detached from terminal; all diagnostics go through SQLite.
	null, e := os.OpenFile(os.DevNull, os.O_RDWR, 0)
	if e != nil {
		return e
	}
	defer null.Close()
	cmd.Stdin = null
	cmd.Stdout = null
	cmd.Stderr = null
	if e = cmd.Start(); e != nil {
		_ = s.finishAgent(a, "failed", "Impossible de démarrer le superviseur", nil)
		return e
	}
	return cmd.Process.Release()
}
func providerEnvironment(allow []string) []string {
	// Provider credentials are inherited only if explicitly allowlisted, never persisted.
	names := []string{"PATH", "HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "TERM", "TMPDIR", "XDG_CONFIG_HOME", "XDG_CACHE_HOME", "CODEX_HOME", "SSL_CERT_FILE", "SSL_CERT_DIR", "NODE_EXTRA_CA_CERTS", "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY"}
	names = append(names, allow...)
	out := []string{}
	seen := map[string]bool{}
	for _, name := range names {
		if seen[name] || strings.ContainsAny(name, "=\x00") {
			continue
		}
		seen[name] = true
		if value, ok := os.LookupEnv(name); ok {
			out = append(out, name+"="+value)
		}
	}
	return out
}

const maxProviderEventBytes = 1 << 20

type outputSink struct {
	provider         string
	cooldown         *ProviderCooldown
	cooldownError    error
	publicBytes      int
	publicLimited    bool
	collectReply     bool
	reply            string
	usage            *Usage
	reportedModel    *ReportedModel
	discarding       bool
	visibilityLogged bool
	guard            *loopGuard
	mu               sync.Mutex
	pending          []byte
	logs             []AgentLog
	s                *Store
	id               string
	capture          bool
	bytes            int
	lines            int
	truncated        bool
	activity         string
}

func (w *outputSink) Write(p []byte) (int, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	n := len(p)
	if w.guard != nil && n > 0 {
		w.guard.lastOutput = time.Now()
		w.guard.outputSeen = true
	}
	// Provider activity is updated in memory; supervisor persists it on heartbeat.
	for len(p) > 0 {
		length := bytes.IndexByte(p, '\n')
		if length < 0 {
			length = len(p)
		}
		if !w.discarding && len(w.pending)+length <= maxProviderEventBytes {
			w.pending = append(w.pending, p[:length]...)
		} else {
			w.pending = nil
			w.discarding = true
			w.visibilityLost("Événement fournisseur trop volumineux ; chronométrage par outil suspendu")
		}
		if length == len(p) {
			break
		}
		if !w.discarding {
			w.line(w.pending)
		}
		w.discarding = false
		w.pending = nil
		p = p[length+1:]
	}
	return n, nil
}
func (w *outputSink) line(line []byte) {
	var data map[string]any
	decodeErr := json.Unmarshal(line, &data)
	if decodeErr != nil && bytes.HasPrefix(bytes.TrimSpace(line), []byte("{")) {
		w.visibilityLost("Événement JSON illisible ; chronométrage par outil suspendu")
	}
	if decodeErr == nil {
		if observed := providerReportedModel(data); observed != nil {
			w.reportedModel = observed
		}
		if c := observedProviderCooldown(data, time.Now()); c != nil {
			if w.s != nil && w.provider != "" {
				if e := w.s.recordProviderCooldown(w.provider, w.id, c); e != nil {
					w.cooldownError = e
				}
			}
			w.cooldown = c
			w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "provider-cooldown", Message: c.message()})
		}
		for _, message := range publicAgentMessages(data) {
			message = boundedLogMessage(message)
			if w.publicBytes+len(message) > 1<<20 {
				if !w.publicLimited {
					w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "output-limit", Message: "Messages limités à 1 Mio ; le suivi des actions continue"})
					w.publicLimited = true
				}
				continue
			}
			w.publicBytes += len(message)
			w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "message", Message: message})
		}
		if w.collectReply {
			if reply := providerReply(data); reply != "" {
				w.reply = reply
			}
		}
		if u := providerUsage(data); u != nil {
			w.usage = u
		}
		if w.guard != nil {
			beforeCalls, beforeResults := w.guard.calls, w.guard.completed
			w.guard.observe(data, time.Now())
			if w.guard.calls > beforeCalls {
				w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "activity", Message: fmt.Sprintf("%s · %s%s", w.guard.lastTool, w.guard.lastAction, operationTarget(w.guard.actionDetail))})
			}
			if w.guard.completed > beforeResults {
				w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "activity", Message: fmt.Sprintf("Résultat d'outil reçu · %d reçus · %d en attente", w.guard.completed, len(w.guard.pending))})
			}
		}
		kind, _ := data["type"].(string)
		switch kind {
		case "item.started", "item.completed":
			if item, ok := data["item"].(map[string]any); ok {
				if typ, ok := item["type"].(string); ok {
					w.activity = "Événement fournisseur : " + kind + " / " + terminalText(typ)
				}
			}
		case "assistant", "user", "result", "system", "thread.started", "turn.started", "turn.completed", "turn.failed":
			w.activity = "Événement fournisseur : " + kind
		}
	}
	if w.capture && !w.truncated {
		if w.bytes+len(line) > 1<<20 || w.lines >= 1000 {
			w.truncated = true
			w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "output-limit", Message: "Capture arrêtée à 1 Mio ou 1 000 lignes ; le processus continue"})
			return
		}
		w.bytes += len(line) + 1
		w.lines++
		w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "output", Message: boundedLogMessage(string(line))})
	}
}
func (w *outputSink) guardReason() string {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.cooldownError != nil {
		return "Impossible de conserver l’attente fournisseur : " + w.cooldownError.Error()
	}
	if w.cooldown != nil {
		return w.cooldown.message()
	}
	if w.guard == nil {
		return ""
	}
	return w.guard.check(time.Now())
}
func (w *outputSink) current() string {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.cooldown != nil {
		return w.cooldown.message()
	}
	if w.guard != nil && w.guard.calls > 0 {
		return fmt.Sprintf("%d appels · %d résultats · dernier outil : %s", w.guard.calls, w.guard.completed, w.guard.lastTool)
	}
	if w.guard != nil {
		output, _, _ := w.guard.monitoring(time.Now())
		if output == "silent" {
			return "Silence fournisseur observé ; vitalité indéterminée ; décision du responsable requise"
		}
	}
	return w.activity
}
func (w *outputSink) progress() AgentProgress {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.guard == nil {
		return AgentProgress{}
	}
	return w.guard.summary()
}
func (w *outputSink) diagnostic(agent, attempt string, stopReason ...string) AttemptDiagnostic {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.guard == nil {
		return AttemptDiagnostic{}
	}
	reason := ""
	if len(stopReason) > 0 {
		reason = stopReason[0]
	}
	return w.guard.diagnostic(agent, attempt, reason)
}
func (w *outputSink) visibilityLost(reason string) {
	if w.guard != nil {
		w.guard.loseVisibility(reason)
	}
	if !w.visibilityLogged {
		w.logs = append(w.logs, AgentLog{AgentID: w.id, At: now(), Kind: "monitoring", Message: reason + ". Durée totale et silence restent surveillés."})
		w.visibilityLogged = true
	}
}
func (w *outputSink) persist() error {
	w.mu.Lock()
	logs := w.logs
	w.logs = nil
	w.mu.Unlock()
	if len(logs) == 0 {
		return nil
	}
	return w.s.logBatch(w.id, logs)
}
func (w *outputSink) flush() error {
	w.mu.Lock()
	if len(w.pending) > 0 {
		if !w.discarding {
			w.line(w.pending)
		}
		w.discarding = false
		w.pending = nil
	}
	w.mu.Unlock()
	return w.persist()
}

func (s *Store) supervise(id string) error {
	a, e := s.agent(id)
	if e != nil {
		return e
	}
	// Claim and registration are one write: no SQL starting / JSON queued window.
	a.Status = "starting"
	a.Supervisor = os.Getpid()
	a.SupervisorStamp = processStamp(a.Supervisor)
	a.Heartbeat = now()
	body, e := json.Marshal(a)
	if e != nil {
		return e
	}
	result, e := s.db.Exec("UPDATE agents SET status='starting',body=? WHERE id=? AND status='queued'", body, id)
	if e != nil {
		return e
	}
	n, _ := result.RowsAffected()
	if n != 1 {
		return fmt.Errorf("session déjà prise en charge")
	}
	desired, e := s.desired(id)
	if e != nil {
		return e
	}
	if desired == "stop" {
		return s.finishAgent(a, "interrupted", "Lancement annulé avant démarrage", nil)
	}
	if e = s.providerCooldownGuard(a.Provider); e != nil {
		a.ProviderCooldown, _, _ = s.providerCooldown(a.Provider)
		a.StopKind = "provider_quota"
		return s.finishAgent(a, "failed", e.Error(), nil)
	}
	if a.Workflow != nil {
		if e = s.actionSkillsGuard(a.Workflow.Skills); e != nil {
			return s.finishAgent(a, "failed", e.Error(), nil)
		}
		if e = s.projectContextGuard(a.Workflow.Project, a.Role); e != nil {
			return s.finishAgent(a, "failed", e.Error(), nil)
		}
	}
	if e = s.projectMemoryGuard(a); e != nil {
		return s.finishAgent(a, "failed", e.Error(), nil)
	}
	if interactiveMode(a.Mode) {
		return s.superviseTerminal(a)
	}
	signals := make(chan os.Signal, 2)
	signal.Notify(signals, syscall.SIGTERM, syscall.SIGINT)
	defer signal.Stop(signals)
	if a.Role == "worker" {
		context, contextErr := s.workerRecoveryForAgent(a)
		if contextErr != nil {
			return s.finishAgent(a, "failed", "Contexte de reprise inaccessible : "+contextErr.Error(), nil)
		}
		if contextErr = appendAgentRecoveryContext(&a, context); contextErr != nil {
			return s.finishAgent(a, "failed", "Contexte de reprise refusé : "+contextErr.Error(), nil)
		}
		// The registered input must be durable before the provider can consume it.
		if contextErr = s.saveAgent(a); contextErr != nil {
			return s.finishAgent(a, "failed", "Enregistrement du contexte de reprise impossible : "+contextErr.Error(), nil)
		}
	}
	environment, args, cacheErr := s.workerLaunchEnvironment(a)
	if cacheErr != nil {
		return s.finishAgent(a, "failed", cacheErr.Error(), nil)
	}
	cmd := exec.Command(a.Command, args...)
	cmd.Dir = a.CWD
	cmd.Env = environment
	cmd.Stdin = strings.NewReader(a.Prompt)
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	limits, e := a.Limits.normalized()
	if e != nil {
		return s.finishAgent(a, "failed", e.Error(), nil)
	}
	sink := &outputSink{collectReply: a.Brainstorm, guard: newLoopGuard(limits), s: s, id: id, provider: a.Provider, capture: a.Capture, activity: "Processus actif ; aucune activité fournisseur reçue"}
	cmd.Stdout = sink
	cmd.Stderr = sink
	// Bound wait if an orphaned descendant keeps stdout/stderr open after parent exits.
	cmd.WaitDelay = 2 * time.Second
	if e = s.checkMemorySummaryBeforeStart(&a); e != nil {
		return s.finishAgent(a, "failed", e.Error(), nil)
	}
	if e = cmd.Start(); e != nil {
		return s.finishAgent(a, "failed", "Échec de lancement : "+e.Error(), nil)
	}
	a.Child = cmd.Process.Pid
	a.ChildStamp = processStamp(a.Child)
	a.Status = "running"
	a.Activity = "Processus démarré ; attente fournisseur"
	a.Heartbeat = now()
	if e = s.saveAgent(a); e != nil {
		_ = syscall.Kill(-a.Child, syscall.SIGKILL)
		_ = cmd.Wait()
		return e
	}
	_ = s.log(id, "lifecycle", "Processus fournisseur démarré")
	if limits.observing() {
		_ = s.log(id, "limits", "Mode observation autorisé : plafonds d’exécution désactivés ; compteurs conservés ; arrêt manuel disponible")
	}
	_ = s.log(id, "limits", fmt.Sprintf("Limites : durée %ds ; silence %ds ; outil observable %ds ; appels %d ; répétitions %d ; erreurs consécutives %d", a.Timeout, limits.SilenceSeconds, limits.ToolSeconds, limits.MaxToolCalls, limits.MaxRepeatedCalls, limits.MaxConsecutiveErrors))
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	tick := time.NewTicker(time.Second)
	defer tick.Stop()
	runStarted := time.Now()
	stopping := false
	forced := false
	var stopAt time.Time
	reason := ""
	requestStop := func(message, cause string) {
		if stopping {
			return
		}
		stopping = true
		stopAt = time.Now()
		reason = message
		a.StopKind = cause
		a.Status = "stopping"
		a.Activity = message + " ; arrêt en attente"
		_ = syscall.Kill(-a.Child, syscall.SIGTERM)
		_ = s.saveAgent(a)
		_ = s.log(id, "lifecycle", a.Activity)
	}
	for {
		select {
		case <-signals:
			requestStop("Interruption du superviseur", "superviseur")
		case e = <-done:
			// Clean any descendants of this owned process group before releasing workspace.
			_ = syscall.Kill(-a.Child, syscall.SIGKILL)
			if err := sink.flush(); err != nil {
				e = err
			}
			if !stopping {
				// A persisted operator stop wins the stop/result race. Process exit
				// still supplies the effective-end proof used below.
				if desiredNow, desiredErr := s.desired(id); desiredErr == nil && desiredNow == "stop" {
					stopping = true
					reason = "Arrêt demandé par opérateur"
					a.StopKind = "operateur"
				}
			}
			if !stopping {
				if decision, err := s.runStopRequest(a); err != nil {
					e = err
				} else if decision != "" {
					stopping, reason, a.StopKind = true, decision, "planning"
				}
			}
			if !stopping {
				if limitReason := sink.guardReason(); limitReason != "" {
					stopping = true
					reason = limitReason
					a.StopKind = "garde"
				}
			}
			a.ProviderCooldown = sink.cooldownSnapshot()
			if a.ProviderCooldown != nil {
				a.StopKind = "provider_quota"
				reason = a.ProviderCooldown.message()
				stopping = true
			}
			a.Progress = sink.progress()
			observeRunTime(&a, runStarted, time.Now())
			a.Diagnostic = sink.diagnostic(a.ID, a.Attempt, reason)
			a.Usage = sink.usageSnapshot()
			a.ReportedModel = sink.reportedModelSnapshot()
			a.Reply = sink.replySnapshot()
			code := cmd.ProcessState.ExitCode()
			state := "completed"
			message := "Processus terminé ; résultat à examiner, tâche non acceptée"
			if e != nil {
				state = "failed"
				message = "Processus en échec (code " + strconv.Itoa(code) + ") ; consulter les journaux"
			}
			if stopping {
				state = "interrupted"
				message = reason + " ; fin du processus confirmée"
			}
			return s.finishAgent(a, state, message, &code)
		case <-tick.C:
			if err := sink.persist(); err != nil {
				requestStop("Échec de persistance des journaux", "superviseur")
			}
			desired, e = s.desired(id)
			if e != nil {
				requestStop("Stockage du superviseur indisponible", "superviseur")
			}
			if desired == "stop" {
				requestStop("Arrêt demandé par opérateur", "operateur")
			}
			if reason := sink.guardReason(); reason != "" {
				requestStop(reason, "garde")
			}

			if stopping && time.Since(stopAt) > 3*time.Second && !forced {
				forced = true
				_ = syscall.Kill(-a.Child, syscall.SIGKILL)
				_ = s.log(id, "lifecycle", "Arrêt forcé après délai coopératif")
			}
			if !stopping {
				a.Activity = sink.current()
			}
			a.Progress = sink.progress()
			observeRunTime(&a, runStarted, time.Now())
			a.Diagnostic = sink.diagnostic(a.ID, a.Attempt)
			if !stopping {
				if decision, err := s.observeRun(a); err != nil {
					requestStop("Persistance de la supervision indisponible", "superviseur")
				} else if decision != "" {
					requestStop(decision, "planning")
				}
			}
			a.Diagnostic = sink.diagnostic(a.ID, a.Attempt)
			a.Usage = sink.usageSnapshot()
			a.ReportedModel = sink.reportedModelSnapshot()
			a.Reply = sink.replySnapshot()
			a.Heartbeat = now()
			if e = s.saveAgent(a); e != nil {
				requestStop("Échec de persistance", "superviseur")
			}
		}
	}
}

func (s *Store) reconcile(id string) error {
	a, e := s.agent(id)
	if e != nil {
		return e
	}
	if !activeAgent(a) {
		if e = s.reconcileProviderCooldown(&a); e != nil {
			return e
		}
		return s.settleAgentTask(a)
	}
	if cancellableQueuedAgent(a) {
		return s.cancelQueuedAgent(a)
	}
	if a.Host != hostIdentity() {
		return fmt.Errorf("hôte/redémarrage différent : vérifier les processus sur l'hôte d'origine ; aucune libération automatique")
	}
	if a.Supervisor > 0 && processStamp(a.Supervisor) == a.SupervisorStamp {
		return fmt.Errorf("superviseur encore présent")
	}
	if a.Status == "starting" && a.Child == 0 {
		return fmt.Errorf("lancement interrompu avant enregistrement PID : vérifier les processus manuellement, verrou conservé")
	}
	if a.Child > 0 {
		if e = syscall.Kill(-a.Child, 0); e == nil || e == syscall.EPERM {
			return fmt.Errorf("groupe de processus encore présent ; vérifier et arrêter sur l'hôte avant réconciliation")
		}
		if e != syscall.ESRCH {
			return e
		}
	}
	// CAS claim protects against a supervisor just starting an unclaimed intent.
	tx, e := s.db.Begin()
	if e != nil {
		return e
	}
	defer tx.Rollback()
	var body []byte
	var status string
	if e = tx.QueryRow("SELECT body,status FROM agents WHERE id=?", id).Scan(&body, &status); e != nil {
		return e
	}
	var latest Agent
	_ = json.Unmarshal(body, &latest)
	if latest.Supervisor != a.Supervisor || status != a.Status {
		return fmt.Errorf("état modifié : relire")
	}
	if _, e = tx.Exec("UPDATE agents SET status='interrupted' WHERE id=?", id); e != nil {
		return e
	}
	if e = tx.Commit(); e != nil {
		return e
	}
	return s.finishAgent(a, "interrupted", "Absence de superviseur et de groupe confirmée ; reprise explicite requise", nil)
}

func (s *Store) initProviders() error {
	path := filepath.Join(s.root, ".swarm", "providers.json")
	p := Providers{Schema: 1, Providers: map[string]Provider{}}
	for name, args := range map[string][]string{"claude": {"-p", "--output-format", "stream-json", "--verbose"}, "codex": {"exec", "--json", "--sandbox", "workspace-write", "-"}} {
		command, e := exec.LookPath(name)
		if e != nil {
			continue
		}
		command, e = filepath.Abs(command)
		if e != nil {
			return e
		}
		// Les CLI connues n'offrent pas actuellement de sonde déterministe de
		// leur sandbox effectif. Le profil reste compatible mais explicitement
		// non vérifié jusqu'à configuration d'un adaptateur provider-context.
		p.Providers[name] = Provider{Command: command, Args: args, Env: []string{}}
	}
	b, _ := json.MarshalIndent(p, "", "  ")
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(b)
	return e
}

// Keep io imported as an explicit compile-time contract for the bounded sink.
var _ io.Writer = (*outputSink)(nil)

func (w *outputSink) usageSnapshot() *Usage {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.usage == nil {
		return nil
	}
	u := *w.usage
	return &u
}

func (w *outputSink) replySnapshot() string { w.mu.Lock(); defer w.mu.Unlock(); return w.reply }

func (w *outputSink) cooldownSnapshot() *ProviderCooldown {
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.cooldown == nil {
		return nil
	}
	c := *w.cooldown
	return &c
}
