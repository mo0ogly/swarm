//go:build linux

package engine

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"
	"unicode/utf8"
)

// A transport plan is not an independent review. Keep it separate from
// managedReviewBatch: existing acceptance code must never treat an inspection
// packet as a complete verdict on a task.
type managedReviewFragmentArtifact struct {
	Kind    string `json:"kind"`
	Name    string `json:"name"`
	Digest  string `json:"sha256"`
	Content string `json:"content"`
}
type managedReviewFragmentPacket struct {
	InspectionContractVersion     int                             `json:"inspection_contract_version,omitempty"`
	Scope                         *managedReviewInspectionScope   `json:"scope,omitempty"`
	DefectCitationContractVersion int                             `json:"defect_citation_contract_version,omitempty"`
	FindingContractVersion        int                             `json:"finding_contract_version,omitempty"`
	LotContract                   *ReviewCoordinationLot          `json:"lot_contract,omitempty"`
	LotCriteria                   map[string]string               `json:"lot_criteria,omitempty"`
	Lot                           string                          `json:"lot,omitempty"`
	InputBudget                   *managedReviewInputBudget       `json:"input_budget,omitempty"`
	Version                       int                             `json:"version"`
	Candidate                     string                          `json:"candidate_commit"`
	ContextDigest                 string                          `json:"context_sha256"`
	Index                         int                             `json:"index"`
	Artifacts                     []managedReviewFragmentArtifact `json:"artifacts"`
}
type managedReviewFragmentPlan struct {
	Coordination       *ReviewCoordinationProposal   `json:"coordination,omitempty"`
	CoordinationFiles  []string                      `json:"coordination_files,omitempty"`
	InputBudget        *managedReviewInputBudget     `json:"input_budget,omitempty"`
	Version            int                           `json:"version"`
	ContextDigest      string                        `json:"context_sha256"`
	Candidate          string                        `json:"candidate_commit"`
	Packets            []managedReviewFragmentPacket `json:"packets"`
	ReservedFinalCalls int                           `json:"reserved_final_calls"`
	AvailableCalls     int                           `json:"available_calls"`
	Executable         bool                          `json:"executable"`
	Reused             []managedFragmentReuse        `json:"historical_observations,omitempty"`
	ChangeDiff         string                        `json:"changes_since_observations,omitempty"`
}

const managedFragmentPromptReserve = 24 * 1024

func managedFragmentArtifacts(c managedReviewContext) ([]managedReviewFragmentArtifact, error) {
	if c.CitationContractVersion != 0 && c.CitationContractVersion != 1 && c.CitationContractVersion != 2 {
		return nil, fmt.Errorf("version de contrat de citation finale inconnue")
	}
	if c.InspectionScopeVersion != 0 && c.InspectionScopeVersion != 1 {
		return nil, fmt.Errorf("version de périmètre d’inspection inconnue")
	}
	if c.Candidate == "" || len(c.Tasks) == 0 || !strings.HasPrefix(c.Diff, "diff --git ") || !utf8.ValidString(c.Diff) || managedDiffHasBinary(c.Diff) {
		return nil, fmt.Errorf("contexte de fragments incomplet ou diff non textuel")
	}
	if c.Baseline != nil && !supportedManagedReviewBaseline(c.Baseline.Version) {
		return nil, fmt.Errorf("version de base acceptée non prise en charge")
	}
	artifacts := []managedReviewFragmentArtifact{}
	appendArtifact := func(kind, name, content string) {
		artifacts = append(artifacts, managedReviewFragmentArtifact{kind, name, hash([]byte(content)), content})
	}
	// Split at file headers, retaining the original separator and all bytes.
	remainder := c.Diff
	seen := map[string]bool{}
	for remainder != "" {
		end := strings.Index(remainder[1:], "\ndiff --git ")
		section := remainder
		if end >= 0 {
			end += 2
			section = remainder[:end]
			remainder = remainder[end:]
		} else {
			remainder = ""
		}
		name := strings.SplitN(section, "\n", 2)[0]
		if seen[name] {
			return nil, fmt.Errorf("section de diff dupliquée")
		}
		seen[name] = true
		appendArtifact("diff", name, section)
	}
	// Everything except diff and supplemental contents is retained as canonical
	// metadata, including reports, deliveries, receipts and accepted baselines.
	metadata := c
	metadata.Diff = ""
	metadata.Sources = nil
	raw, err := json.Marshal(metadata)
	if err != nil {
		return nil, err
	}
	appendArtifact("context", "contracts-reports-controls-baseline", string(raw))
	seen = map[string]bool{}
	for _, source := range c.Sources {
		if source.Path == "" || seen[source.Path] || !utf8.ValidString(source.Content) || source.Bytes != len(source.Content) || source.Digest != hash([]byte(source.Content)) {
			return nil, fmt.Errorf("source annexe incohérente")
		}
		seen[source.Path] = true
		raw, err = json.Marshal(source)
		if err != nil {
			return nil, err
		}
		appendArtifact("source", source.Path, string(raw))
	}
	return artifacts, nil
}

// All canonical evidence is included, not only the diff. No disk/Store write,
// provider call, budget reservation or publication is performed by this plan.
func planManagedReviewFragments(c managedReviewContext, available, finalCalls int) (managedReviewFragmentPlan, error) {
	empty := managedReviewFragmentPlan{}
	if finalCalls < 1 || available <= finalCalls {
		return empty, fmt.Errorf("budget de revue finale absent")
	}
	artifacts, err := managedFragmentArtifacts(c)
	if err != nil {
		return empty, err
	}
	plan, err := packManagedFragmentArtifacts(c, artifacts, available, finalCalls)
	if err != nil {
		return empty, err
	}
	if err = validateManagedReviewFragments(c, plan); err != nil {
		return empty, err
	}
	return plan, nil
}

func packManagedFragmentArtifacts(c managedReviewContext, artifacts []managedReviewFragmentArtifact, available, finalCalls int) (managedReviewFragmentPlan, error) {
	return packManagedFragmentArtifactsWithLot(c, artifacts, available, finalCalls, "", nil, nil)
}
func packManagedFragmentArtifactsWithLot(c managedReviewContext, artifacts []managedReviewFragmentArtifact, available, finalCalls int, lot string, contract *ReviewCoordinationLot, criteria map[string]string) (managedReviewFragmentPlan, error) {
	empty := managedReviewFragmentPlan{}
	canonical, _ := json.Marshal(c)
	plan := managedReviewFragmentPlan{Version: 2, ContextDigest: hash(canonical), Candidate: c.Candidate, AvailableCalls: available, ReservedFinalCalls: finalCalls}
	packet := managedReviewFragmentPacket{InspectionContractVersion: managedFragmentInspectionContractVersion, Scope: managedFragmentScope(c), DefectCitationContractVersion: managedFragmentDefectCitationContractVersion, FindingContractVersion: managedFragmentFindingContractVersion, Lot: lot, LotContract: contract, LotCriteria: criteria, Version: 2, Candidate: c.Candidate, ContextDigest: plan.ContextDigest, Index: 0}
	// New plans reserve workflow space in addition to the variable schema and
	// anchor table. Historical packets keep their original validation contract.
	fits := func(p managedReviewFragmentPacket) bool {
		raw, e := json.Marshal(p)
		return e == nil && len(raw)+managedFragmentPromptReserve+len(managedFragmentPacketSchema(p))+len(managedFragmentAnchorsJSON(p)) <= managedReviewPromptLimit && managedFragmentReplyFits(p)
	}
	for _, artifact := range artifacts {
		next := packet
		next.Artifacts = append(append([]managedReviewFragmentArtifact(nil), packet.Artifacts...), artifact)
		if !fits(next) {
			if len(packet.Artifacts) == 0 {
				return empty, &managedFragmentLegacyCapacityError{Name: artifact.Name}
			}
			plan.Packets = append(plan.Packets, packet)
			packet = managedReviewFragmentPacket{InspectionContractVersion: managedFragmentInspectionContractVersion, Scope: managedFragmentScope(c), DefectCitationContractVersion: managedFragmentDefectCitationContractVersion, FindingContractVersion: managedFragmentFindingContractVersion, Lot: lot, LotContract: contract, LotCriteria: criteria, Version: 2, Candidate: c.Candidate, ContextDigest: plan.ContextDigest, Index: len(plan.Packets), Artifacts: []managedReviewFragmentArtifact{artifact}}
			if !fits(packet) {
				return empty, &managedFragmentLegacyCapacityError{Name: artifact.Name}
			}
		} else {
			packet = next
		}
	}
	if len(packet.Artifacts) > 0 {
		plan.Packets = append(plan.Packets, packet)
	}
	if len(plan.Packets)+finalCalls > available {
		return empty, fmt.Errorf("budget insuffisant : %d inspections et %d appels finaux pour %d disponibles", len(plan.Packets), finalCalls, available)
	}
	return plan, nil
}

func validateManagedReviewFragments(c managedReviewContext, p managedReviewFragmentPlan) error {
	canonical, err := json.Marshal(c)
	if err != nil {
		return err
	}
	if (p.Version != 1 && p.Version != 2 && p.Version != 3 && p.Version != 4) || p.Executable || p.Candidate != c.Candidate || p.ContextDigest != hash(canonical) || p.ReservedFinalCalls < 1 || len(p.Packets) == 0 || fragmentPaidInspections(p)+p.ReservedFinalCalls > p.AvailableCalls {
		return fmt.Errorf("plan de fragments périmé ou incohérent")
	}
	if err := validateFragmentInputBudget(p.Version, p.InputBudget); err != nil {
		return err
	}
	expected, err := managedFragmentArtifacts(c)
	if err != nil {
		return err
	}
	actual := []managedReviewFragmentArtifact{}
	for i, packet := range p.Packets {
		raw, err := json.Marshal(packet)
		if err != nil || !supportedFragmentInspectionContract(packet.InspectionContractVersion) || !reflect.DeepEqual(packet.Scope, managedFragmentScope(c)) || !supportedFragmentDefectCitationContract(packet.DefectCitationContractVersion) || !supportedFragmentFindingContract(packet.FindingContractVersion) || packet.Version != p.Version || packet.Index != i || packet.Candidate != p.Candidate || packet.ContextDigest != p.ContextDigest || len(packet.Artifacts) == 0 || (p.Version < 4 && len(raw)+managedFragmentPromptReserve > managedReviewPromptLimit) || !reflect.DeepEqual(packet.InputBudget, p.InputBudget) {
			return fmt.Errorf("paquet de revue modifié ou trop grand")
		}
		// Structural rechecks run inside journal/cancellation checks. Count the
		// complete prompt at preflight and immediately before each paid call,
		// not on every immutable-journal poll (which would tokenize megabytes).
		if p.Version == 4 && len(raw) > p.InputBudget.MaxBytes {
			return fmt.Errorf("paquet dépasse le plafond mémoire ancré")
		}
		actual = append(actual, packet.Artifacts...)
	}
	if p.Coordination != nil {
		return validateCoordinatedFragmentCoverage(c, p)
	}
	if len(p.CoordinationFiles) > 0 {
		return fmt.Errorf("périmètre coordonné sans plan")
	}
	for _, packet := range p.Packets {
		if packet.Lot != "" || packet.LotContract != nil || len(packet.LotCriteria) > 0 {
			return fmt.Errorf("lot sans plan")
		}
	}
	if p.Version == 3 || (p.Version == 4 && len(p.Reused) > 0) {
		return validateFragmentReuseCoverage(c, p, actual, expected)
	}
	if len(p.Reused) > 0 || p.ChangeDiff != "" {
		return fmt.Errorf("historical observations require protocol3")
	}
	if !reflect.DeepEqual(actual, expected) {
		return fmt.Errorf("couverture des preuves incomplète ou modifiée")
	}
	return nil
}
