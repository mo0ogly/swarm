//go:build linux

package engine

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// A preparation is a durable operation, not a new attempt. It is never adopted
// by another request. An explicit resume reuses its identity and saved settings.
func taskForPreparation(w Work, id string) *Task {
	t, _ := w.task(id)
	return t
}

func managedPreparationContract(w Work, t *Task) string {
	if t == nil || w.Planning == nil || w.Planning.Repository == nil {
		return ""
	}
	data, _ := json.Marshal([]any{w.Objective, w.Scope, t.ID, t.Title, t.Deliverable,
		t.Criteria, t.Depends, t.Next, t.ScopeID, t.Requirements, t.PlanRole,
		t.PlanMaxAttempts, t.PlanToolLimit, t.ValidationPolicy, t.Profile,
		len(t.Attempts), w.Planning.Repository.Candidate})
	return hash(data)
}

func preparedRequestDigest(r Launch) string {
	r.SkillRefresh = nil // Receipt records authorization, not a frozen setting.
	r.Revision, r.EventID, r.Origin, r.ConductorID, r.ProviderDigest = 0, "", "", "", ""
	if r.Role == "" {
		r.Role = "worker"
	}
	if r.Timeout == 0 {
		r.Timeout = 1800
	}
	b, _ := json.Marshal(r)
	return hash(b)
}

// Resumption may lower an explicit tool budget; all other frozen settings stay exact.
func preparedRequestCompatible(saved, requested Launch) bool {
	if requested.preparedSkillRefresh {
		if !samePreparedSkillPaths(saved.Skills, requested.Skills) {
			return false
		}
		saved.Skills = requested.Skills
	}
	if preparedRequestDigest(saved) == preparedRequestDigest(requested) {
		return true
	}
	if saved.Limits == nil || requested.Limits == nil || requested.Limits.MaxToolCalls < 1 || requested.Limits.MaxToolCalls >= saved.Limits.MaxToolCalls {
		return false
	}
	limits := *saved.Limits
	limits.MaxToolCalls = requested.Limits.MaxToolCalls
	saved.Limits = &limits
	return preparedRequestDigest(saved) == preparedRequestDigest(requested)
}

func (s *Store) readPreparedLaunch(w Work, id string) (ManagedAttempt, error) {
	var record ManagedAttempt
	if !safeName(id) || w.Planning == nil || w.Planning.Repository == nil {
		return record, fmt.Errorf("préparation de lancement inconnue")
	}
	repo := w.Planning.Repository
	rel, e := filepath.Rel(s.root, filepath.Join(repo.Storage, "copy-"+id+".json"))
	if e != nil {
		return record, e
	}
	path, e := localFile(s.root, rel)
	if e != nil {
		return record, e
	}
	st, e := os.Stat(path)
	if e != nil {
		return record, e
	}
	if st.Size() > 128*1024 {
		return record, fmt.Errorf("préparation de lancement trop grande")
	}
	b, e := os.ReadFile(path)
	if e != nil {
		return record, e
	}
	if e = strict(b, &record); e != nil {
		return record, e
	}
	if record.Agent != id || record.Work != w.ID || record.Task == "" || record.State != "ready" {
		return record, fmt.Errorf("attribution de préparation incohérente")
	}
	return record, nil
}

func (s *Store) preparedLaunchForTask(w Work, t *Task) (*PreparedLaunch, error) {
	if w.Planning == nil || w.Planning.Repository == nil {
		return nil, nil
	}
	var id string
	e := s.db.QueryRow(`SELECT m.agent_id FROM managed_attempts m
	 WHERE m.work_id=? AND m.task_id=? AND m.state='ready'
	 AND NOT EXISTS(SELECT 1 FROM agents a WHERE a.id=m.agent_id)
	 ORDER BY m.rowid DESC LIMIT 1`, w.ID, t.ID).Scan(&id)
	if e == sql.ErrNoRows {
		// A crash can occur after the filesystem checkpoint but before SQL.
		id, e = s.preparedManifestForTask(w, t)
		if e != nil || id == "" {
			return nil, e
		}
	}
	if e != nil {
		return nil, e
	}
	p := &PreparedLaunch{ID: id, Task: t.ID}
	record, e := s.readPreparedLaunch(w, id)
	if e != nil {
		p.Reason = "Préparation illisible ; copie conservée : " + e.Error()
		return p, nil
	}
	if e = s.preparedLaunchGuard(w, t, record); e != nil {
		p.Reason = e.Error()
		return p, nil
	}
	r := record.Request
	p.Provider, p.Workspace, p.Instruction, p.Timeout, p.Limits = r.Provider, filepath.Join(record.Path, w.Planning.Repository.Subdir), r.Instruction, r.Timeout, r.Limits
	for _, selected := range r.Skills {
		item, _, err := s.readActionSkill(selected.Path)
		if err != nil || selected.SHA256 == "" || item.SHA256 != selected.SHA256 {
			p.Reason = "Skill préparé modifié : examiner son empreinte actuelle puis confirmer explicitement l’actualisation avec agent resume-launch."
			return p, nil
		}
	}
	p.Ready = true
	return p, nil
}

func (s *Store) preparedLaunchGuard(w Work, t *Task, record ManagedAttempt) error {
	if record.Request == nil || record.PreparationContract == "" {
		return &CommandError{Code: "prepared_launch_legacy", Message: "Préparation ancienne sans paramètres sauvegardés : conserver la copie et reprendre uniquement avec la demande initiale identifiée."}
	}
	r := record.Request
	if r.EventID != record.Agent || r.TaskID != t.ID || record.Task != t.ID || record.Work != w.ID || r.Schema != 1 {
		return fmt.Errorf("paramètres de préparation incohérents")
	}
	if !s.preparedContractMatches(w, t, record) || record.Path != managedCopyRoot(w.Planning.Repository, t.ID, len(t.Attempts)+1) {
		return &CommandError{Code: "prepared_launch_changed", Message: "La tâche ou sa révision Git a changé depuis la préparation. Reprise refusée ; copie conservée pour examen."}
	}
	return verifyManagedCopy(w.Planning.Repository, record.Path)
}

func (s *Store) resumePreparedLaunch(work, id string, revision int, refresh ...PreparedSkillRefresh) (Agent, bool, error) {
	return s.resumePreparedLaunchAs(work, id, revision, originOperator, "", refresh...)
}

// Only the current conductor may resume its previously authorized automatic
// intent. Operator preparations retain the explicit public resume path.
func (s *Store) resumeAutomaticPreparedLaunch(work, id string, revision int, conductor string) (Agent, bool, error) {
	if !safeName(conductor) {
		return Agent{}, false, fmt.Errorf("conducteur courant identifié requis pour reprendre la préparation automatique")
	}
	w, err := s.get(work)
	if err != nil {
		return Agent{}, false, err
	}
	record, err := s.readPreparedLaunch(w, id)
	if err != nil {
		return Agent{}, false, err
	}
	if record.Request == nil || record.Request.Origin != originConductor || !safeName(record.Request.ConductorID) {
		return Agent{}, false, fmt.Errorf("préparation opérateur ou intention automatique non attribuable ; reprise explicite requise")
	}
	return s.resumePreparedLaunchAs(work, id, revision, originConductor, conductor)
}

func (s *Store) resumePreparedLaunchAs(work, id string, revision int, origin, conductor string, refresh ...PreparedSkillRefresh) (Agent, bool, error) {
	if !safeName(id) {
		return Agent{}, false, fmt.Errorf("identifiant de préparation invalide")
	}
	// A lost response or a double click can only retrieve the original agent.
	if a, e := s.agent(id); e == nil {
		if a.WorkID != work {
			return Agent{}, false, fmt.Errorf("préparation hors mission")
		}
		w, err := s.get(work)
		if err != nil {
			return Agent{}, false, err
		}
		record, err := s.readPreparedLaunch(w, id)
		if err != nil {
			return Agent{}, false, err
		}
		bound, err := s.managedAttempt(id)
		if err != nil {
			return Agent{}, false, err
		}
		expected, expectedErr := canonicalOwnedProjectPath(s.root, filepath.Join(record.Path, w.Planning.Repository.Subdir))
		actual, actualErr := canonicalOwnedProjectPath(s.root, a.CWD)
		if record.Request == nil || record.Request.Schema != 1 || record.PreparationContract == "" || a.Attempt != "a-"+hash([]byte(work + "|" + id))[:24] || record.Request.EventID != id || record.Request.TaskID != a.TaskID || record.Task != a.TaskID || bound.Agent != a.ID || bound.Work != work || bound.Task != a.TaskID || bound.Path != record.Path || bound.Base != record.Base || expectedErr != nil || actualErr != nil || actual != expected {
			return Agent{}, false, fmt.Errorf("agent sans attribution à cette préparation")
		}
		task, err := w.task(a.TaskID)
		if err != nil {
			return Agent{}, false, err
		}
		for _, attempt := range task.Attempts {
			if a.Attempt != "" && attempt.ID == a.Attempt {
				return a, false, nil
			}
		}
		return Agent{}, false, fmt.Errorf("tentative sans attribution à cette préparation")
	} else if e != sql.ErrNoRows {
		return Agent{}, false, e
	}
	w, e := s.get(work)
	if e != nil {
		return Agent{}, false, e
	}
	if w.Revision != revision {
		return Agent{}, false, &CommandError{Code: "revision_conflict", Message: "Le travail a changé ; actualiser puis confirmer.", Retryable: true}
	}
	record, e := s.readPreparedLaunch(w, id)
	if e != nil {
		return Agent{}, false, e
	}
	t, e := w.task(record.Task)
	if e != nil {
		return Agent{}, false, e
	}
	if e = s.preparedLaunchGuard(w, t, record); e != nil {
		return Agent{}, false, e
	}
	r := *record.Request
	if len(refresh) > 1 {
		return Agent{}, false, fmt.Errorf("une seule actualisation de skills autorisée")
	}
	if len(refresh) == 1 {
		r, e = s.refreshPreparedSkills(r, refresh[0])
		if e != nil {
			return Agent{}, false, e
		}
	}
	r.Revision, r.Origin, r.ConductorID = revision, origin, conductor
	// An explicit resume retains the reservation while respecting the provider ceiling.
	// Never change the saved manifest or the task profile, nor raise a smaller budget.
	if r.Limits != nil {
		providers, err := s.providers()
		if err != nil {
			return Agent{}, false, err
		}
		provider, ok := providers.Providers[r.Provider]
		if !ok {
			return Agent{}, false, fmt.Errorf("fournisseur inconnu : %s", r.Provider)
		}
		ceiling, err := provider.Limits.normalized()
		if err != nil {
			return Agent{}, false, err
		}
		if r.Limits.MaxToolCalls > ceiling.MaxToolCalls {
			limits := *r.Limits
			limits.MaxToolCalls = ceiling.MaxToolCalls
			r.Limits = &limits
		}
	}
	// All provider, dependency, review, budget and concurrency guards run again.
	return s.prepare(work, r)
}

func (s *Store) preparedManifestForTask(w Work, t *Task) (string, error) {
	entries, e := os.ReadDir(w.Planning.Repository.Storage)
	if e != nil {
		return "", e
	}
	found := ""
	for _, entry := range entries {
		name := entry.Name()
		if !strings.HasPrefix(name, "copy-") || !strings.HasSuffix(name, ".json") {
			continue
		}
		id := strings.TrimSuffix(strings.TrimPrefix(name, "copy-"), ".json")
		record, e := s.readPreparedLaunch(w, id)
		if e != nil || record.Task != t.ID || record.Path != managedCopyRoot(w.Planning.Repository, t.ID, len(t.Attempts)+1) {
			continue
		}
		if _, e = s.agent(id); e == nil {
			continue
		} else if e != sql.ErrNoRows {
			return "", e
		}
		if found != "" {
			return "", fmt.Errorf("plusieurs préparations attribuées à la même copie ; examen requis")
		}
		found = id
	}
	return found, nil
}

// Requalification can create a new commit with byte-identical content. Bind all
// other preparation inputs exactly and verify both Git trees before reuse.
func (s *Store) preparedContractMatches(w Work, t *Task, record ManagedAttempt) bool {
	if t == nil || w.Planning == nil || w.Planning.Repository == nil {
		return false
	}
	if record.Base == w.Planning.Repository.Candidate {
		return record.PreparationContract == managedPreparationContract(w, t)
	}
	planning := *w.Planning
	repo := *planning.Repository
	current := repo.Candidate
	repo.Candidate = record.Base
	planning.Repository = &repo
	w.Planning = &planning
	if record.PreparationContract != managedPreparationContract(w, t) {
		return false
	}
	bare := filepath.Join(repo.Storage, "repository.git")
	oldTree, e := managedGit(bare, "rev-parse", "--verify", record.Base+"^{tree}")
	if e != nil {
		return false
	}
	currentTree, e := managedGit(bare, "rev-parse", "--verify", current+"^{tree}")
	return e == nil && oldTree != "" && oldTree == currentTree
}
