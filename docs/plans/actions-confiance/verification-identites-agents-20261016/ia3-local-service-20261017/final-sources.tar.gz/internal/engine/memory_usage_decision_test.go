//go:build linux

package engine

import (
	"encoding/json"
	"errors"
	"path/filepath"
	"reflect"
	"slices"
	"testing"
	"time"
)

func TestMemoryUsageResourceSnapshotTaskBoundary(t *testing.T) {
	root, w, r, target := memoryUsageFixture(t)
	before, err := memorySummaryUsageBinding(root, w, r, target)
	if err != nil {
		t.Fatal(err)
	}
	r.TaskID = "other"
	target.Task = "other"
	refreshMemoryUsageSelection(t, root, w, &r)
	after, err := memorySummaryUsageBinding(root, w, r, target)
	if err != nil {
		t.Fatal(err)
	}
	if before.projection.Sources[0].Resource == after.projection.Sources[0].Resource {
		t.Fatal("different task snapshots alias the same exact memory resource")
	}
	for i := 1; i < len(before.projection.Sources); i++ {
		if before.projection.Sources[i].Resource != after.projection.Sources[i].Resource {
			t.Fatal("same original dialogue was incorrectly scoped to the recipient task")
		}
	}
}

type memoryDecisionFixture struct {
	root   string
	work   Work
	launch Launch
	target memoryUsageTarget
	ids    memoryUsageDecisionIDs
	frame  memoryUsageFrame
}

func memoryDecisionSetup(t *testing.T) memoryDecisionFixture {
	t.Helper()
	root, w, r, target := memoryUsageFixture(t)
	b, err := memorySummaryUsageBinding(root, w, r, target)
	if err != nil {
		t.Fatal(err)
	}
	requests, err := b.requests("decision-event", "reader-grant")
	if err != nil {
		t.Fatal(err)
	}
	snapshot, authority, requester, at := memoryUsageAuthority(t, root, b, requests)
	rights := []agentIdentityPermission{}
	for _, source := range b.projection.Sources {
		if source.Transmit {
			rights = append(rights, agentIdentityPermission{"memory.read", source.Resource})
		}
	}
	recipient := agentIdentityGrant{ID: "recipient-grant", Issuer: requester.actor, Holder: target.Recipient, Scope: target.Scope, TrustRevision: requester.trustRevision,
		Permissions: rights, NotBefore: at.Add(-time.Minute), ExpiresAt: at.Add(30 * time.Second)}
	snapshot.Grants[recipient.ID] = recipient
	snapshot.Instances[target.Recipient.InstanceID] = agentIdentityInstance{ID: target.Recipient.InstanceID, LogicalAgentID: "receiver-logical", Principal: target.Recipient.Principal, Scope: target.Scope, GrantID: recipient.ID, BindingID: "recipient-channel"}
	authority.roots[recipient.ID] = true
	f := memoryDecisionFixture{root, w, r, target, memoryUsageDecisionIDs{"decision-event", "reader-grant", "recipient-grant"},
		memoryUsageFrame{snapshot, authority, requester, agentIdentityCaller{projectRoot: root, actor: target.Recipient, trustRevision: requester.trustRevision, bindingID: "recipient-channel", verifiedAt: at}, at}}
	f.refresh(t)
	return f
}

func (f *memoryDecisionFixture) refresh(t *testing.T) {
	t.Helper()
	digest, err := agentIdentityDigest(f.frame.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	f.frame.authority.snapshotDigest = digest
	f.frame.authority.snapshotRevision = f.frame.snapshot.Revision
}

func (f memoryDecisionFixture) clone(t *testing.T) memoryDecisionFixture {
	t.Helper()
	f.work, f.launch = memoryUsageClone(t, f.work, f.launch)
	raw, err := json.Marshal(f.frame.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	f.frame.snapshot = agentIdentitySnapshot{}
	if err = json.Unmarshal(raw, &f.frame.snapshot); err != nil {
		t.Fatal(err)
	}
	roots := map[string]bool{}
	for id, v := range f.frame.authority.roots {
		roots[id] = v
	}
	f.frame.authority.roots = roots
	return f
}

func (f memoryDecisionFixture) evaluate(previous *memoryUsageDecision) (memoryUsageDecision, error) {
	return evaluateMemorySummaryUsage(f.root, f.work, f.launch, f.target, f.ids, f.frame, previous)
}

func requireMemoryDecisionRefusal(t *testing.T, got memoryUsageDecision, err error, code string) {
	t.Helper()
	if err == nil || !reflect.DeepEqual(got, memoryUsageDecision{}) {
		t.Fatal("refusal exposed a full or partial decision", err)
	}
	if code != "" {
		var actual *CommandError
		if !errors.As(err, &actual) || actual.Code != code {
			t.Fatalf("want refusal %s, got %v", code, err)
		}
	}
}

func TestMemoryUsageDecisionChecksBothActorsBeforeReturning(t *testing.T) {
	f := memoryDecisionSetup(t)
	before := f.clone(t)
	got, err := f.evaluate(nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(got.requester) != 13 || len(got.recipient) != 3 {
		t.Fatal("wrong complete decision shape")
	}
	if !got.expiresAt.Equal(f.frame.at.Add(30 * time.Second)) {
		t.Fatal("aggregate outlived the recipient grant")
	}
	events := map[string]bool{}
	for _, decision := range append(slices.Clone(got.requester), got.recipient...) {
		if events[decision.EventID] {
			t.Fatal("requester and recipient events alias")
		}
		events[decision.EventID] = true
	}
	for _, decision := range got.recipient {
		if decision.Actor != f.target.Recipient {
			t.Fatal("recipient decision lost actual actor")
		}
	}
	if !reflect.DeepEqual(f, before) {
		t.Fatal("evaluation mutated its input frame, Work or launch")
	}
	again, err := f.evaluate(&got)
	if err != nil || !reflect.DeepEqual(got, again) {
		t.Fatal("exact current reuse failed", err)
	}
}

func TestMemoryUsageDecisionRejectsEveryIncompleteAuthority(t *testing.T) {
	base := memoryDecisionSetup(t)
	previous, err := base.evaluate(nil)
	if err != nil {
		t.Fatal(err)
	}
	changeGrant := func(f *memoryDecisionFixture, id string, change func(*agentIdentityGrant)) {
		g := f.frame.snapshot.Grants[id]
		change(&g)
		f.frame.snapshot.Grants[id] = g
	}
	cases := []struct {
		name, code string
		change     func(*memoryDecisionFixture)
		unanchored bool
	}{
		{"last-requester-right", "agent_identity_permission_denied", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.requesterGrant, func(g *agentIdentityGrant) { g.Permissions = g.Permissions[:len(g.Permissions)-1] })
		}, false},
		{"last-recipient-right", "agent_identity_permission_denied", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.recipientGrant, func(g *agentIdentityGrant) { g.Permissions = g.Permissions[:len(g.Permissions)-1] })
		}, false},
		{"missing-recipient-caller", "memory_usage_recipient_mismatch", func(f *memoryDecisionFixture) { f.frame.recipient = agentIdentityCaller{} }, false},
		{"other-recipient-subject", "memory_usage_recipient_mismatch", func(f *memoryDecisionFixture) { f.frame.recipient.actor.Principal.Subject = "another-subject" }, false},
		{"other-recipient-instance", "memory_usage_recipient_mismatch", func(f *memoryDecisionFixture) { f.frame.recipient.actor.InstanceID = "another-instance" }, false},
		{"missing-recipient-channel", "agent_identity_binding_mismatch", func(f *memoryDecisionFixture) { f.frame.recipient.bindingID = "" }, false},
		{"unregistered-recipient", "agent_identity_binding_mismatch", func(f *memoryDecisionFixture) { delete(f.frame.snapshot.Instances, f.target.Recipient.InstanceID) }, false},
		{"revoked-recipient-instance", "agent_identity_binding_mismatch", func(f *memoryDecisionFixture) {
			i := f.frame.snapshot.Instances[f.target.Recipient.InstanceID]
			i.RevokedAt = &f.frame.at
			f.frame.snapshot.Instances[i.ID] = i
		}, false},
		{"revoked-recipient-grant", "agent_identity_grant_inactive", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.recipientGrant, func(g *agentIdentityGrant) { g.RevokedAt = &f.frame.at })
		}, false},
		{"expired-recipient-grant", "agent_identity_grant_inactive", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.recipientGrant, func(g *agentIdentityGrant) { g.ExpiresAt = f.frame.at })
		}, false},
		{"revoked-requester-grant", "agent_identity_grant_inactive", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.requesterGrant, func(g *agentIdentityGrant) { g.RevokedAt = &f.frame.at })
		}, false},
		{"stale-requester", "agent_identity_caller_stale", func(f *memoryDecisionFixture) { f.frame.requester.verifiedAt = f.frame.at.Add(-time.Second) }, false},
		{"stale-recipient", "agent_identity_caller_stale", func(f *memoryDecisionFixture) { f.frame.recipient.verifiedAt = f.frame.at.Add(-time.Second) }, false},
		{"expired-recipient-caller", "agent_identity_caller_stale", func(f *memoryDecisionFixture) { f.frame.recipient.expiresAt = &f.frame.at }, false},
		{"invalid-event", "memory_usage_binding_invalid", func(f *memoryDecisionFixture) { f.ids.eventID = "" }, false},
		{"missing-recipient-grant", "memory_usage_binding_invalid", func(f *memoryDecisionFixture) { f.ids.recipientGrant = "" }, false},
		{"foreign-control-project", "memory_usage_project_mismatch", func(f *memoryDecisionFixture) { f.frame.authority.projectRoot = filepath.Join(f.root, "other-project") }, false},
		{"missing-clock", "agent_identity_clock_required", func(f *memoryDecisionFixture) { f.frame.at = time.Time{} }, false},
		{"unanchored-snapshot", "agent_identity_snapshot_changed", func(f *memoryDecisionFixture) {
			changeGrant(f, f.ids.requesterGrant, func(g *agentIdentityGrant) {
				g.Permissions = append(g.Permissions, agentIdentityPermission{"tool.invoke", "other-tool"})
			})
		}, true},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			f := base.clone(t)
			test.change(&f)
			if !test.unanchored {
				f.refresh(t)
			}
			original := f.clone(t)
			got, err := f.evaluate(&previous)
			requireMemoryDecisionRefusal(t, got, err, test.code)
			if !reflect.DeepEqual(f, original) {
				t.Fatal("refusal mutated its inputs")
			}
			valid, err := base.evaluate(&previous)
			if err != nil || len(valid.recipient) != 3 {
				t.Fatal("isolated refusal damaged subsequent valid use", err)
			}
		})
	}
}

func TestMemoryUsageDecisionRejectsEditedOrPartialPrevious(t *testing.T) {
	f := memoryDecisionSetup(t)
	previous, err := f.evaluate(nil)
	if err != nil {
		t.Fatal(err)
	}
	for name, change := range map[string]func(*memoryUsageDecision){
		"missing-requester":   func(d *memoryUsageDecision) { d.requester = d.requester[:len(d.requester)-1] },
		"missing-recipient":   func(d *memoryUsageDecision) { d.recipient = d.recipient[:len(d.recipient)-1] },
		"reordered-recipient": func(d *memoryUsageDecision) { d.recipient[0], d.recipient[1] = d.recipient[1], d.recipient[0] },
		"edited-binding":      func(d *memoryUsageDecision) { d.bindingDigest = hash([]byte("another binding")) },
		"edited-expiration":   func(d *memoryUsageDecision) { d.expiresAt = d.expiresAt.Add(time.Second) },
		"edited-actor":        func(d *memoryUsageDecision) { d.requester[0].Actor.Principal.Subject = "forged" },
		"roles-swapped":       func(d *memoryUsageDecision) { d.requester, d.recipient = d.recipient, d.requester },
		"empty":               func(d *memoryUsageDecision) { *d = memoryUsageDecision{} },
	} {
		t.Run(name, func(t *testing.T) {
			candidate := previous
			candidate.requester = slices.Clone(previous.requester)
			candidate.recipient = slices.Clone(previous.recipient)
			change(&candidate)
			got, err := f.evaluate(&candidate)
			requireMemoryDecisionRefusal(t, got, err, "memory_usage_decision_stale")
		})
	}
	got, err := f.evaluate(&previous)
	if err != nil || !reflect.DeepEqual(got, previous) {
		t.Fatal("editing a copy damaged original proof", err)
	}
}

func TestMemoryUsageDecisionRebuildsAndRechecksBeforeReuse(t *testing.T) {
	base := memoryDecisionSetup(t)
	previous, err := base.evaluate(nil)
	if err != nil {
		t.Fatal(err)
	}
	t.Run("changed-selection", func(t *testing.T) {
		f := base.clone(t)
		f.launch.Summary.Reason = "Another exact selection"
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "memory_usage_decision_stale")
	})
	t.Run("stale-answer", func(t *testing.T) {
		f := base.clone(t)
		f.work.Tasks[2].Answers[0].Text = "Changed stored answer"
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "")
	})
	t.Run("other-task-snapshot", func(t *testing.T) {
		f := base.clone(t)
		f.launch.TaskID = "other"
		f.target.Task = "other"
		refreshMemoryUsageSelection(t, f.root, f.work, &f.launch)
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "agent_identity_permission_denied")
	})
	t.Run("new-authority", func(t *testing.T) {
		f := base.clone(t)
		f.frame.snapshot.Revision++
		f.refresh(t)
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "memory_usage_decision_stale")
		if _, err = f.evaluate(nil); err != nil {
			t.Fatal("fresh evaluation under current authority failed", err)
		}
	})
	t.Run("new-grant", func(t *testing.T) {
		f := base.clone(t)
		g := f.frame.snapshot.Grants[f.ids.requesterGrant]
		g.ID = "new-requester-grant"
		f.ids.requesterGrant = g.ID
		f.frame.snapshot.Grants[g.ID] = g
		f.frame.authority.roots[g.ID] = true
		f.frame.snapshot.Revision++
		if err := validateAgentIdentityTransition(base.frame.snapshot, f.frame.snapshot); err != nil {
			t.Fatal("fixture proposed an illegal registry transition", err)
		}
		f.refresh(t)
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "memory_usage_decision_stale")
	})
	t.Run("reauthenticate-then-expire", func(t *testing.T) {
		f := base.clone(t)
		f.frame.at = f.frame.at.Add(time.Second)
		f.frame.requester.verifiedAt = f.frame.at
		f.frame.recipient.verifiedAt = f.frame.at
		if _, err := f.evaluate(&previous); err != nil {
			t.Fatal("fresh actors could not reuse still-current decision", err)
		}
		f.frame.at = base.frame.at.Add(31 * time.Second)
		f.frame.requester.verifiedAt = f.frame.at
		f.frame.recipient.verifiedAt = f.frame.at
		got, err := f.evaluate(&previous)
		requireMemoryDecisionRefusal(t, got, err, "agent_identity_grant_inactive")
	})
}
