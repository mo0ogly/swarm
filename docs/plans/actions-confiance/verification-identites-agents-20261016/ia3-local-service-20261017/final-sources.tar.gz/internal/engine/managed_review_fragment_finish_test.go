//go:build linux

package engine

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestManagedFragmentFinishRequiresDurableDecision(t *testing.T) {
	s, w, a, c, path, receipt := fragmentBeginFixture(t)
	r, err := s.beginManagedFragmentReview(w, a, c, path, receipt)
	if err != nil {
		t.Fatal(err)
	}
	before, _ := s.get(w.ID)
	if s.finishManagedFragmentReview(w.ID, a, r.ID, nil) == nil {
		t.Fatal("incomplete review finalized")
	}
	after, _ := s.get(w.ID)
	task, _ := after.task(a.TaskID)
	if task.IndependentReview.State == "passed" || task.Status == "accepted" || after.Planning.Reviewer.Calls != before.Planning.Reviewer.Calls {
		t.Fatal("premature completion or charge")
	}
}

func TestManagedFragmentFinishPersistsProtocolFailureCode(t *testing.T) {
	s, w, a, c, path, receipt := fragmentBeginFixture(t)
	r, err := s.beginManagedFragmentReview(w, a, c, path, receipt)
	if err != nil {
		t.Fatal(err)
	}
	if err := s.finishManagedFragmentReview(w.ID, a, r.ID, &CommandError{Code: reviewFragmentProtocolError, Message: "inspection de fragment : invalid fixture quote"}); err == nil {
		t.Fatal("protocol failure accepted")
	}
	after, err := s.get(w.ID)
	if err != nil {
		t.Fatal(err)
	}
	task, _ := after.task(a.TaskID)
	if task.IndependentReview.State != "error" || task.IndependentReview.FailureCode != reviewFragmentProtocolError || task.Status == "accepted" || after.Planning.Reviewer.Calls != w.Planning.Reviewer.Calls {
		t.Fatal("protocol error lost its attribution or accepted the candidate")
	}
	routes := planningReviewFailureRouting(after, after.Planning.Inbox)
	inventory := s.planningReviewEvidence(after, after.Planning.Inbox)
	if routes[task.ID].Review != r.ID || inventory[task.ID].Review != r.ID || task.IndependentReview.ResultEvent == r.ID || task.IndependentReview.ResultEvent == "" {
		t.Fatal("actual fragment result event did not deliver routing and inventory", routes, inventory)
	}
}
func TestManagedFragmentSaveRejectsStaleJournalAnchor(t *testing.T) {
	s, w, a, c, path, receipt := fragmentBeginFixture(t)
	r, err := s.beginManagedFragmentReview(w, a, c, path, receipt)
	if err != nil {
		t.Fatal(err)
	}
	anchor := *r.FragmentJournal
	anchor.JournalDigest = "stale"
	r.FragmentJournal = &anchor
	r.State = "error"
	if s.saveManagedReview(w.ID, a, r) == nil {
		t.Fatal("stale anchor overwrote current journal")
	}
	after, _ := s.get(w.ID)
	task, _ := after.task(a.TaskID)
	if task.IndependentReview.FragmentJournal.JournalDigest == "stale" || task.IndependentReview.State != "running" {
		t.Fatal("journal mutated")
	}
}

func TestManagedFragmentRefusalRequiresOriginalProof(t *testing.T) {
	s, w, a, c, path, receipt := fragmentBeginFixture(t)
	if err := os.WriteFile(filepath.Join(s.root, "review-fixture/claude"), []byte(fragmentRuntimeProviderFixture), 0700); err != nil {
		t.Fatal(err)
	}
	managedReviewMode(t, s, "fail")
	r, err := s.beginManagedFragmentReview(w, a, c, path, receipt)
	if err != nil {
		t.Fatal(err)
	}
	plan, _, err := s.readFragmentJournalAnchor(r)
	if err != nil {
		t.Fatal(err)
	}
	state, _, runErr := s.runManagedFragmentReview(w, a, r)
	if runErr != nil || state != "changes_requested" {
		t.Fatal("missing final independent refusal", state, runErr)
	}
	w, err = s.get(w.ID)
	if err != nil {
		t.Fatal(err)
	}
	task, _ := w.task(a.TaskID)
	r = *task.IndependentReview
	reason, err := s.managedFragmentRefusal(r)
	if err != nil || reason == "" {
		t.Fatal(reason, err)
	}
	if !strings.Contains(reason, "Reproduction :") || !strings.Contains(reason, "Attendu :") || managedReviewCalls(t, s) != len(plan.Packets)+2 {
		t.Fatal("final refusal lacks complete inspections/selection/decision", reason)
	}
	// The legacy error label is not authority; original proof remains necessary.
	r.State = "error"
	reason, err = s.managedFragmentRefusal(r)
	if err != nil || reason == "" {
		t.Fatal(reason, err)
	}
	before := managedReviewCalls(t, s)
	journal := filepath.Join(s.root, r.FragmentJournal.Journal)
	if err = os.WriteFile(journal, []byte("{}"), 0600); err != nil {
		t.Fatal(err)
	}
	if reason, err = s.managedFragmentRefusal(r); err == nil || reason != "" {
		t.Fatal("altered journal authorized correction")
	}
	if managedReviewCalls(t, s) != before {
		t.Fatal("proof check spent a call")
	}
}
