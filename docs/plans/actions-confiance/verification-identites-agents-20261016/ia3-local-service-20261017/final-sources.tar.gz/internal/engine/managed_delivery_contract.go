//go:build linux

package engine

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Producer declarations are a completeness check, never an acceptance verdict.
// They are read from the immutable result/candidate and checked before a paid review.
type ManagedDelivery struct {
	Version  int                 `json:"version"`
	Task     string              `json:"task"`
	Attempt  string              `json:"attempt"`
	Contract string              `json:"contract"`
	Outcome  string              `json:"outcome"`
	Criteria []DeliveryCriterion `json:"criteria"`
}

type DeliveryCriterion struct {
	Index    int      `json:"index"`
	Status   string   `json:"status"`
	Reason   string   `json:"reason"`
	Controls []string `json:"controls"`
	Evidence []string `json:"evidence"`
}

const deliveryEvidenceBoundary = "Le bilan décrit les vérifications locales du producteur, pas une validation future du moteur. Le producteur exécute les vérifications autorisées dans sa copie et consigne commande, résultat observé et fichiers de preuve. status=pass signifie uniquement que ses vérifications locales couvrent réellement ce critère ; outcome=complete signifie que sa livraison locale est complète, jamais que la tâche est acceptée. Ne pas attendre la revue indépendante pour rendre ce bilan. Si une vérification locale manque ou échoue, conserver not_tested ou fail et expliquer la limite. Le moteur exécutera ensuite ses propres contrôles sur la révision candidate, puis demandera une revue indépendante ; lui seul peut accepter la tâche. Le planificateur ne doit pas demander au producteur de certifier un contrôle du moteur qui n'a pas encore eu lieu."

const deliveryReadyBoundary = "Bilan version 2 : outcome=ready signifie que les sources et recettes sont prêtes pour les contrôles obligatoires du moteur, sans acceptation ni certification locale inventée. Si une capacité de votre environnement empêche une vérification, conserver status=not_tested et son motif ; déclarer les sources complètes et les identifiants des contrôles autorisés qui vérifieront ce critère. ready exige une politique automatique couvrant chaque critère ; un échec produit connu reste fail et bloque la remise. Ne pas relancer un contrôle sur une permission inchangée. Le moteur doit exécuter ses contrôles dans son contexte sur ce candidat puis obtenir la revue indépendante avant toute acceptation."

const deliveryNegativeCheckBoundary = "Pour un test de refus, garder valides tous les autres champs que la variation visée et vérifier le motif attendu ainsi que l’absence de mutation métier. Après ajout d’une règle obligatoire, réexaminer les anciens cas négatifs : un refus déclenché par une autre garde ne démontre pas la protection annoncée. Pour une garde critique, un retrait contrôlé dans une fixture isolée doit faire échouer le cas nommé ; conserver cette preuve et ne jamais livrer la mutation."

const reviewSourceBoundary = "Le vérificateur est sans outils. Les fichiers déclarés dans delivery.criteria[].evidence sont joints intégralement depuis le candidat Git testé, même inchangés, avec blob et SHA256 ; le rapport est déjà fourni intégralement. Déclarer les originaux nécessaires, pas seulement un rapport qui les cite. docs/TASK-ID.review-context.json (version 1, files de chemins relatifs Git) ajoute des sources complémentaires. Les limites de contexte restent applicables : une source invalide, absente, non textuelle ou trop grande bloque avant l'appel payant, sans troncature. Pour un refus unknown, distinguer résultat incorrect et pièce non fournie ; une reprise doit nommer le manque, l'original à déclarer et la vérification attendue. Ajouter seulement des citations ou des numéros de ligne ne remplace pas l'original. Ne pas modifier artificiellement une source inchangée pour la faire entrer dans le diff. Une source transmise n'est ni une lecture comprise ni une acceptation."

func managedDeliveryInstructions(t *Task, attempt string) string {
	manifest := ManagedDelivery{Version: 2, Task: t.ID, Attempt: attempt, Contract: reviewContract(t), Outcome: "partial"}
	for i := range t.Criteria {
		ids := []string{}
		if t.ValidationPolicy != nil {
			for _, c := range t.ValidationPolicy.Controls {
				for _, index := range c.Criteria {
					if index == i+1 {
						ids = append(ids, c.ID)
						break
					}
				}
			}
		}
		manifest.Criteria = append(manifest.Criteria, DeliveryCriterion{Index: i + 1, Status: "not_tested", Reason: "À compléter avec la commande et le résultat de la vérification locale réellement effectuée", Controls: ids, Evidence: []string{}})
	}
	data, _ := json.MarshalIndent(manifest, "", "  ")
	controls := ""
	if t.ValidationPolicy != nil {
		checks, _ := json.MarshalIndent(t.ValidationPolicy.Controls, "", "  ")
		controls = "\nContrôles configurés à reproduire localement avec leurs options, dans les permissions de la copie. Ne pas modifier leur définition pour obtenir un succès. Leur exécution locale ne remplace pas celle du moteur :\n" + string(checks) + "\n"
	}
	return "\n" + deliveryEvidenceBoundary + "\n" + deliveryReadyBoundary + "\n" + deliveryNegativeCheckBoundary + "\n" + reviewSourceBoundary + controls + "\nBILAN DE LIVRAISON REQUIS : écrire docs/" + t.ID + ".delivery.json dans cette copie, en plus du rapport Markdown. Le moteur contrôle ce bilan avant la revue payante. Garder task/attempt/contract et un élément par critère. outcome=complete seulement si TOUS les critères sont démontrés localement ; ready si les sources et recettes sont prêtes à être contrôlées conformément au contrat version 2 ; sinon partial ou blocked. status=pass, fail, not_tested ou not_applicable ; expliquer chaque résultat dans reason. controls référence uniquement les identifiants de contrôles autorisés pour ce critère, jamais une commande libre ; evidence référence des fichiers suivis de cette copie (chemins relatifs à la racine Git). Une preuve absente ou une non-applicabilité conserve un résultat incomplet à examiner. Ne pas réduire un critère au test le plus facile : traiter toutes ses obligations, y compris les interactions navigateur demandées. Ne pas inventer de preuve ni transformer un non-testé en pass. Ce bilan n’est pas une acceptation.\n" + string(data) + "\n"
}

func deliveryIncomplete(reason string) error {
	return &CommandError{Code: "delivery_incomplete", Message: "Livraison incomplète : " + reason + ". Aucun appel de revue lancé ; le responsable doit examiner les éléments manquants avant une reprise autorisée."}
}

func (s *Store) managedDelivery(w Work, t *Task, a Agent, candidate string) (*ManagedDelivery, error) {
	repo := w.Planning.Repository
	bare := filepath.Join(repo.Storage, "repository.git")
	path := filepath.ToSlash(filepath.Join(repo.Subdir, "docs", t.ID+".delivery.json"))
	source, e := candidateReviewSource(bare, candidate, path, 32*1024)
	if errors.Is(e, os.ErrNotExist) {
		if a.DeliveryVersion > 0 {
			return nil, deliveryIncomplete("bilan par critère absent (" + path + ")")
		}
		return nil, nil // A new host must not retroactively change old attempts.
	}
	if e != nil {
		return nil, deliveryIncomplete("bilan illisible : " + e.Error())
	}
	var d ManagedDelivery
	if e = strict([]byte(source.Content), &d); e != nil {
		return nil, deliveryIncomplete("bilan de livraison invalide : " + e.Error())
	}
	if (d.Version != 1 && d.Version != 2) || (d.Version == 2 && a.DeliveryVersion != 2) || d.Task != t.ID || d.Attempt != a.Attempt || d.Contract != reviewContract(t) {
		return nil, deliveryIncomplete("bilan attribué à une autre tâche, tentative ou consigne")
	}
	ready := d.Version == 2 && d.Outcome == "ready"
	if d.Outcome != "complete" && d.Outcome != "partial" && d.Outcome != "blocked" && !ready {
		return nil, deliveryIncomplete("état de livraison inconnu")
	}
	if len(d.Criteria) != len(t.Criteria) || t.ValidationPolicy == nil {
		return nil, deliveryIncomplete("critères ou contrôles manquants")
	}
	if ready && t.ValidationPolicy.Mode != "automatic" {
		return nil, deliveryIncomplete("la remise ready exige des contrôles automatiques autorisés")
	}
	seen := map[int]bool{}
	for _, c := range d.Criteria {
		if c.Index < 1 || c.Index > len(t.Criteria) || seen[c.Index] {
			return nil, deliveryIncomplete("critère inconnu ou dupliqué")
		}
		seen[c.Index] = true
		if (c.Status != "pass" && !(ready && c.Status == "not_tested")) || strings.TrimSpace(c.Reason) == "" {
			return nil, deliveryIncomplete(fmt.Sprintf("critère %d non démontré (%s) : %s. %s", c.Index, c.Status, guardBlock(c.Reason, 300), deliveryEvidenceBoundary))
		}
		if len(c.Controls) == 0 || len(c.Evidence) == 0 || len(c.Evidence) > 24 {
			return nil, deliveryIncomplete(fmt.Sprintf("contrôles ou fichiers de preuve manquants pour le critère %d", c.Index))
		}
		for _, id := range c.Controls {
			valid := false
			for _, check := range t.ValidationPolicy.Controls {
				if check.ID == id {
					for _, index := range check.Criteria {
						if index == c.Index {
							valid = true
						}
					}
				}
			}
			if !valid {
				return nil, deliveryIncomplete(fmt.Sprintf("contrôle %s non autorisé pour le critère %d", id, c.Index))
			}
		}
		for _, path := range c.Evidence {
			if path == "" || filepath.IsAbs(path) || filepath.ToSlash(filepath.Clean(path)) != path || strings.HasPrefix(path, "../") || path == "." || strings.ContainsAny(path, "\x00\n\r\\:") || strings.HasPrefix(path, ".git/") || path == ".git" {
				return nil, deliveryIncomplete("chemin de preuve invalide")
			}
			entry, e := managedGit(bare, "ls-tree", "-z", candidate, "--", ":(literal)"+path)
			if e != nil {
				return nil, e
			}
			parts := strings.SplitN(strings.TrimSuffix(entry, "\x00"), "\t", 2)
			if len(parts) != 2 || parts[1] != path || (!strings.HasPrefix(parts[0], "100644 blob ") && !strings.HasPrefix(parts[0], "100755 blob ")) {
				return nil, deliveryIncomplete("fichier de preuve absent ou non régulier : " + path)
			}
		}
	}
	if d.Outcome != "complete" && !ready {
		return nil, deliveryIncomplete("le producteur déclare un résultat partiel ou bloqué")
	}
	return &d, nil
}
