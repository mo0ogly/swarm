package engine

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"swarm.local/companion/internal/identitycontract"
)

const schemaVersion = 37

type ManualOverride struct {
	Reason         string `json:"reason"`
	Actor          string `json:"actor"`
	At             string `json:"at"`
	PreviousStatus string `json:"previous_status"`
	Revision       int    `json:"revision"`
}

type BrainstormAnswer struct {
	Attempt string `json:"attempt"`
	Text    string `json:"text"`
	At      string `json:"at"`
}

type Revalidation struct {
	PreviousArtifacts map[string]string `json:"previous_artifacts"`
	Config            string            `json:"config_digest"`
	Report            string            `json:"report,omitempty"`
	ReportHash        string            `json:"report_hash,omitempty"`
}

// ValidationPolicy is an operator authorization, not a provider suggestion.
// Commands are never parsed from a plan, a handoff, logs or assistant text.
type ValidationPolicy struct {
	Mode       string              `json:"mode"`
	Controls   []ValidationControl `json:"controls"`
	Authorized string              `json:"authorized_at,omitempty"`
	Actor      string              `json:"actor,omitempty"`
}

type ValidationControl struct {
	EnvironmentExitCodes []int    `json:"environment_exit_codes,omitempty"`
	ReviewOutput         bool     `json:"review_output,omitempty"`
	Inputs               []string `json:"inputs,omitempty"`
	ID                   string   `json:"id"`
	Command              []string `json:"command"`
	Criteria             []int    `json:"criteria"`
	Justification        string   `json:"justification"`
	Dir                  string   `json:"dir,omitempty"`
	Timeout              int      `json:"timeout_seconds,omitempty"`
}

type ValidationControlResult struct {
	CommandRuntimeLimits  *RunLimitsConfigEntry `json:"command_runtime_limits,omitempty"`
	RuntimeLimits         *RunLimitsConfigEntry `json:"runtime_limits,omitempty"`
	EnvironmentFailure    bool                  `json:"environment_failure,omitempty"`
	ReviewOutput          string                `json:"review_output,omitempty"`
	OutputBytes           int                   `json:"output_bytes,omitempty"`
	ReviewOutputTruncated bool                  `json:"review_output_truncated,omitempty"`
	ID                    string                `json:"id"`
	Command               []string              `json:"command,omitempty"`
	Executed              bool                  `json:"executed"`
	Passed                bool                  `json:"passed"`
	ExitCode              int                   `json:"exit_code"`
	OutputHash            string                `json:"output_sha256"`
	Summary               string                `json:"summary"`
	Started               string                `json:"started_at,omitempty"`
	Finished              string                `json:"finished_at,omitempty"`
	WallDurationMS        *int64                `json:"wall_duration_ms,omitempty"`
	CPUDurationMS         *int64                `json:"cpu_duration_ms,omitempty"`
}

type AutomaticValidation struct {
	DeliveryVersion int    `json:"delivery_version,omitempty"`
	Attempt         string `json:"attempt_id"`
	Revision        int    `json:"revision"`
	// CandidateSHA is the Git commit actually merged, committed and checked
	// out when the controls below ran (managed_integration.go's commit-tree
	// result), never derived from Reason text. Distinct from Revision, the
	// business work revision counter, and from At, the receipt timestamp.
	CandidateSHA string                    `json:"candidate_sha"`
	Producer     string                    `json:"producer_agent_id"`
	Controller   string                    `json:"controller"`
	PolicyDigest string                    `json:"policy_digest"`
	Policy       ValidationPolicy          `json:"policy"`
	Artifacts    map[string]string         `json:"artifacts"`
	Controls     []ValidationControlResult `json:"controls"`
	Receipt      string                    `json:"receipt"`
	State        string                    `json:"state"`
	Reason       string                    `json:"reason"`
	At           string                    `json:"at"`
}

type Task struct {
	MemorySelections        []MemoryReference           `json:"memory_selections,omitempty"`
	MemoryDecision          *MemorySelectionDecision    `json:"memory_decision,omitempty"`
	MemorySelectionImported bool                        `json:"memory_selection_imported,omitempty"`
	InstructionBase         *string                     `json:"instruction_base,omitempty"`
	InstructionOperatorBase *string                     `json:"instruction_operator_base,omitempty"`
	InstructionRevisions    []InstructionRevision       `json:"instruction_revisions,omitempty"`
	ProviderRelayDecision   *ProviderRelayDecision      `json:"provider_relay_decision,omitempty"`
	LegacyReportSubmissions []Attempt                   `json:"legacy_report_submissions,omitempty"`
	ReviewCoordination      *ReviewCoordinationRecord   `json:"review_coordination,omitempty"`
	Restarts                []TaskRestart               `json:"restarts,omitempty"`
	ModelSelection          *TaskModel                  `json:"model_selection,omitempty"`
	Requalifications        []HistoricalRequalification `json:"requalifications,omitempty"`
	IntegrationRetries      []IntegrationRetry          `json:"integration_retries,omitempty"`
	BatchReviewResume       *IndependentReview          `json:"batch_review_resume,omitempty"`
	RecoveredResult         *RecoveredResult            `json:"recovered_result,omitempty"`
	CorrectiveRecovery      *CorrectiveRecovery         `json:"corrective_recovery,omitempty"`
	PreviousReviews         []IndependentReview         `json:"previous_reviews,omitempty"`
	IndependentReview       *IndependentReview          `json:"independent_review,omitempty"`
	ScopeID                 string                      `json:"scope_id,omitempty"`
	Requirements            []string                    `json:"requirements,omitempty"`
	ValidationPolicy        *ValidationPolicy           `json:"validation_policy,omitempty"`
	AutoValidation          *AutomaticValidation        `json:"automatic_validation,omitempty"`
	EvidenceStaleReason     string                      `json:"evidence_stale_reason,omitempty"`
	LaunchHeld              bool                        `json:"launch_held,omitempty"`
	Profile                 *LaunchProfile              `json:"launch_profile,omitempty"`
	Revalidation            *Revalidation               `json:"revalidation,omitempty"`
	PlanChecks              map[string]string           `json:"plan_checks,omitempty"`
	PlanBriefHash           string                      `json:"plan_brief_hash,omitempty"`
	PlanRole                string                      `json:"plan_role,omitempty"`
	PlanningRetry           bool                        `json:"planning_retry,omitempty"`
	PlanMaxAttempts         int                         `json:"plan_max_attempts,omitempty"`
	PlanToolLimit           int                         `json:"plan_tool_limit,omitempty"`
	Contexts                []SavedContext              `json:"contexts,omitempty"`
	Answers                 []BrainstormAnswer          `json:"answers,omitempty"`
	Question                string                      `json:"question,omitempty"`
	Response                string                      `json:"response,omitempty"`
	ResponseError           string                      `json:"response_error,omitempty"`
	Brainstorm              bool                        `json:"brainstorm,omitempty"`
	Override                *ManualOverride             `json:"manual_override,omitempty"`
	ID                      string                      `json:"id"`
	Title                   string                      `json:"title"`
	Owner                   string                      `json:"owner"`
	Deliverable             string                      `json:"deliverable"`
	Criteria                []string                    `json:"criteria"`
	Depends                 []string                    `json:"depends"`
	Status                  string                      `json:"status"`
	Blocker                 string                      `json:"blocker"`
	Next                    string                      `json:"next"`
	Attempts                []Attempt                   `json:"attempts"`
	Gate                    *GateRecord                 `json:"gate,omitempty"`
}

// Origine d'une tentative : lancée à la main ou par l'ordonnanceur.
const (
	originOperator       = "operateur"
	originConductor      = "conducteur"
	originMissionPreview = "aperçu-mission"
)

// launchProfile fige ce que l'opérateur a choisi, workspace résolu compris.
func launchProfile(r Launch, cwd string) LaunchProfile {
	p := LaunchProfile{Skills: append([]ActionSkillSelection(nil), r.Skills...), Provider: r.Provider, Role: r.Role, Workspace: cwd, Instruction: r.Instruction,
		Level: r.Level, Timeout: r.Timeout, Capture: r.Capture, Limits: r.Limits,
		Updated: now(), Actor: launchOrigin(r)}
	if p.Role == "" {
		p.Role = "worker"
	}
	return p
}

func launchOrigin(r Launch) string {
	if r.Origin == originConductor {
		return originConductor
	}
	return originOperator
}

// Profil de lancement réutilisable : ce que l'opérateur a choisi une fois et
// que l'ordonnanceur rejoue, au lieu de redemander le même formulaire.
// Le profil d'une tâche prime sur celui du travail.
type LaunchProfile struct {
	Skills      []ActionSkillSelection `json:"skills,omitempty"`
	Limits      *RunLimits             `json:"limits,omitempty"`
	Provider    string                 `json:"provider"`
	Role        string                 `json:"role"`
	Workspace   string                 `json:"workspace"`
	Instruction string                 `json:"instruction,omitempty"`
	Level       string                 `json:"level,omitempty"`
	Timeout     int                    `json:"timeout_seconds,omitempty"`
	Capture     bool                   `json:"capture_output,omitempty"`
	Updated     string                 `json:"updated"`
	Actor       string                 `json:"actor"`
}
type Attempt struct {
	ID      string `json:"id"`
	Status  string `json:"status"`
	Started string `json:"started"`
	Ended   string `json:"ended,omitempty"`
}
type GitState struct {
	Head    string `json:"head"`
	Branch  string `json:"branch"`
	Changes string `json:"changes"`
}
type Work struct {
	RequirementPrerequisites map[string][]string `json:"requirement_prerequisites,omitempty"`
	Planning                 *PlanningState      `json:"planning,omitempty"`
	Profile                  *LaunchProfile      `json:"launch_profile,omitempty"`
	Plans                    []ApprovedPlan      `json:"plans,omitempty"`
	Retex                    []Retex             `json:"retex,omitempty"`
	ProjectMemory            []ProjectMemory     `json:"project_memory,omitempty"`
	PlanningBrief            *PlanningBrief      `json:"planning_brief,omitempty"`
	Schema                   int                 `json:"schema_version"`
	ID                       string              `json:"id"`
	Revision                 int                 `json:"revision"`
	Title                    string              `json:"title"`
	Objective                string              `json:"objective"`
	Scope                    string              `json:"scope"`
	Criteria                 []string            `json:"criteria"`
	Next                     string              `json:"next"`
	Summary                  string              `json:"summary"`
	Memory                   []string            `json:"memory"`
	Created                  string              `json:"created"`
	Updated                  string              `json:"updated"`
	Git                      GitState            `json:"git"`
	Tasks                    []Task              `json:"tasks"`
}
type Event struct {
	ID       string          `json:"id"`
	WorkID   string          `json:"work_id"`
	Revision int             `json:"revision"`
	Kind     string          `json:"kind"`
	At       string          `json:"at"`
	Payload  json.RawMessage `json:"payload"`
}
type Request struct {
	RequirementPrerequisites map[string][]string `json:"requirement_prerequisites,omitempty"`
	ConfirmContractRevision  bool                `json:"confirm_contract_revision,omitempty"`
	ExpectedContract         string              `json:"expected_contract,omitempty"`
	ContractRevisionReason   string              `json:"contract_revision_reason,omitempty"`
	MaxAttempts              int                 `json:"max_attempts,omitempty"`
	MaxToolCalls             int                 `json:"max_tool_calls,omitempty"`
	Schema                   int                 `json:"schema_version"`
	EventID                  string              `json:"event_id"`
	Revision                 int                 `json:"expected_revision"`
	ID                       string              `json:"id,omitempty"`
	Title                    string              `json:"title,omitempty"`
	Objective                string              `json:"objective,omitempty"`
	Scope                    string              `json:"scope,omitempty"`
	Criteria                 []string            `json:"criteria,omitempty"`
	Owner                    string              `json:"owner,omitempty"`
	Deliverable              string              `json:"deliverable,omitempty"`
	Depends                  []string            `json:"depends,omitempty"`
	Status                   string              `json:"status,omitempty"`
	Blocker                  string              `json:"blocker,omitempty"`
	Next                     string              `json:"next,omitempty"`
	Summary                  string              `json:"summary,omitempty"`
	Memory                   []string            `json:"memory,omitempty"`
	Outcome                  string              `json:"outcome,omitempty"`
	ValidationPolicy         *ValidationPolicy   `json:"validation_policy,omitempty"`
	Observation              string              `json:"observation,omitempty"`
	Orientation              string              `json:"orientation,omitempty"`
	Decision                 string              `json:"decision,omitempty"`
	Result                   string              `json:"result,omitempty"`
	// Auteur de la mutation, quand ce n'est pas un humain. « task.update » est
	// écrit par les deux voies : l'opérateur depuis le cockpit, la CLI ou le
	// terminal, et le moteur au départ, au relais et à la fin d'une tentative.
	// Le type d'événement seul ne les distingue donc pas, et le fil d'activité
	// attribuait au moteur des gestes humains — y compris l'acceptation.
	// Les points d'entrée externes effacent ce champ : personne ne peut se
	// déclarer moteur depuis l'extérieur, et l'absence se lit « humain ».
	Origin string `json:"origin,omitempty"`
}

func now() string { return time.Now().UTC().Format(time.RFC3339Nano) }
func newID(prefix string) string {
	b := make([]byte, 12)
	if _, e := rand.Read(b); e != nil {
		panic(e)
	}
	return prefix + hex.EncodeToString(b)
}
func nonempty(s string) bool { return strings.TrimSpace(s) != "" }
func require(ok bool, msg string) error {
	if !ok {
		return fmt.Errorf("%s", msg)
	}
	return nil
}
func (w *Work) task(id string) (*Task, error) {
	for i := range w.Tasks {
		if w.Tasks[i].ID == id {
			return &w.Tasks[i], nil
		}
	}
	return nil, fmt.Errorf("tâche inconnue : %s", id)
}
func safeName(s string) bool { return identitycontract.Name(s) }

// Resolve the authorized root and targets in the same physical namespace.
// A retained alias after a project move must not make its own files outsiders.
// Child symlinks still pass the existing containment checks below.
func canonicalProjectRoot(root string) (string, error) {
	abs, err := filepath.Abs(root)
	if err != nil {
		return "", err
	}
	return filepath.EvalSymlinks(abs)
}

// Only an alias of the complete authorized project root is compatible with
// retained ownership. A redirected child directory is a different identity.
func canonicalOwnedProjectPath(root, path string) (string, error) {
	canonical, err := canonicalProjectRoot(root)
	if err != nil {
		return "", err
	}
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return "", fmt.Errorf("chemin absolu normalisé requis")
	}
	var ancestors []string
	for p := path; ; p = filepath.Dir(p) {
		ancestors = append(ancestors, p)
		if filepath.Dir(p) == p {
			break
		}
	}
	// Inspect from outside to inside: a child link back to the root must not be
	// mistaken for another authorized project-root alias.
	for i := len(ancestors) - 1; i >= 0; i-- {
		prefix, e := filepath.EvalSymlinks(ancestors[i])
		if e != nil || prefix != canonical {
			continue
		}
		rel, e := filepath.Rel(ancestors[i], path)
		if e != nil {
			return "", e
		}
		actual, e := filepath.EvalSymlinks(path)
		if e != nil {
			return "", e
		}
		if actual != filepath.Join(canonical, rel) {
			return "", fmt.Errorf("chemin attribué redirigé")
		}
		return actual, nil
	}
	return "", fmt.Errorf("chemin attribué hors projet")
}

func localFile(root, name string) (string, error) {
	if !nonempty(name) || filepath.IsAbs(name) {
		return "", fmt.Errorf("chemin relatif requis : %s", name)
	}
	root, e := canonicalProjectRoot(root)
	if e != nil {
		return "", e
	}
	resolved, e := filepath.EvalSymlinks(filepath.Join(root, name))
	if e != nil {
		return "", e
	}
	rel, e := filepath.Rel(root, resolved)
	if e != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return "", fmt.Errorf("chemin hors projet : %s", name)
	}
	st, e := os.Stat(resolved)
	if e != nil {
		return "", e
	}
	if !st.Mode().IsRegular() {
		return "", fmt.Errorf("fichier régulier requis : %s", name)
	}
	return resolved, nil
}
func atomicWrite(path string, data []byte) error {
	// Open the parent before mutation: durable publication requires both the
	// file contents and its renamed directory entry to be synchronized.
	dir, e := os.Open(filepath.Dir(path))
	if e != nil {
		return e
	}
	defer dir.Close()
	f, e := os.CreateTemp(filepath.Dir(path), ".swarm-write-")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if _, e = f.Write(data); e != nil {
		f.Close()
		return e
	}
	if e = f.Sync(); e != nil {
		f.Close()
		return e
	}
	if e = f.Close(); e != nil {
		return e
	}
	if e = os.Rename(name, path); e != nil {
		return e
	}
	// A failure here means publication is uncertain, not rolled back. Callers
	// must reconcile the target rather than blindly retrying an effect.
	return dir.Sync()
}
