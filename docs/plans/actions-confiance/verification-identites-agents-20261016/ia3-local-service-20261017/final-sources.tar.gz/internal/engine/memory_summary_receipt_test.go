//go:build linux

package engine

import (
	"database/sql"
	"encoding/json"
	"os"
	"reflect"
	"strings"
	"testing"
)

func TestMemorySummarySourceInvalidUTF8ReadBoundary(t *testing.T) {
	// Minimal SQL read fixture, not a migrated Store or a mission database.
	// The real migrated write boundary is exercised by the source tests; no
	// identity trigger is removed or disabled to reach this reader guard.
	db, err := sql.Open("sqlite", ":memory:")
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	db.SetMaxOpenConns(1)
	if _, err := db.Exec("CREATE TABLE works(id TEXT PRIMARY KEY,revision INTEGER,body BLOB)"); err != nil {
		t.Fatal(err)
	}
	if _, err := db.Exec("INSERT INTO works(id,revision,body) VALUES(?,?,?)", "work", 1, []byte{0xff}); err != nil {
		t.Fatal(err)
	}
	s := &Store{root: t.TempDir(), db: db}
	q, _ := json.Marshal(MemorySummarySourceRequest{Schema: 1, Work: "work", Task: "task", Revision: 1, Dialogues: []DialogueRef{{Task: "source"}}})
	packet, err := s.memorySummarySource(q)
	if err == nil || !strings.Contains(err.Error(), "invalid UTF-8") || packet != (MemorySummarySourcePacket{}) {
		t.Fatal("invalid UTF-8 reader returned a source packet", packet, err)
	}
	var body []byte
	if err := db.QueryRow("SELECT body FROM works WHERE id=?", "work").Scan(&body); err != nil || !reflect.DeepEqual(body, []byte{0xff}) {
		t.Fatal("source rejection rewrote the read fixture", err)
	}
}

func TestMemorySummarySelectionReceiptDriftPreventsProvider(t *testing.T) {
	for _, scenario := range []string{"edited-selection", "missing-receipt"} {
		t.Run(scenario, func(t *testing.T) {
			s, w, r := summarySelectionFixture(t)
			script := summaryCaptureProvider(t, s)
			a := prepareSummaryAgent(t, s, w, r)
			if scenario == "missing-receipt" {
				a.Context.Summary = nil
			} else {
				a.Context.Summary.Selection.Reason = "Changed after confirmation"
				raw, err := json.Marshal(a.Context.Summary.Selection)
				if err != nil {
					t.Fatal(err)
				}
				a.Context.Summary.SelectionSHA = hash(raw)
			}
			// Corruption fixture only. No public operation to alter this receipt
			// is claimed, and this is not a test against a live mission database.
			if err := s.saveAgent(a); err != nil {
				t.Fatal(err)
			}
			if err := s.supervise(a.ID); err != nil {
				t.Fatal(err)
			}
			stored, err := s.agent(a.ID)
			if err != nil {
				t.Fatal(err)
			}
			if _, err := os.Stat(script + ".calls"); !os.IsNotExist(err) {
				t.Fatalf("provider invoked despite %s: status=%s activity=%s err=%v", scenario, stored.Status, stored.Activity, err)
			}
			if stored.Status != "failed" || stored.Child != 0 || !strings.Contains(stored.Activity, "reçu extractif") {
				t.Fatal("receipt drift not explained before provider start", stored.Status, stored.Activity)
			}
		})
	}
}

func TestMemorySummarySelectionCompleteReceiptBeforeStart(t *testing.T) {
	for _, scenario := range []string{
		"schema", "selection", "selection-digest", "source-count", "received-missing", "received-order", "omitted-missing",
		"attachment-digest", "attachment-bytes", "prepared-revision", "queued-revision", "snapshot-injected", "work", "task",
		"missing-context", "missing-receipt", "missing-prepared-receipt", "prepared-digest", "prepared-bytes", "prompt",
		"forged-prepared-digest", "current-digest", "current-bytes", "queued-digest",
	} {
		t.Run(scenario, func(t *testing.T) {
			s, w, r := summarySelectionFixture(t)
			a := prepareSummaryAgent(t, s, w, r)
			if err := appendAgentRecoveryContext(&a, "\nEngine recovery fixture\n"); err != nil {
				t.Fatal(err)
			}
			if err := s.saveAgent(a); err != nil {
				t.Fatal(err)
			}
			switch scenario {
			case "schema":
				a.Context.Summary.Schema++
			case "selection":
				a.Context.Summary.Selection.Reason += " changed"
				raw, _ := json.Marshal(a.Context.Summary.Selection)
				a.Context.Summary.SelectionSHA = hash(raw)
			case "selection-digest":
				a.Context.Summary.SelectionSHA = hash([]byte("wrong"))
			case "source-count":
				a.Context.Summary.SourceCount++
			case "received-missing":
				a.Context.Summary.Received = a.Context.Summary.Received[:1]
			case "received-order":
				a.Context.Summary.Received[0], a.Context.Summary.Received[1] = a.Context.Summary.Received[1], a.Context.Summary.Received[0]
			case "omitted-missing":
				a.Context.Summary.Omitted = nil
			case "attachment-digest":
				a.Context.Summary.AttachmentSHA = hash([]byte("wrong"))
			case "attachment-bytes":
				a.Context.Summary.AttachmentBytes++
			case "prepared-revision":
				a.Context.Summary.PreparedRevision++
			case "queued-revision":
				a.Context.Summary.QueuedRevision++
			case "snapshot-injected":
				a.Context.Summary.SnapshotInjected = true
			case "work":
				a.Context.Summary.Work = "other"
			case "task":
				a.Context.Summary.Task = "other"
			case "missing-context":
				a.Context = nil
			case "missing-receipt":
				a.Context.Summary = nil
			case "missing-prepared-receipt":
				a.PreparedContext.Summary = nil
			case "prepared-digest":
				a.PreparedContext.SHA256 = hash([]byte("wrong"))
			case "prepared-bytes":
				a.PreparedContext.Bytes = -1
			case "prompt":
				a.Prompt = "changed" + a.Prompt
			case "forged-prepared-digest":
				a.Prompt = "changed" + a.Prompt
				a.PreparedContext.Bytes += len("changed")
				a.PreparedContext.SHA256 = hash([]byte(a.Prompt[:a.PreparedContext.Bytes]))
				if err := bindAgentContext(&a); err != nil {
					t.Fatal(err)
				}
			case "current-digest":
				a.Context.SHA256 = hash([]byte("wrong"))
			case "current-bytes":
				a.Context.Bytes++
			case "queued-digest":
				a.Context.Summary.QueuedSourceSHA = hash([]byte("wrong"))
			}
			before, _ := json.Marshal(a)
			state := recoverySnapshotTest(t, s)
			if err := s.checkMemorySummaryBeforeStart(&a); err == nil {
				t.Fatal("inconsistent receipt accepted", scenario)
			}
			after, _ := json.Marshal(a)
			if string(before) != string(after) || state != recoverySnapshotTest(t, s) {
				t.Fatal("refusal mutated its input or persisted state")
			}
			valid, err := s.agent(a.ID)
			if err != nil {
				t.Fatal(err)
			}
			prepared, _ := json.Marshal(valid.PreparedContext)
			if err := s.checkMemorySummaryBeforeStart(&valid); err != nil {
				t.Fatal("valid recovery refused", err)
			}
			stored, err := s.agent(a.ID)
			if err != nil || stored.Context.Summary.CheckedBeforeStart == "" || stored.Context.Summary.CheckedSourceSHA != stored.Context.Summary.QueuedSourceSHA {
				t.Fatal("valid check not persisted", err)
			}
			retained, _ := json.Marshal(stored.PreparedContext)
			if string(prepared) != string(retained) {
				t.Fatal("prepared historical receipt was rewritten")
			}
		})
	}
}

func TestMemorySummarySelectionOriginalRequestRequired(t *testing.T) {
	for _, scenario := range []string{"malformed", "unknown-field", "schema", "event", "task", "revision", "context-hash", "missing-selection"} {
		t.Run(scenario, func(t *testing.T) {
			s, w, r := summarySelectionFixture(t)
			a := prepareSummaryAgent(t, s, w, r)
			var raw []byte
			if err := s.db.QueryRow("SELECT request FROM agents WHERE id=?", a.ID).Scan(&raw); err != nil {
				t.Fatal(err)
			}
			var request map[string]any
			if err := json.Unmarshal(raw, &request); err != nil {
				t.Fatal(err)
			}
			switch scenario {
			case "unknown-field":
				request["forged"] = true
			case "schema":
				request["schema_version"] = 2
			case "event":
				request["event_id"] = "other"
			case "task":
				request["task_id"] = "other"
			case "revision":
				request["expected_revision"] = 0
			case "context-hash":
				request["context_hash"] = hash([]byte("wrong"))
			case "missing-selection":
				delete(request, "summary_selection")
			}
			raw, _ = json.Marshal(request)
			if scenario == "malformed" {
				raw = []byte("{")
			}
			if _, err := s.db.Exec("UPDATE agents SET request=? WHERE id=?", raw, a.ID); err != nil {
				t.Fatal(err)
			}
			before := recoverySnapshotTest(t, s)
			if err := s.checkMemorySummaryBeforeStart(&a); err == nil {
				t.Fatal("invalid original launch accepted", scenario)
			}
			if before != recoverySnapshotTest(t, s) || a.Context.Summary.CheckedBeforeStart != "" {
				t.Fatal("invalid original request marked as checked")
			}
		})
	}
}

func TestMemorySummarySelectionCheckSaveFailureCanRecover(t *testing.T) {
	s, w, r := summarySelectionFixture(t)
	a := prepareSummaryAgent(t, s, w, r)
	before, _ := json.Marshal(a)
	if _, err := s.db.Exec("CREATE TRIGGER fixture_refuse_summary_check BEFORE UPDATE ON agents BEGIN SELECT RAISE(ABORT,'fixture summary check write failed'); END"); err != nil {
		t.Fatal(err)
	}
	state := recoverySnapshotTest(t, s)
	err := s.checkMemorySummaryBeforeStart(&a)
	after, _ := json.Marshal(a)
	if err == nil || !strings.Contains(err.Error(), "fixture summary check write failed") || string(before) != string(after) || state != recoverySnapshotTest(t, s) {
		t.Fatal("save failure changed the check receipt or hid its cause", err)
	}
	if _, err := s.db.Exec("DROP TRIGGER fixture_refuse_summary_check"); err != nil {
		t.Fatal(err)
	}
	if err := s.checkMemorySummaryBeforeStart(&a); err != nil || a.Context.Summary.CheckedBeforeStart == "" {
		t.Fatal("recovery after persistence failure", err)
	}
}

func TestMemorySummarySelectionNoReceiptWithoutSelection(t *testing.T) {
	s, w, r := summarySelectionFixture(t)
	r.Summary = nil
	a, created, err := s.prepare(w.ID, r)
	if err != nil || !created {
		t.Fatal(created, err)
	}
	before := recoverySnapshotTest(t, s)
	if err := s.checkMemorySummaryBeforeStart(&a); err != nil || before != recoverySnapshotTest(t, s) {
		t.Fatal("legacy non-summary launch changed", err)
	}
	selected := MemorySummaryReceipt{Schema: 1}
	a.Context.Summary = &selected
	if err := s.checkMemorySummaryBeforeStart(&a); err == nil {
		t.Fatal("injected receipt without original selection accepted")
	}
	if !reflect.DeepEqual(*a.Context.Summary, selected) || before != recoverySnapshotTest(t, s) {
		t.Fatal("injected receipt refusal mutated state")
	}
}

func TestMemorySummarySelectionPreparedReceiptCannotClaimStartCheck(t *testing.T) {
	s, w, r := summarySelectionFixture(t)
	a := prepareSummaryAgent(t, s, w, r)
	if err := appendAgentRecoveryContext(&a, "\nEngine recovery fixture\n"); err != nil {
		t.Fatal(err)
	}
	historical := *a.PreparedContext.Summary
	historical.CheckedBeforeStart = now()
	historical.CheckedSourceSHA = historical.QueuedSourceSHA
	a.PreparedContext.Summary = &historical
	before, _ := json.Marshal(a)
	state := recoverySnapshotTest(t, s)
	if err := s.checkMemorySummaryBeforeStart(&a); err == nil {
		t.Fatal("prepared receipt falsely claims a before-start check")
	}
	after, _ := json.Marshal(a)
	if string(before) != string(after) || state != recoverySnapshotTest(t, s) {
		t.Fatal("false prepared observation refusal mutated state")
	}
}

func TestMemorySummarySelectionCurrentObservationCanBeRechecked(t *testing.T) {
	s, w, r := summarySelectionFixture(t)
	a := prepareSummaryAgent(t, s, w, r)
	if err := appendAgentRecoveryContext(&a, "\nEngine recovery fixture\n"); err != nil {
		t.Fatal(err)
	}
	prepared, _ := json.Marshal(a.PreparedContext)
	for i := 0; i < 2; i++ {
		if err := s.checkMemorySummaryBeforeStart(&a); err != nil {
			t.Fatal("valid current observation cannot be checked again", err)
		}
	}
	retained, _ := json.Marshal(a.PreparedContext)
	if string(prepared) != string(retained) || a.Context.Summary.CheckedBeforeStart == "" || a.Context.Summary.CheckedSourceSHA != a.Context.Summary.QueuedSourceSHA {
		t.Fatal("current recheck rewrote prepared history or lost its observation")
	}
}
