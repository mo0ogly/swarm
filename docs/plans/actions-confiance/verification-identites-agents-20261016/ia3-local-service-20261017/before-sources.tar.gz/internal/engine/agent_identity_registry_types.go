//go:build linux

package engine

import (
	"encoding/json"
	"path/filepath"
)

// The journal is data. Authority additionally requires the independent Trust
// head AND a private checkpoint supplied by the controller, never reconstructed
// from an imported database or untrusted request. Human minting belongs to IA3.
type agentIdentityRegistryHead struct {
	Schema         int                           `json:"schema_version"`
	ProjectDigest  string                        `json:"project_context_digest"`
	Scope          agentIdentityScope            `json:"scope"`
	Revision       int                           `json:"snapshot_revision"`
	SnapshotDigest string                        `json:"snapshot_digest"`
	TrustRevision  int                           `json:"trust_configuration_revision"`
	Roots          []string                      `json:"root_grants"`
	Publisher      agentIdentityPrincipal        `json:"publisher"`
	EventID        string                        `json:"event_id"`
	Previous       string                        `json:"previous_head_digest,omitempty"`
	Issuance       *agentIdentityIssuanceReceipt `json:"issuance_receipt,omitempty"`
}

type agentIdentityRegistryIntent struct {
	Head     agentIdentityRegistryHead `json:"head"`
	Snapshot json.RawMessage           `json:"snapshot"`
}

type agentIdentityPublicationState struct {
	Head    *agentIdentityRegistryHead   `json:"head,omitempty"`
	Pending *agentIdentityRegistryIntent `json:"pending,omitempty"`
}

// Neither private checkpoint nor publication permit can be populated by JSON.
// The permit binds the exact next snapshot, roots, publisher and Trust revision.
// A business role or token alone never constructs this capability.
type agentIdentityRegistryCheckpoint struct {
	projectRoot string
	workID      string
	headDigest  string
}

type agentIdentityRegistryPermit struct {
	issuer        *agentIdentityPublicationIssuerProof
	base          agentIdentityRegistryCheckpoint
	nextDigest    string
	roots         []string
	publisher     agentIdentityPrincipal
	trustRevision int
	eventID       string
	scope         agentIdentityScope
}

func (c agentIdentityRegistryCheckpoint) valid() bool {
	return filepath.IsAbs(c.projectRoot) && filepath.Clean(c.projectRoot) == c.projectRoot && safeName(c.workID) &&
		(c.headDigest == "" || agentIdentityHashValid(c.headDigest))
}

func (h agentIdentityRegistryHead) valid() bool {
	if (h.Schema != 1 && h.Schema != 2) || (h.Schema == 1 && h.Issuance != nil) || (h.Schema == 2 && !h.Issuance.valid(h)) ||
		!agentIdentityHashValid(h.ProjectDigest) || !h.Scope.valid() || h.Revision <= 0 || !agentIdentityHashValid(h.SnapshotDigest) || h.TrustRevision <= 0 ||
		!h.Publisher.valid() || !safeName(h.EventID) || (h.Previous != "" && !agentIdentityHashValid(h.Previous)) || len(h.Roots) == 0 {
		return false
	}
	seen := map[string]bool{}
	for _, id := range h.Roots {
		if !safeName(id) || seen[id] {
			return false
		}
		seen[id] = true
	}
	return true
}

func validateAgentIdentityPublicationStates(states map[string]agentIdentityPublicationState) error {
	for id, state := range states {
		if !safeName(id) || (state.Head == nil && state.Pending == nil) {
			return agentIdentityError("agent_identity_registry_invalid")
		}
		previous := ""
		if state.Head != nil {
			if !state.Head.valid() || state.Head.Scope.WorkID != id {
				return agentIdentityError("agent_identity_registry_invalid")
			}
			previous, _ = agentIdentityDigest(*state.Head)
		}
		if state.Pending != nil {
			revision := 1
			if state.Head != nil {
				revision = state.Head.Revision + 1
			}
			if !state.Pending.Head.valid() || state.Pending.Head.Scope.WorkID != id || state.Pending.Head.Previous != previous || state.Pending.Head.Revision != revision || len(state.Pending.Snapshot) == 0 {
				return agentIdentityError("agent_identity_registry_invalid")
			}
		}
	}
	return nil
}

func validateAgentIdentityRegistrySnapshot(snapshot agentIdentitySnapshot, head agentIdentityRegistryHead) error {
	if !head.valid() || snapshot.Revision != head.Revision {
		return agentIdentityError("agent_identity_registry_invalid")
	}
	if err := validateAgentIdentitySnapshotRecords(snapshot); err != nil {
		return err
	}
	digest, err := agentIdentityDigest(snapshot)
	if err != nil || digest != head.SnapshotDigest {
		return agentIdentityError("agent_identity_snapshot_changed")
	}
	for _, id := range head.Roots {
		grant, exists := snapshot.Grants[id]
		if !exists || grant.ParentID != "" || grant.Scope != head.Scope || grant.TrustRevision != head.TrustRevision {
			return agentIdentityError("agent_identity_root_untrusted")
		}
	}
	visited := map[string]bool{}
	for id, grant := range snapshot.Grants {
		if grant.Scope.WorkID != head.Scope.WorkID {
			return agentIdentityError("agent_identity_registry_invalid")
		}
		if grant.Holder.InstanceID != "" {
			instance, exists := snapshot.Instances[grant.Holder.InstanceID]
			if !exists || instance.Principal != grant.Holder.Principal || instance.GrantID != id || instance.Scope != grant.Scope {
				return agentIdentityError("agent_identity_binding_mismatch")
			}
		}
		path := map[string]bool{}
		for currentID := id; currentID != "" && !visited[currentID]; {
			if path[currentID] {
				return agentIdentityError("agent_identity_delegation_invalid")
			}
			path[currentID] = true
			current := snapshot.Grants[currentID]
			if current.ParentID != "" {
				parent, exists := snapshot.Grants[current.ParentID]
				rights, valid := agentIdentityPermissionSet(parent.Delegable)
				if !exists || !valid || current.Issuer != parent.Holder || current.Scope != parent.Scope || current.TrustRevision != parent.TrustRevision ||
					current.NotBefore.Before(parent.NotBefore) || current.ExpiresAt.After(parent.ExpiresAt) ||
					!agentIdentitySubset(current.Permissions, rights) || !agentIdentitySubset(current.Delegable, rights) {
					return agentIdentityError("agent_identity_delegation_invalid")
				}
			}
			currentID = current.ParentID
		}
		for currentID := range path {
			visited[currentID] = true
		}
	}
	for id, instance := range snapshot.Instances {
		grant, exists := snapshot.Grants[instance.GrantID]
		if !exists || instance.Scope.WorkID != head.Scope.WorkID || grant.Holder.InstanceID != id || grant.Holder.Principal != instance.Principal || grant.Scope != instance.Scope {
			return agentIdentityError("agent_identity_binding_mismatch")
		}
	}
	return nil
}
