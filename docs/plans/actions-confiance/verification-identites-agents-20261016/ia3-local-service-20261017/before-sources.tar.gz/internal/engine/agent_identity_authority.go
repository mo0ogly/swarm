//go:build linux

package engine

import (
	"path/filepath"
	"time"
)

func agentIdentityPermissionSet(permissions []agentIdentityPermission) (map[agentIdentityPermission]bool, bool) {
	set := make(map[agentIdentityPermission]bool, len(permissions))
	for _, p := range permissions {
		if !p.valid() || set[p] {
			return nil, false
		}
		set[p] = true
	}
	return set, true
}

func agentIdentitySubset(child []agentIdentityPermission, parent map[agentIdentityPermission]bool) bool {
	for _, p := range child {
		if !parent[p] {
			return false
		}
	}
	return true
}

// The caller must provide a fresh, protected frame and time under the eventual
// commitment protocol. This pure evaluator neither locks nor commits either
// Trust JSON or mission SQLite. There is intentionally no implicit root role,
// unconfigured fallback, external self-asserted actor or imported authority.
func evaluateAgentIdentity(snapshot agentIdentitySnapshot, authority agentIdentityAuthority, caller agentIdentityCaller, request agentIdentityRequest, at time.Time) (agentIdentityDecision, error) {
	var result agentIdentityDecision
	deny := func(code string) (agentIdentityDecision, error) { return result, agentIdentityError(code) }
	if at.IsZero() {
		return deny("agent_identity_clock_required")
	}
	if !request.valid() {
		return deny("agent_identity_request_invalid")
	}
	if !caller.actor.valid() || !caller.verifiedAt.Equal(at) || caller.trustRevision <= 0 || caller.trustRevision != authority.trustRevision ||
		(caller.expiresAt != nil && !at.Before(*caller.expiresAt)) {
		return deny("agent_identity_caller_stale")
	}
	if snapshot.Schema != 1 || snapshot.Revision <= 0 || snapshot.Revision != authority.snapshotRevision ||
		!agentIdentityHashValid(authority.snapshotDigest) || !authority.scope.valid() || request.Scope != authority.scope ||
		!filepath.IsAbs(authority.projectRoot) || filepath.Clean(authority.projectRoot) != authority.projectRoot || caller.projectRoot != authority.projectRoot {
		return deny("agent_identity_authority_unavailable")
	}
	digest, err := agentIdentityDigest(snapshot)
	if err != nil || digest != authority.snapshotDigest {
		return deny("agent_identity_snapshot_changed")
	}
	if snapshot.Grants == nil || snapshot.Instances == nil || len(authority.roots) == 0 {
		return deny("agent_identity_authority_unavailable")
	}
	grant, ok := snapshot.Grants[request.GrantID]
	if !ok || grant.Holder != caller.actor {
		return deny("agent_identity_holder_mismatch")
	}
	if caller.actor.InstanceID == "" {
		if caller.bindingID != "" {
			return deny("agent_identity_binding_mismatch")
		}
	} else {
		instance, ok := snapshot.Instances[caller.actor.InstanceID]
		if !ok || instance.ID != caller.actor.InstanceID || !safeName(instance.LogicalAgentID) ||
			instance.Principal != caller.actor.Principal || instance.Scope != request.Scope || instance.GrantID != grant.ID ||
			!agentIdentityText(instance.BindingID) || caller.bindingID != instance.BindingID || instance.RevokedAt != nil {
			return deny("agent_identity_binding_mismatch")
		}
	}
	permission := agentIdentityPermission{request.Operation, request.Resource}
	permissions, valid := agentIdentityPermissionSet(grant.Permissions)
	if !valid || !permissions[permission] {
		return deny("agent_identity_permission_denied")
	}
	expires := grant.ExpiresAt
	if caller.expiresAt != nil && caller.expiresAt.Before(expires) {
		expires = *caller.expiresAt
	}
	seen := map[string]bool{}
	id := request.GrantID
	for {
		current, ok := snapshot.Grants[id]
		if !ok || current.ID != id || seen[id] || !safeName(id) || !current.Issuer.valid() || !current.Holder.valid() ||
			current.Scope != request.Scope || current.TrustRevision != authority.trustRevision || current.RevokedAt != nil || current.NotBefore.IsZero() ||
			current.ExpiresAt.IsZero() || !current.NotBefore.Before(current.ExpiresAt) || at.Before(current.NotBefore) || !at.Before(current.ExpiresAt) {
			return deny("agent_identity_grant_inactive")
		}
		seen[id] = true
		rights, rightsValid := agentIdentityPermissionSet(current.Permissions)
		_, delegableValid := agentIdentityPermissionSet(current.Delegable)
		if !rightsValid || len(rights) == 0 || !delegableValid || !agentIdentitySubset(current.Delegable, rights) {
			return deny("agent_identity_delegation_invalid")
		}
		if current.ExpiresAt.Before(expires) {
			expires = current.ExpiresAt
		}
		if current.ParentID == "" {
			if !authority.roots[id] {
				return deny("agent_identity_root_untrusted")
			}
			break
		}
		parent, ok := snapshot.Grants[current.ParentID]
		if !ok || current.Issuer != parent.Holder || current.Scope != parent.Scope || current.NotBefore.Before(parent.NotBefore) ||
			current.ExpiresAt.After(parent.ExpiresAt) {
			return deny("agent_identity_delegation_invalid")
		}
		parentDelegable, parentValid := agentIdentityPermissionSet(parent.Delegable)
		if !parentValid || !agentIdentitySubset(current.Permissions, parentDelegable) || !agentIdentitySubset(current.Delegable, parentDelegable) {
			return deny("agent_identity_delegation_invalid")
		}
		// Referencing a parent's old instance is not permission to delegate on
		// its behalf after that instance was revoked or replaced.
		if parent.Holder.InstanceID != "" {
			instance, ok := snapshot.Instances[parent.Holder.InstanceID]
			if !ok || instance.ID != parent.Holder.InstanceID || instance.Principal != parent.Holder.Principal ||
				instance.Scope != parent.Scope || instance.GrantID != parent.ID || instance.RevokedAt != nil {
				return deny("agent_identity_delegation_invalid")
			}
		}
		id = current.ParentID
	}
	requestDigest, err := agentIdentityDigest(request)
	if err != nil {
		return deny("agent_identity_request_invalid")
	}
	return agentIdentityDecision{ProjectDigest: hash([]byte(caller.projectRoot)), EventID: request.EventID, Actor: caller.actor, RequestDigest: requestDigest,
		SnapshotDigest: digest, SnapshotRevision: snapshot.Revision, TrustRevision: caller.trustRevision, ExpiresAt: expires.UTC()}, nil
}

// Reuse authenticates and reevaluates first, then compares the entire binding.
// It does not mark the decision consumed; the transactional consumer must do so.
func reuseAgentIdentityDecision(previous agentIdentityDecision, snapshot agentIdentitySnapshot, authority agentIdentityAuthority, caller agentIdentityCaller, request agentIdentityRequest, at time.Time) (agentIdentityDecision, error) {
	current, err := evaluateAgentIdentity(snapshot, authority, caller, request, at)
	if err != nil {
		return agentIdentityDecision{}, err
	}
	if current != previous {
		return agentIdentityDecision{}, agentIdentityError("agent_identity_decision_stale")
	}
	return current, nil
}

// This validates a proposed update, not its authority or its publication. An
// already published grant/instance cannot be rewritten or erased to reactivate
// rights. A replacement requires a new ID and an explicit newly authorized
// record. The future writer must check this against the protected current state
// and commit its new anchor atomically; comparing with an imported old state is
// insufficient.
func validateAgentIdentityTransition(previous, next agentIdentitySnapshot) error {
	if previous.Schema != 1 || next.Schema != 1 || previous.Revision <= 0 || next.Revision <= previous.Revision || next.Revision != previous.Revision+1 ||
		previous.Grants == nil || next.Grants == nil || previous.Instances == nil || next.Instances == nil {
		return agentIdentityError("agent_identity_transition_invalid")
	}
	for id, old := range previous.Grants {
		current, ok := next.Grants[id]
		if !ok || !agentIdentityRevocationPreserved(old.RevokedAt, current.RevokedAt) {
			return agentIdentityError("agent_identity_history_changed")
		}
		old.RevokedAt, current.RevokedAt = nil, nil
		before, err := agentIdentityDigest(old)
		if err != nil {
			return err
		}
		after, err := agentIdentityDigest(current)
		if err != nil {
			return err
		}
		if before != after {
			return agentIdentityError("agent_identity_history_changed")
		}
	}
	for id, old := range previous.Instances {
		current, ok := next.Instances[id]
		if !ok || !agentIdentityRevocationPreserved(old.RevokedAt, current.RevokedAt) {
			return agentIdentityError("agent_identity_history_changed")
		}
		old.RevokedAt, current.RevokedAt = nil, nil
		if old != current {
			return agentIdentityError("agent_identity_history_changed")
		}
	}
	return validateAgentIdentitySnapshotRecords(next)
}

func validateAgentIdentitySnapshotRecords(next agentIdentitySnapshot) error {
	if next.Schema != 1 || next.Revision <= 0 || next.Grants == nil || next.Instances == nil {
		return agentIdentityError("agent_identity_transition_invalid")
	}
	for id, grant := range next.Grants {
		permissions, valid := agentIdentityPermissionSet(grant.Permissions)
		_, delegable := agentIdentityPermissionSet(grant.Delegable)
		if id != grant.ID || !safeName(id) || !grant.Issuer.valid() || !grant.Holder.valid() || !grant.Scope.valid() || grant.TrustRevision <= 0 ||
			!valid || len(permissions) == 0 || !delegable || !agentIdentitySubset(grant.Delegable, permissions) ||
			grant.NotBefore.IsZero() || !grant.NotBefore.Before(grant.ExpiresAt) || (grant.ParentID != "" && !safeName(grant.ParentID)) {
			return agentIdentityError("agent_identity_transition_invalid")
		}
	}
	for id, instance := range next.Instances {
		if id != instance.ID || !safeName(id) || !safeName(instance.LogicalAgentID) || !instance.Principal.valid() || !instance.Scope.valid() ||
			!safeName(instance.GrantID) || !agentIdentityText(instance.BindingID) {
			return agentIdentityError("agent_identity_transition_invalid")
		}
	}
	return nil
}

func agentIdentityRevocationPreserved(previous, next *time.Time) bool {
	if next != nil && next.IsZero() {
		return false
	}
	return previous == nil || (next != nil && previous.Equal(*next))
}
