//go:build linux

package engine

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sync"
	"testing"
	"time"
)

type agentIdentityRegistryFixture struct {
	store    *Store
	snapshot agentIdentitySnapshot
	permit   agentIdentityRegistryPermit
	request  agentIdentityRequest
	actor    agentIdentityActor
}

func registryFixture(t *testing.T) agentIdentityRegistryFixture {
	t.Helper()
	s, _ := trustFixture(t)
	w := createdWork(t, s)
	w = seedPlan(t, s, w, fixturePlan())
	review, err := s.readPlan(w.ID, "plan-source")
	if err != nil {
		t.Fatal(err)
	}
	w, err = s.commitPlan(w.ID, newID("plan-adopt-"), w.Revision, review)
	if err != nil {
		t.Fatal(err)
	}
	f := agentIdentityAuthorityFixture(t)
	scope, err := s.readAgentIdentityNextPlanScope(registryContext(t), agentIdentityRegistryCheckpoint{s.root, w.ID, ""})
	if err != nil {
		t.Fatal(err)
	}
	f.request.Scope = scope
	f.snapshot.Revision = 1
	at := time.Now().UTC()
	for id, grant := range f.snapshot.Grants {
		grant.Scope, grant.NotBefore, grant.ExpiresAt = scope, at.Add(-time.Minute), at.Add(time.Hour)
		f.snapshot.Grants[id] = grant
	}
	for id, instance := range f.snapshot.Instances {
		instance.Scope = scope
		f.snapshot.Instances[id] = instance
	}
	digest, err := agentIdentityDigest(f.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	// Fixture stands in for the independent approval/checkpoint issuer. No
	// human approval or production checkpoint service is claimed by this setup.
	permit := agentIdentityRegistryPermit{base: agentIdentityRegistryCheckpoint{s.root, w.ID, ""}, nextDigest: digest, roots: []string{"grant-root"},
		publisher: f.caller.actor.Principal, trustRevision: f.caller.trustRevision, eventID: "registry-initial", scope: scope}
	return agentIdentityRegistryFixture{s, f.snapshot, permit, f.request, f.caller.actor}
}

func registryContext(t *testing.T) context.Context {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	t.Cleanup(cancel)
	return ctx
}

func registryRaw(t *testing.T, snapshot agentIdentitySnapshot) []byte {
	t.Helper()
	raw, err := json.Marshal(snapshot)
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func registryPublish(t *testing.T, f agentIdentityRegistryFixture) agentIdentityRegistryCheckpoint {
	t.Helper()
	checkpoint, err := f.store.publishAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), trustRequesterToken, f.permit, nil)
	if err != nil {
		t.Fatal(err)
	}
	return checkpoint
}

func registryNext(t *testing.T, f agentIdentityRegistryFixture, checkpoint agentIdentityRegistryCheckpoint) agentIdentityRegistryFixture {
	t.Helper()
	snapshot, err := decodeAgentIdentitySnapshot(registryRaw(t, f.snapshot))
	if err != nil {
		t.Fatal(err)
	}
	f.snapshot = snapshot
	f.snapshot.Revision++
	f.permit.base = checkpoint
	f.permit.eventID = "registry-next"
	return f
}

func registryApproveFixture(t *testing.T, f *agentIdentityRegistryFixture) {
	t.Helper()
	digest, err := agentIdentityDigest(f.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	f.permit.nextDigest = digest
}

func registryCounts(t *testing.T, s *Store) (int, int) {
	t.Helper()
	var snapshots, publications int
	if err := s.db.QueryRow(`SELECT count(*) FROM agent_identity_snapshots`).Scan(&snapshots); err != nil {
		t.Fatal(err)
	}
	if err := s.db.QueryRow(`SELECT count(*) FROM agent_identity_publications`).Scan(&publications); err != nil {
		t.Fatal(err)
	}
	return snapshots, publications
}

func registryTrustBytes(t *testing.T, s *Store) []byte {
	t.Helper()
	path, _, _ := s.trustPaths()
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func registryAssertUnchanged(t *testing.T, s *Store, before []byte, snapshots, publications int) {
	t.Helper()
	a, b := registryCounts(t, s)
	if string(before) != string(registryTrustBytes(t, s)) || a != snapshots || b != publications {
		t.Fatalf("rejected operation changed authority/journal: snapshots=%d/%d publications=%d/%d", a, snapshots, b, publications)
	}
}

func TestAgentIdentityRegistryPublicationPersistenceAndOwnedSource(t *testing.T) {
	f := registryFixture(t)
	checkpoint := registryPublish(t, f)
	// Reopen the actual SQLite/Trust files; keep the control checkpoint outside
	// the files being reopened. This is not an external witness service.
	if err := f.store.db.Close(); err != nil {
		t.Fatal(err)
	}
	s, err := openStore(f.store.root, false)
	if err != nil {
		t.Fatal(err)
	}
	defer s.db.Close()
	snapshot, authority, err := s.readAgentIdentityRegistry(registryContext(t), checkpoint)
	if err != nil || !reflect.DeepEqual(snapshot, f.snapshot) || authority.scope != f.request.Scope || !authority.roots["grant-root"] || authority.snapshotRevision != 1 {
		t.Fatalf("durable source lost binding: snapshot=%+v authority=%+v err=%v", snapshot, authority, err)
	}
	delete(snapshot.Grants, "grant-root")
	delete(authority.roots, "grant-root")
	snapshot, authority, err = s.readAgentIdentityRegistry(registryContext(t), checkpoint)
	if err != nil || len(snapshot.Grants) != 2 || !authority.roots["grant-root"] {
		t.Fatal("returned maps alias persisted authority: ", err)
	}
	f.store = s
	if again := registryPublish(t, f); again != checkpoint {
		t.Fatal("exact authenticated replay changed checkpoint")
	}
	if a, b := registryCounts(t, s); a != 1 || b != 1 {
		t.Fatal("replay duplicated publication: ", a, b)
	}
	var forged agentIdentityRegistryCheckpoint
	if err := json.Unmarshal([]byte(`{"projectRoot":"/tmp","workID":"work","headDigest":"self-asserted"}`), &forged); err != nil {
		t.Fatal(err)
	}
	if _, _, err = s.readAgentIdentityRegistry(registryContext(t), forged); err == nil {
		t.Fatal("JSON minted a private checkpoint")
	}
	if _, _, err = s.readAgentIdentityRegistry(registryContext(t), f.permit.base); err == nil {
		t.Fatal("empty bootstrap checkpoint adopted existing database authority")
	}
}

func TestAgentIdentityRegistryRejectsUnauthorizedAndHistoricalRewrite(t *testing.T) {
	for _, name := range []string{"missing-permit", "wrong-token", "wrong-publisher", "changed-content", "untrusted-root", "foreign-project", "event-reuse", "unrevoke", "cycle", "nil-context", "cancelled-context", "missing-work"} {
		t.Run(name, func(t *testing.T) {
			f := registryFixture(t)
			checkpoint := registryPublish(t, f)
			if name == "unrevoke" {
				next := registryNext(t, f, checkpoint)
				grant := next.snapshot.Grants["grant-child"]
				at := time.Now().UTC()
				grant.RevokedAt = &at
				next.snapshot.Grants[grant.ID] = grant
				registryApproveFixture(t, &next)
				checkpoint = registryPublish(t, next)
				f = next
			}
			next := registryNext(t, f, checkpoint)
			registryApproveFixture(t, &next)
			token := trustRequesterToken
			ctx := registryContext(t)
			switch name {
			case "missing-permit":
				next.permit = agentIdentityRegistryPermit{}
			case "wrong-token":
				token = "invented-credential-012345"
			case "wrong-publisher":
				token = trustAdminToken // business admin is not this independent permit's publisher
			case "changed-content":
				grant := next.snapshot.Grants["grant-child"]
				grant.ExpiresAt = grant.ExpiresAt.Add(-time.Second)
				next.snapshot.Grants[grant.ID] = grant
			case "untrusted-root":
				next.permit.roots = []string{"grant-child"}
			case "foreign-project":
				next.permit.base.projectRoot = t.TempDir()
			case "event-reuse":
				next.permit.eventID = "registry-initial"
			case "unrevoke":
				next.permit.eventID = "registry-third"
				grant := next.snapshot.Grants["grant-child"]
				grant.RevokedAt = nil
				next.snapshot.Grants[grant.ID] = grant
				registryApproveFixture(t, &next)
			case "cycle":
				grant := next.snapshot.Grants["grant-child"]
				grant.ParentID = grant.ID
				next.snapshot.Grants[grant.ID] = grant
				registryApproveFixture(t, &next)
			case "nil-context":
				ctx = nil
			case "cancelled-context":
				cancelled, cancel := context.WithCancel(context.Background())
				cancel()
				ctx = cancelled
			case "missing-work":
				next.snapshot.Revision = 1
				next.permit.base = agentIdentityRegistryCheckpoint{f.store.root, "absent-work", ""}
				next.permit.scope.WorkID = "absent-work"
				for id, grant := range next.snapshot.Grants {
					grant.Scope = next.permit.scope
					next.snapshot.Grants[id] = grant
				}
				for id, instance := range next.snapshot.Instances {
					instance.Scope = next.permit.scope
					next.snapshot.Instances[id] = instance
				}
				registryApproveFixture(t, &next)
			}
			before := registryTrustBytes(t, f.store)
			a, b := registryCounts(t, f.store)
			_, err := f.store.publishAgentIdentityRegistry(ctx, registryRaw(t, next.snapshot), token, next.permit, nil)
			if err == nil {
				t.Fatal("invalid publication succeeded")
			}
			if name == "unrevoke" && commandFailure(err).Code != "agent_identity_history_changed" {
				t.Fatal("unrevocation guard masked by another failure: ", err)
			}
			if name == "missing-work" && commandFailure(err).Code != "agent_identity_work_missing" {
				t.Fatal("missing-work guard masked by another failure: ", err)
			}
			registryAssertUnchanged(t, f.store, before, a, b)
		})
	}
}

func TestAgentIdentityRegistryRecoveryAtBothCommitBoundaries(t *testing.T) {
	for _, bootstrap := range []bool{true, false} {
		for _, phase := range []string{"intent_persisted", "sqlite_committed"} {
			name := phase
			if bootstrap {
				name += "-bootstrap"
			} else {
				name += "-update"
			}
			t.Run(name, func(t *testing.T) {
				f := registryFixture(t)
				baseRows := 0
				if !bootstrap {
					checkpoint := registryPublish(t, f)
					f = registryNext(t, f, checkpoint)
					registryApproveFixture(t, &f)
					baseRows = 1
				}
				injected := errors.New("fixture interruption at " + phase)
				_, err := f.store.publishAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), trustRequesterToken, f.permit, func(at string) error {
					if at == phase {
						return injected
					}
					return nil
				})
				if !errors.Is(err, injected) {
					t.Fatal("fault boundary not reached: ", err)
				}
				wantedRows := baseRows
				if phase == "sqlite_committed" {
					wantedRows++
				}
				if a, b := registryCounts(t, f.store); a != wantedRows || b != wantedRows {
					t.Fatal("wrong interrupted commit phase: ", a, b, wantedRows)
				}
				before := registryTrustBytes(t, f.store)
				if _, _, err = f.store.readAgentIdentityRegistry(registryContext(t), f.permit.base); err == nil {
					t.Fatal("pending state exposed authority")
				}
				if _, err = f.store.publishAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), trustRequesterToken, f.permit, nil); err == nil {
					t.Fatal("normal retry bypassed required recovery")
				}
				wrong := f.permit
				wrong.eventID = "different-recovery"
				if _, err = f.store.recoverAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), wrong); err == nil {
					t.Fatal("recovery accepted different intent")
				}
				registryAssertUnchanged(t, f.store, before, wantedRows, wantedRows)
				f.store.db.Close()
				reopened, err := openStore(f.store.root, false)
				if err != nil {
					t.Fatal(err)
				}
				defer reopened.db.Close()
				checkpoint, err := reopened.recoverAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), f.permit)
				if err != nil {
					t.Fatal("prepared publication did not recover: ", err)
				}
				if a, b := registryCounts(t, reopened); a != baseRows+1 || b != baseRows+1 {
					t.Fatal("recovery duplicated/lost journal: ", a, b)
				}
				if again, err := reopened.recoverAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), f.permit); err != nil || again != checkpoint {
					t.Fatal("recovery replay was not exact: ", err)
				}
				got, _, err := reopened.readAgentIdentityRegistry(registryContext(t), checkpoint)
				if err != nil || !reflect.DeepEqual(got, f.snapshot) {
					t.Fatal("recovery published a different snapshot: ", err)
				}
			})
		}
	}
}

func TestAgentIdentityRegistryRecoveryPreservesChangedTrust(t *testing.T) {
	f := registryFixture(t)
	_, err := f.store.publishAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), trustRequesterToken, f.permit, func(phase string) error {
		if phase == "intent_persisted" {
			return errors.New("fixture interrupted")
		}
		return nil
	})
	if err == nil {
		t.Fatal("fixture interruption missed")
	}
	if _, err = f.store.trustConfig(lifecycleChange(t, "alice", true, 1), false); err != nil {
		t.Fatal(err)
	}
	checkpoint, err := f.store.recoverAgentIdentityRegistry(registryContext(t), registryRaw(t, f.snapshot), f.permit)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = f.store.readAgentIdentityRegistry(registryContext(t), checkpoint); commandFailure(err).Code != "agent_identity_registry_stale" {
		t.Fatal("recovery revived old Trust rights: ", err)
	}
	_, err = f.store.withTrustLock(false, func(state *trustState) (any, error) {
		if state.Revision != 2 || state.AgentIdentities[f.permit.base.workID].Pending != nil {
			t.Fatal("recovery rolled back configuration or left pending state")
		}
		_, e := resolveAgentIdentityCaller(f.store.root, state, trustRequesterToken, time.Now().UTC())
		if e == nil {
			t.Fatal("recovery unsuspended the publisher")
		}
		return nil, nil
	})
	if err != nil {
		t.Fatal(err)
	}
}

func TestAgentIdentityRegistryRollbackAndTamperRequireCurrentWitness(t *testing.T) {
	for _, mode := range []string{"sqlite-rollback", "joint-rollback", "snapshot-tamper", "journal-tamper", "oversized-row", "checkpoint-foreign-project", "storage-version-changed"} {
		t.Run(mode, func(t *testing.T) {
			f := registryFixture(t)
			checkpoint := registryPublish(t, f)
			backup := filepath.Join(t.TempDir(), "old.db")
			if err := migrationBackup(f.store.db, backup); err != nil {
				t.Fatal(err)
			}
			oldTrust := registryTrustBytes(t, f.store)
			next := registryNext(t, f, checkpoint)
			at := time.Now().UTC()
			grant := next.snapshot.Grants["grant-child"]
			grant.RevokedAt = &at
			next.snapshot.Grants[grant.ID] = grant
			registryApproveFixture(t, &next)
			current := registryPublish(t, next)
			s := f.store
			switch mode {
			case "sqlite-rollback", "joint-rollback":
				if err := s.db.Close(); err != nil {
					t.Fatal(err)
				}
				raw, err := os.ReadFile(backup)
				if err != nil {
					t.Fatal(err)
				}
				if err = atomicWrite(filepath.Join(s.root, ".swarm", "state.db"), raw); err != nil {
					t.Fatal(err)
				}
				if mode == "joint-rollback" {
					path, _, _ := s.trustPaths()
					if err = atomicWrite(path, oldTrust); err != nil {
						t.Fatal(err)
					}
				}
				s, err = openStore(s.root, false)
				if err != nil {
					t.Fatal(err)
				}
				defer s.db.Close()
			case "snapshot-tamper":
				if _, err := s.db.Exec(`UPDATE agent_identity_snapshots SET body=? WHERE revision=2`, []byte(`{"schema_version":1}`)); err != nil {
					t.Fatal(err)
				}
			case "journal-tamper":
				if _, err := s.db.Exec(`UPDATE agent_identity_publications SET body=? WHERE event_id=?`, []byte(`{}`), f.permit.eventID); err != nil {
					t.Fatal(err)
				}
			case "oversized-row":
				if _, err := s.db.Exec(`UPDATE agent_identity_snapshots SET body=zeroblob(?) WHERE revision=2`, trustStateMaxBytes+1); err != nil {
					t.Fatal(err)
				}
			case "checkpoint-foreign-project":
				current.projectRoot = t.TempDir()
			case "storage-version-changed":
				if _, err := s.db.Exec(fmt.Sprintf("PRAGMA user_version=%d", schemaVersion+1)); err != nil {
					t.Fatal(err)
				}
			}
			_, _, err := s.readAgentIdentityRegistry(registryContext(t), current)
			if err == nil {
				t.Fatal("rollback/import/tamper bypassed the independent current checkpoint")
			}
			if mode == "storage-version-changed" && commandFailure(err).Code != "storage_version_conflict" {
				t.Fatal("storage fence masked by another failure: ", err)
			}
		})
	}
}

func TestAgentIdentityRegistryConcurrentPublishersAndCancelledWait(t *testing.T) {
	f := registryFixture(t)
	checkpoint := registryPublish(t, f)
	next := registryNext(t, f, checkpoint)
	registryApproveFixture(t, &next)
	raw := registryRaw(t, next.snapshot)
	var group sync.WaitGroup
	start := make(chan struct{})
	results := make(chan agentIdentityRegistryCheckpoint, 2)
	for _, id := range []string{"concurrent-A", "concurrent-B"} {
		permit := next.permit
		permit.eventID = id
		group.Add(1)
		go func() {
			defer group.Done()
			<-start
			got, err := f.store.publishAgentIdentityRegistry(context.Background(), raw, trustRequesterToken, permit, nil)
			if err == nil {
				results <- got
			}
		}()
	}
	close(start)
	group.Wait()
	close(results)
	if len(results) != 1 {
		t.Fatal("concurrent publications did not have exactly one winner: ", len(results))
	}
	winner := <-results
	if a, b := registryCounts(t, f.store); a != 2 || b != 2 {
		t.Fatal("concurrent publications duplicated or lost history: ", a, b)
	}
	if _, _, err := f.store.readAgentIdentityRegistry(registryContext(t), winner); err != nil {
		t.Fatal(err)
	}
	// Hold the only connection. A cancelled acquisition must release Trust
	// without preparing or publishing any state.
	connection, err := f.store.db.Conn(registryContext(t))
	if err != nil {
		t.Fatal(err)
	}
	defer connection.Close()
	next.permit.base = winner
	next.snapshot.Revision++
	next.permit.eventID = "cancelled-wait"
	registryApproveFixture(t, &next)
	before := registryTrustBytes(t, f.store)
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Millisecond)
	defer cancel()
	if _, err = f.store.publishAgentIdentityRegistry(ctx, registryRaw(t, next.snapshot), trustRequesterToken, next.permit, nil); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal("connection wait ignored caller cancellation: ", err)
	}
	connection.Close()
	registryAssertUnchanged(t, f.store, before, 2, 2)
}

func TestAgentIdentityRegistrySourceFeedsRealInstanceAndDurableRevocation(t *testing.T) {
	f := registryFixture(t)
	checkpoint := registryPublish(t, f)
	runtime, err := newAgentIdentityRuntime(f.store.root)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { runtime.Close() })
	directory, err := os.MkdirTemp("", "swarm-registry-channel-")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.RemoveAll(directory) })
	if err = os.WriteFile(filepath.Join(directory, "worker.py"), []byte(agentIdentityChannelWorker), 0600); err != nil {
		t.Fatal(err)
	}
	listener := agentIdentityTestListener(t, filepath.Join(directory, "broker.sock"))
	control := agentIdentityTestListener(t, filepath.Join(directory, "control.sock"))
	instance := f.snapshot.Instances[f.actor.InstanceID]
	cage := startAgentIdentityTestCage(t, runtime, f.actor, instance.BindingID, f.permit.trustRevision, directory, listener, control)
	exchange := func(checkpoint agentIdentityRegistryCheckpoint, allowed bool, refusal string) {
		cage.command(t, "send", f.request)
		message, err := receiveAgentIdentityMessage(cage.connection, make([]byte, 65536))
		if err != nil {
			t.Fatal(err)
		}
		decision, decisionErr := f.store.evaluateAgentIdentityRegistryMessage(registryContext(t), checkpoint, message, runtime, nil, time.Time{})
		message.Close()
		if _, err = cage.connection.Write([]byte{1}); err != nil {
			t.Fatal(err)
		}
		cage.completed(t)
		if (decisionErr == nil) != allowed || (allowed && decision.Actor != f.actor) {
			t.Fatalf("source-backed instance decision actor=%+v error=%v allowed=%v", decision.Actor, decisionErr, allowed)
		}
		if !allowed && commandFailure(decisionErr).Code != refusal {
			t.Fatal("expected source refusal masked by another failure: ", decisionErr)
		}
	}
	exchange(checkpoint, true, "")
	next := registryNext(t, f, checkpoint)
	grant := next.snapshot.Grants["grant-child"]
	at := time.Now().UTC()
	grant.RevokedAt = &at
	next.snapshot.Grants[grant.ID] = grant
	registryApproveFixture(t, &next)
	current := registryPublish(t, next)
	exchange(current, false, "agent_identity_grant_inactive")
	identityPlanEdit(t, f, func(w *Work) { w.Objective += " changed contract" })
	exchange(current, false, "agent_identity_plan_mismatch")
	var agents int
	if err = f.store.db.QueryRow(`SELECT count(*) FROM agents`).Scan(&agents); err != nil || agents != 0 {
		t.Fatal("registry publication/decision created a business agent: ", agents, err)
	}
}

func TestAgentIdentityRegistryMigrationPreservesHistoryAndInspection(t *testing.T) {
	f := registryFixture(t)
	work, err := f.store.get(f.permit.base.workID)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = f.store.db.Exec(`DROP TABLE agent_identity_publications; DROP TABLE agent_identity_snapshots; PRAGMA user_version=35`); err != nil {
		t.Fatal(err)
	}
	f.store.db.Close()
	if _, err = openStoreWithMigration(f.store.root, false, false); commandFailure(err).Code != "storage_upgrade_required" {
		t.Fatal("inspection implicitly upgraded identity storage: ", err)
	}
	s, err := openStore(f.store.root, false)
	if err != nil {
		t.Fatal(err)
	}
	defer s.db.Close()
	got, err := s.get(work.ID)
	if err != nil || !reflect.DeepEqual(got, work) {
		t.Fatal("identity migration changed legacy Work: ", err)
	}
	backups, err := filepath.Glob(filepath.Join(s.root, ".swarm", "state-pre-v36-*.db"))
	if err != nil || len(backups) != 1 {
		t.Fatal("migration backup missing: ", backups, err)
	}
	if a, b := registryCounts(t, s); a != 0 || b != 0 {
		t.Fatal("migration granted authority to historical data: ", a, b)
	}
	f.store = s
	registryPublish(t, f)
}
