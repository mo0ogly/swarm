//go:build linux

package engine

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

type agentIdentityTestState struct {
	snapshot  agentIdentitySnapshot
	authority agentIdentityAuthority
	caller    agentIdentityCaller
	request   agentIdentityRequest
	at        time.Time
}

func agentIdentityAuthorityFixture(t *testing.T) agentIdentityTestState {
	t.Helper()
	s, at := trustFixture(t)
	var caller agentIdentityCaller
	_, err := s.withTrustLock(false, func(st *trustState) (any, error) {
		var err error
		caller, err = resolveAgentIdentityCaller(s.root, st, trustRequesterToken, at)
		return nil, err
	})
	if err != nil {
		t.Fatal(err)
	}
	request := agentIdentityTestRequest()
	issuer := caller.actor
	actor := issuer
	actor.InstanceID = "instance-child"
	permission := agentIdentityPermission{request.Operation, request.Resource}
	root := agentIdentityGrant{ID: "grant-root", Issuer: issuer, Holder: issuer, Scope: request.Scope, TrustRevision: caller.trustRevision,
		Permissions: []agentIdentityPermission{permission}, Delegable: []agentIdentityPermission{permission}, NotBefore: at.Add(-time.Minute), ExpiresAt: at.Add(time.Hour)}
	child := root
	child.ID, child.ParentID, child.Holder = "grant-child", root.ID, actor
	child.NotBefore, child.ExpiresAt = at.Add(-time.Second), at.Add(time.Minute)
	child.Delegable = nil
	snapshot := agentIdentitySnapshot{Schema: 1, Revision: 4, Grants: map[string]agentIdentityGrant{root.ID: root, child.ID: child},
		Instances: map[string]agentIdentityInstance{actor.InstanceID: {ID: actor.InstanceID, LogicalAgentID: "logical-child", Principal: actor.Principal, Scope: request.Scope, GrantID: child.ID, BindingID: "verified-channel-1"}}}
	caller.actor, caller.bindingID = actor, "verified-channel-1"
	f := agentIdentityTestState{snapshot: snapshot, caller: caller, request: request, at: at}
	f.authority = agentIdentityAuthority{projectRoot: caller.projectRoot, trustRevision: caller.trustRevision, scope: request.Scope, roots: map[string]bool{root.ID: true}}
	f.refreshTestAuthority(t)
	return f
}

// Fixture-only stand-in for the protected current-authority producer. Production
// must not derive its trusted frame this way from untrusted/persisted snapshot data.
func (f *agentIdentityTestState) refreshTestAuthority(t *testing.T) {
	t.Helper()
	digest, err := agentIdentityDigest(f.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	f.authority.snapshotDigest, f.authority.snapshotRevision = digest, f.snapshot.Revision
}

func (f agentIdentityTestState) clone(t *testing.T) agentIdentityTestState {
	t.Helper()
	raw, err := json.Marshal(f.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	f.snapshot, err = decodeAgentIdentitySnapshot(raw)
	if err != nil {
		t.Fatal(err)
	}
	roots := map[string]bool{}
	for id, allowed := range f.authority.roots {
		roots[id] = allowed
	}
	f.authority.roots = roots
	return f
}

func (f *agentIdentityTestState) changeGrant(id string, fn func(*agentIdentityGrant)) {
	g := f.snapshot.Grants[id]
	fn(&g)
	f.snapshot.Grants[id] = g
}

func TestAgentIdentityAuthorityPermitsExactAttenuatedRequest(t *testing.T) {
	f := agentIdentityAuthorityFixture(t)
	before := f.clone(t)
	decision, err := evaluateAgentIdentity(f.snapshot, f.authority, f.caller, f.request, f.at)
	if err != nil {
		t.Fatal(err)
	}
	digest, err := agentIdentityDigest(f.request)
	if err != nil {
		t.Fatal(err)
	}
	if decision.RequestDigest != digest || decision.Actor != f.caller.actor || decision.EventID != f.request.EventID ||
		decision.SnapshotRevision != 4 || !decision.ExpiresAt.Equal(f.at.Add(time.Minute)) {
		t.Fatalf("decision lost exact binding: %#v", decision)
	}
	if !reflect.DeepEqual(f.snapshot, before.snapshot) {
		t.Fatal("evaluation mutated registry")
	}
	if _, err := reuseAgentIdentityDecision(decision, f.snapshot, f.authority, f.caller, f.request, f.at); err != nil {
		t.Fatal(err)
	}
}

func TestAgentIdentityRejectsCachedCaller(t *testing.T) {
	f := agentIdentityAuthorityFixture(t)
	if _, err := evaluateAgentIdentity(f.snapshot, f.authority, f.caller, f.request, f.at.Add(time.Second)); err == nil {
		t.Fatal("a previously resolved caller was reused at a later decision without fresh authentication")
	}
}

func TestAgentIdentityAuthorityRejectsInvalidChainsWithoutMutation(t *testing.T) {
	base := agentIdentityAuthorityFixture(t)
	cases := map[string]func(*agentIdentityTestState){
		"zero-clock":        func(f *agentIdentityTestState) { f.at = time.Time{} },
		"missing-authority": func(f *agentIdentityTestState) { f.authority = agentIdentityAuthority{} },
		"missing-principal": func(f *agentIdentityTestState) { f.caller.actor.Principal = agentIdentityPrincipal{} },
		"foreign-issuer":    func(f *agentIdentityTestState) { f.caller.actor.Principal.Issuer = "https://other-issuer.invalid" },
		"foreign-subject":   func(f *agentIdentityTestState) { f.caller.actor.Principal.Subject = "homonym" },
		"kind-confusion":    func(f *agentIdentityTestState) { f.caller.actor.Principal.Kind = "human" },
		"missing-binding":   func(f *agentIdentityTestState) { f.caller.bindingID = "" },
		"copied-binding":    func(f *agentIdentityTestState) { f.caller.bindingID = "another-channel" },
		"copied-instance":   func(f *agentIdentityTestState) { f.caller.actor.InstanceID = "instance-other" },
		"missing-instance":  func(f *agentIdentityTestState) { delete(f.snapshot.Instances, f.caller.actor.InstanceID) },
		"revoked-instance": func(f *agentIdentityTestState) {
			i := f.snapshot.Instances[f.caller.actor.InstanceID]
			i.RevokedAt = &f.at
			f.snapshot.Instances[i.ID] = i
		},
		"wrong-instance-grant": func(f *agentIdentityTestState) {
			i := f.snapshot.Instances[f.caller.actor.InstanceID]
			i.GrantID = "grant-root"
			f.snapshot.Instances[i.ID] = i
		},
		"expired-caller": func(f *agentIdentityTestState) { at := f.at; f.caller.expiresAt = &at },
		"stale-caller":   func(f *agentIdentityTestState) { f.caller.trustRevision-- },
		"foreign-work":   func(f *agentIdentityTestState) { f.request.Scope.WorkID = "work-other" },
		"stale-plan":     func(f *agentIdentityTestState) { f.authority.scope.PlanVersion++ },
		"changed-plan":   func(f *agentIdentityTestState) { f.authority.scope.PlanDigest = hash([]byte("new-plan")) },
		"missing-root":   func(f *agentIdentityTestState) { delete(f.authority.roots, "grant-root") },
		"untrusted-root": func(f *agentIdentityTestState) { f.authority.roots = map[string]bool{"unrelated": true} },
		"missing-parent": func(f *agentIdentityTestState) { delete(f.snapshot.Grants, "grant-root") },
		"cycle": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) {
				g.ParentID = "grant-child"
				g.Issuer = f.caller.actor
				g.NotBefore = f.at.Add(-time.Second)
				g.ExpiresAt = f.at.Add(time.Minute)
			})
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Delegable = append([]agentIdentityPermission{}, g.Permissions...) })
		},
		"self-parent": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) {
				g.ParentID = g.ID
				g.Issuer = g.Holder
				g.Delegable = append([]agentIdentityPermission{}, g.Permissions...)
			})
		},
		"forged-parent": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Issuer.Principal.ID = "bob"; g.Issuer.Principal.Subject = "bob" })
		},
		"future-child": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.NotBefore = f.at.Add(time.Second) })
		},
		"expired-child": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.ExpiresAt = f.at })
		},
		"expired-parent": func(f *agentIdentityTestState) { f.at = f.at.Add(time.Hour) },
		"revoked-child": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.RevokedAt = &f.at })
		},
		"revoked-parent": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { g.RevokedAt = &f.at })
		},
		"time-escalation": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.ExpiresAt = f.at.Add(2 * time.Hour) })
		},
		"start-escalation": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.NotBefore = f.at.Add(-time.Hour) })
		},
		"permission-escalation": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) {
				g.Permissions = append(g.Permissions, agentIdentityPermission{"memory.transmit", "memory/private"})
			})
		},
		"nondelegable-parent": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { g.Delegable = nil })
		},
		"invalid-delegable": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Delegable = []agentIdentityPermission{{"memory.read", "other"}} })
		},
		"duplicate-permission": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Permissions = append(g.Permissions, g.Permissions[0]) })
		},
		"wildcard-permission": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) {
				g.Delegable = append(g.Delegable, agentIdentityPermission{"agent.create", "*"})
			})
		},
		"unknown-operation": func(f *agentIdentityTestState) { f.request.Operation = "admin.grant" },
		"wrong-resource":    func(f *agentIdentityTestState) { f.request.Resource = "task/other" },
		"parent-other-plan": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { g.Scope.PlanVersion++ })
		},
		"old-grant-after-reactivation": func(f *agentIdentityTestState) { f.authority.trustRevision++; f.caller.trustRevision++ },
	}
	for name, change := range cases {
		t.Run(name, func(t *testing.T) {
			f := base.clone(t)
			change(&f)
			f.caller.verifiedAt = f.at // fixture stand-in for a fresh runtime attestation
			f.refreshTestAuthority(t)
			before, err := json.Marshal(f.snapshot)
			if err != nil {
				t.Fatal(err)
			}
			decision, err := evaluateAgentIdentity(f.snapshot, f.authority, f.caller, f.request, f.at)
			if err == nil || decision != (agentIdentityDecision{}) {
				t.Fatalf("invalid authority accepted: %#v, %v", decision, err)
			}
			after, err := json.Marshal(f.snapshot)
			if err != nil || string(before) != string(after) {
				t.Fatal("denial mutated registry")
			}
		})
	}
}

func TestAgentIdentityDecisionReauthenticationAndExactReplay(t *testing.T) {
	base := agentIdentityAuthorityFixture(t)
	previous, err := evaluateAgentIdentity(base.snapshot, base.authority, base.caller, base.request, base.at)
	if err != nil {
		t.Fatal(err)
	}
	for name, change := range map[string]func(*agentIdentityTestState){
		"different-event":   func(f *agentIdentityTestState) { f.request.EventID = "create-2" },
		"different-content": func(f *agentIdentityTestState) { f.request.ContentDigest = hash([]byte("changed launch")) },
		"different-caller":  func(f *agentIdentityTestState) { f.caller.actor.Principal.ID = "bob" },
		"expired":           func(f *agentIdentityTestState) { f.at = previous.ExpiresAt },
		"revoked-then-replay": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { g.RevokedAt = &f.at })
			f.snapshot.Revision++
			f.refreshTestAuthority(t)
		},
		"current-snapshot-changed": func(f *agentIdentityTestState) { f.snapshot.Revision++; f.refreshTestAuthority(t) },
	} {
		t.Run(name, func(t *testing.T) {
			f := base.clone(t)
			change(&f)
			f.caller.verifiedAt = f.at
			if _, err := reuseAgentIdentityDecision(previous, f.snapshot, f.authority, f.caller, f.request, f.at); err == nil {
				t.Fatal("old result returned without fresh exact authorization")
			}
		})
	}
}

func TestAgentIdentitySnapshotIsDataNotImportedAuthority(t *testing.T) {
	f := agentIdentityAuthorityFixture(t)
	raw, err := json.Marshal(f.snapshot)
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "snapshot.json")
	if err := os.WriteFile(path, raw, 0600); err != nil {
		t.Fatal(err)
	}
	reopened, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	snapshot, err := decodeAgentIdentitySnapshot(reopened)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := evaluateAgentIdentity(snapshot, agentIdentityAuthority{}, f.caller, f.request, f.at); err == nil {
		t.Fatal("imported snapshot became active authority")
	}
	if _, err := evaluateAgentIdentity(snapshot, f.authority, f.caller, f.request, f.at); err != nil {
		t.Fatal(err)
	}
	old := snapshot
	f.snapshot.Revision++
	f.refreshTestAuthority(t)
	if _, err := evaluateAgentIdentity(old, f.authority, f.caller, f.request, f.at); err == nil {
		t.Fatal("old authentic snapshot restored active rights")
	}
	for _, body := range []string{"null", "{}", string(raw) + " {}", `{"schema_version":1,"revision":1,"grants":{},"instances":{},"roots":{"grant-root":true}}`, `{"schema_version":1,"revision":1,"revision":2,"grants":{},"instances":{}}`} {
		if _, err := decodeAgentIdentitySnapshot([]byte(body)); err == nil {
			t.Fatal("invalid/self-authorizing snapshot accepted")
		}
	}
}

func TestAgentIdentitySnapshotTamperingCannotRefreshItsOwnAuthority(t *testing.T) {
	base := agentIdentityAuthorityFixture(t)
	for name, change := range map[string]func(*agentIdentityTestState){
		"alter-grant": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.ExpiresAt = g.ExpiresAt.Add(time.Hour) })
		},
		"remove-revocation": func(f *agentIdentityTestState) { f.snapshot.Revision-- },
		"alter-instance": func(f *agentIdentityTestState) {
			i := f.snapshot.Instances[f.caller.actor.InstanceID]
			i.BindingID = "other-channel"
			f.snapshot.Instances[i.ID] = i
		},
	} {
		t.Run(name, func(t *testing.T) {
			f := base.clone(t)
			change(&f)
			if _, err := evaluateAgentIdentity(f.snapshot, f.authority, f.caller, f.request, f.at); err == nil {
				t.Fatal("snapshot accepted without the independent current frame")
			}
		})
	}
}

func TestAgentIdentityMultilevelDelegationRevocation(t *testing.T) {
	f := agentIdentityAuthorityFixture(t)
	f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Delegable = append([]agentIdentityPermission{}, g.Permissions...) })
	parent := f.snapshot.Grants["grant-child"]
	grandchild := parent
	grandchild.ID = "grant-grandchild"
	grandchild.ParentID = parent.ID
	grandchild.Issuer = parent.Holder
	grandchild.Holder.InstanceID = "instance-grandchild"
	grandchild.Delegable = nil
	f.snapshot.Grants[grandchild.ID] = grandchild
	f.snapshot.Instances[grandchild.Holder.InstanceID] = agentIdentityInstance{ID: grandchild.Holder.InstanceID, LogicalAgentID: "logical-grandchild", Principal: grandchild.Holder.Principal, Scope: grandchild.Scope, GrantID: grandchild.ID, BindingID: "verified-channel-2"}
	f.caller.actor = grandchild.Holder
	f.caller.bindingID = "verified-channel-2"
	f.request.GrantID = grandchild.ID
	f.refreshTestAuthority(t)
	if _, err := evaluateAgentIdentity(f.snapshot, f.authority, f.caller, f.request, f.at); err != nil {
		t.Fatal(err)
	}
	for _, ancestor := range []string{"grant-root", "grant-child"} {
		t.Run(ancestor, func(t *testing.T) {
			copy := f.clone(t)
			copy.changeGrant(ancestor, func(g *agentIdentityGrant) { g.RevokedAt = &copy.at })
			copy.snapshot.Revision++
			copy.refreshTestAuthority(t)
			if err := validateAgentIdentityTransition(f.snapshot, copy.snapshot); err != nil {
				t.Fatal(err)
			}
			if _, err := evaluateAgentIdentity(copy.snapshot, copy.authority, copy.caller, copy.request, copy.at); err == nil {
				t.Fatal("descendant retained ancestor's revoked authority")
			}
		})
	}
	t.Run("revoked-parent-instance", func(t *testing.T) {
		copy := f.clone(t)
		i := copy.snapshot.Instances[parent.Holder.InstanceID]
		i.RevokedAt = &copy.at
		copy.snapshot.Instances[i.ID] = i
		copy.refreshTestAuthority(t)
		if _, err := evaluateAgentIdentity(copy.snapshot, copy.authority, copy.caller, copy.request, copy.at); err == nil {
			t.Fatal("descendant used revoked parent instance")
		}
	})
}

func TestAgentIdentityTransitionPreservesHistoryAndRevocation(t *testing.T) {
	f := agentIdentityAuthorityFixture(t)
	next := f.clone(t)
	next.snapshot.Revision++
	next.changeGrant("grant-root", func(g *agentIdentityGrant) { g.RevokedAt = &next.at })
	if err := validateAgentIdentityTransition(f.snapshot, next.snapshot); err != nil {
		t.Fatal(err)
	}
	for name, change := range map[string]func(*agentIdentityTestState){
		"remove-grant": func(f *agentIdentityTestState) { delete(f.snapshot.Grants, "grant-child") },
		"rewrite-holder": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Holder.InstanceID = "replacement" })
		},
		"rewrite-plan": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.Scope.PlanVersion++ })
		},
		"extend-expiry": func(f *agentIdentityTestState) {
			f.changeGrant("grant-child", func(g *agentIdentityGrant) { g.ExpiresAt = g.ExpiresAt.Add(time.Second) })
		},
		"clear-revocation": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { g.RevokedAt = nil })
		},
		"move-revocation": func(f *agentIdentityTestState) {
			f.changeGrant("grant-root", func(g *agentIdentityGrant) { at := f.at.Add(time.Second); g.RevokedAt = &at })
		},
		"remove-instance": func(f *agentIdentityTestState) { delete(f.snapshot.Instances, "instance-child") },
		"reuse-binding": func(f *agentIdentityTestState) {
			i := f.snapshot.Instances["instance-child"]
			i.BindingID = "replacement-binding"
			f.snapshot.Instances[i.ID] = i
		},
		"reuse-logical-agent": func(f *agentIdentityTestState) {
			i := f.snapshot.Instances["instance-child"]
			i.LogicalAgentID = "other"
			f.snapshot.Instances[i.ID] = i
		},
		"skip-revision":     func(f *agentIdentityTestState) { f.snapshot.Revision++ },
		"rollback-revision": func(f *agentIdentityTestState) { f.snapshot.Revision -= 2 },
	} {
		t.Run(name, func(t *testing.T) {
			candidate := next.clone(t)
			candidate.snapshot.Revision++
			change(&candidate)
			if err := validateAgentIdentityTransition(next.snapshot, candidate.snapshot); err == nil {
				t.Fatal("history/revocation rewritten")
			}
		})
	}
	updated := next.clone(t)
	updated.snapshot.Revision++
	replacement := updated.snapshot.Grants["grant-child"]
	replacement.ID = "grant-replacement"
	updated.snapshot.Grants[replacement.ID] = replacement
	if err := validateAgentIdentityTransition(next.snapshot, updated.snapshot); err != nil {
		t.Fatal(err)
	}
	if next.snapshot.Grants["grant-root"].RevokedAt == nil || updated.snapshot.Grants["grant-root"].RevokedAt == nil {
		t.Fatal("replacement erased revoked ancestor")
	}
}
